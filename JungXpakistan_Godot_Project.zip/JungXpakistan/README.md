# JungXpakistan (Godot 4.3 prototype)

Original 3D battle-royale prototype. Single-player vs 29 AI bots (30 players per match).
Art is placeholder primitives (no imported assets). Layout is inspired by the genre, not copied from any game.

## STATUS (honest)
| Feature | State |
|---|---|
| Lobby: character select (2 characters), 3-slot Skill Hub, rank, missions | Written, NOT yet run |
| Bangalia map section (village, city, abandoned buildings, river, bridge, farmland, hills, trees) | Written, NOT yet run |
| Touch controls: move, look, fire, jump, crouch, reload, 3 skills | Written, NOT yet run |
| Control editor: move/resize buttons, opacity, sensitivity, save/load/reset | Written, NOT yet run |
| Weapon: ammo, reload, recoil, hitscan, 40% aim assist (~1.5 m) | Written, NOT yet run |
| Safe zone, loot (medkits, ammo), supply drop, 29 AI bots, results, RP + ranks | Written, NOT yet run |
| Training ground | Written, NOT yet run |
| Online multiplayer, custom rooms, matchmaking, Duo/Squad, AI assistant, anti-cheat | NOT implemented (see docs/ARCHITECTURE.md) |
| APK | NOT built (the environment that wrote this had no Godot or Android SDK) |

"Not yet run" means the code was written without a Godot editor available, so expect to fix a few small errors
on first open. Paste any red error from Godot's Output panel back to Claude and it will be fixed.

## Run on PC first (fastest way to test)
1. Download Godot 4.3 (standard, not .NET) from godotengine.org.
2. Open Godot > Import > select `project.godot` > Open.
3. Press F5. Mouse clicks act as touch (drag the left side = move, right side = look, click buttons).

## Build the APK
1. Install JDK 17 and the Android SDK (easiest: install Android Studio once, then SDK Manager: Platform 34,
   Build-Tools 34.0.0, Platform-Tools, Command-line Tools, CMake, NDK).
2. Godot: Editor > Editor Settings > Export > Android: set Android SDK Path and Java SDK Path
   (and create a debug keystore: `keytool -keyalg RSA -genkeypair -alias androiddebugkey -keypass android -keystore debug.keystore -storepass android -dname "CN=Android Debug,O=Android,C=US" -validity 9999`
   then set it in the same settings page, user `androiddebugkey`, password `android`).
3. Editor > Manage Export Templates > Download and Install.
4. Project > Export > Add... > Android. Set Package > Unique Name to `com.jungxpakistan.game`.
5. Click "Export Project", untick "Export With Debug" only for release builds, save as `JungXpakistan.apk`.
6. Copy the APK to your phone and install (allow "install unknown apps").
Exact SDK/NDK versions change per Godot release: follow docs.godotengine.org > "Exporting for Android" for 4.3.

## Files
- scripts/main.gd: lobby <-> match switch
- scripts/lobby.gd, customize.gd: menus
- scripts/game.gd: world, player, bots, zone, skills, loot
- scripts/hud.gd: touch controls + HUD
- scripts/settings.gd: saved settings, layout, rank (user://save.cfg)
- scripts/data.gd: characters + skills
