# Roadmap to real online play

The prototype is client-only. Do these in order; do not claim multiplayer until each is tested.
1. Dedicated authoritative server: same Godot project exported headless (Linux), ENet/WebSocket via
   MultiplayerAPI. Server owns movement, hit detection, damage, zone, loot. Clients send inputs only.
2. Aim assist must be applied/validated on the server (same 40%, ~1.5 m rule as game.gd) so it is fair and transparent.
3. Matchmaking + custom rooms: small backend (e.g. Nakama or a Node/Go service) issuing room codes, optional passwords,
   queues for Solo/Duo/Squad, filling to 30 players.
4. Accounts, ranking (RP rules are in game.gd `_finish`), leaderboards, seasonal reset: backend DB.
5. Reconnect + spectating: server keeps player state for a grace window; spectators receive snapshots.
6. AI assistant (optional): backend endpoint calls the AI API; the key lives only on the server, never in the APK.
7. Anti-cheat: server validation of speed, fire rate, ammo; report system; rate limiting.
