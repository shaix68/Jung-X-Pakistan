extends RefCounted
## Saved settings, control layout and player profile (user://save.cfg).

const PATH := "user://save.cfg"
const BUTTONS := ["stick", "fire", "jump", "crouch", "reload", "skill1", "skill2", "skill3"]
# name: [x fraction, y fraction, size multiplier]
const DEFAULT_LAYOUT := {
	"stick": [0.13, 0.68, 1.0],
	"fire": [0.88, 0.70, 1.15],
	"jump": [0.94, 0.45, 0.9],
	"crouch": [0.80, 0.48, 0.8],
	"reload": [0.76, 0.87, 0.8],
	"skill1": [0.62, 0.87, 0.9],
	"skill2": [0.56, 0.66, 0.9],
	"skill3": [0.62, 0.46, 0.9],
}
const TIERS := ["Bronze", "Silver", "Gold", "Platinum", "Diamond", "Heroic"]
const TIER_MIN := [0, 100, 250, 450, 700, 1000]

static var layout: Dictionary = {}
static var opacity := 0.75
static var cam_sens := 1.0
static var aim_sens := 0.8
static var aim_assist := 0.4
static var low_end := false
static var volume := 0.8
static var rp := 0
static var matches := 0
static var kills := 0
static var wins := 0
static var skills_used := 0
static var char_idx := 0
static var loaded := false

static func reset_layout() -> void:
	layout = {}
	for b in BUTTONS:
		layout[b] = DEFAULT_LAYOUT[b].duplicate()

static func load_all() -> void:
	if loaded:
		return
	loaded = true
	reset_layout()
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	for b in BUTTONS:
		var v = cfg.get_value("layout", b, null)
		if v is Array and v.size() == 3:
			layout[b] = v
	opacity = cfg.get_value("ui", "opacity", opacity)
	cam_sens = cfg.get_value("ui", "cam_sens", cam_sens)
	aim_sens = cfg.get_value("ui", "aim_sens", aim_sens)
	aim_assist = cfg.get_value("ui", "aim_assist", aim_assist)
	low_end = cfg.get_value("ui", "low_end", low_end)
	volume = cfg.get_value("ui", "volume", volume)
	rp = cfg.get_value("profile", "rp", rp)
	matches = cfg.get_value("profile", "matches", matches)
	kills = cfg.get_value("profile", "kills", kills)
	wins = cfg.get_value("profile", "wins", wins)
	skills_used = cfg.get_value("profile", "skills_used", skills_used)
	char_idx = cfg.get_value("profile", "char_idx", char_idx)

static func save_all() -> void:
	var cfg := ConfigFile.new()
	for b in BUTTONS:
		cfg.set_value("layout", b, layout[b])
	cfg.set_value("ui", "opacity", opacity)
	cfg.set_value("ui", "cam_sens", cam_sens)
	cfg.set_value("ui", "aim_sens", aim_sens)
	cfg.set_value("ui", "aim_assist", aim_assist)
	cfg.set_value("ui", "low_end", low_end)
	cfg.set_value("ui", "volume", volume)
	cfg.set_value("profile", "rp", rp)
	cfg.set_value("profile", "matches", matches)
	cfg.set_value("profile", "kills", kills)
	cfg.set_value("profile", "wins", wins)
	cfg.set_value("profile", "skills_used", skills_used)
	cfg.set_value("profile", "char_idx", char_idx)
	cfg.save(PATH)

static func tier_index() -> int:
	var idx := 0
	for i in TIER_MIN.size():
		if rp >= TIER_MIN[i]:
			idx = i
	return idx
