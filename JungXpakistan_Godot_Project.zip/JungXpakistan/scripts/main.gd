extends Node
## Switches between the lobby and a match.

const Lobby = preload("res://scripts/lobby.gd")
const Game = preload("res://scripts/game.gd")

var current: Node

func _ready() -> void:
	# lets you test touch controls with the mouse on desktop
	Input.emulate_touch_from_mouse = not (OS.has_feature("android") or OS.has_feature("ios"))
	show_lobby()

func show_lobby() -> void:
	var l := Lobby.new()
	l.start_pressed.connect(start_match)
	_swap(l)

func start_match(mode: String) -> void:
	var g := Game.new()
	g.mode = mode
	g.exit_to_lobby.connect(show_lobby)
	_swap(g)

func _swap(n: Node) -> void:
	if current:
		current.queue_free()
	current = n
	add_child(n)
