extends Node3D
## Match scene: Bangalia map section, player, 29 AI bots (30 total), safe zone, loot, skills.
## NOTE: single-player prototype. Multiplayer needs a dedicated server (see docs/ARCHITECTURE.md).

signal exit_to_lobby

const Settings = preload("res://scripts/settings.gd")
const Data = preload("res://scripts/data.gd")
const Model = preload("res://scripts/character_model.gd")
const HudScript = preload("res://scripts/hud.gd")

const MAP_HALF := 190.0
const GUN_RANGE := 120.0
const FIRE_INTERVAL := 0.11
const MAG_SIZE := 30
const AIM_ASSIST_RANGE := 1.5
const ZONE_RADII := [180.0, 115.0, 65.0, 30.0, 10.0]
const HUBS := [Vector2(70, 70), Vector2(-110, -100), Vector2(105, -110)]

var mode := "solo"
var chardata: Dictionary = {}
var rng := RandomNumberGenerator.new()
var space: PhysicsDirectSpaceState3D

var player: CharacterBody3D
var cam_pivot: Node3D
var cam: Camera3D
var player_model: Node3D
var shield_node: MeshInstance3D
var hud

var hp := 100.0
var ammo := 30
var reserve := 90
var reloading := 0.0
var fire_cd := 0.0
var yaw := 0.0
var pitch := -0.1
var vel_y := 0.0
var crouching := false
var dash_t := 0.0
var dash_dir := Vector3.ZERO
var shield_t := 0.0
var speed_t := 0.0
var radar_t := 0.0
var skill_cd := [0.0, 0.0, 0.0]
var kills := 0
var elapsed := 0.0
var finished := false
var attr_t := 6.0
var drop_spawned := false

var bots: Array = []
var pickups: Array = []

var zone_center := Vector2.ZERO
var zone_radius := 280.0
var zone_stage := 0
var zone_timer := 25.0
var zone_shrinking := false
var zone_from := 280.0
var zone_to := 180.0
var zone_c_from := Vector2.ZERO
var zone_c_to := Vector2.ZERO
var zone_node: MeshInstance3D

var sfx_shot: AudioStreamPlayer
var sfx_skill: AudioStreamPlayer
var sfx_hit: AudioStreamPlayer
var result_panel: PanelContainer
var result_label: Label

func _ready() -> void:
	Settings.load_all()
	rng.randomize()
	chardata = Data.CHARS[Settings.char_idx]
	_build_world()
	_build_player()
	_spawn_bots()
	_spawn_pickups()
	_build_zone()
	_build_ui()
	_make_audio()
	if mode == "training":
		reserve = 999
		hud.toast("Training ground: infinite ammo, dummy bots, no zone")
	else:
		hud.toast("Match started: be the last one alive!")

# ------------------------------------------------------------------ world
func _box(pos: Vector3, sz: Vector3, color: Color, collide := true) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = sz
	mi.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	mi.material_override = m
	body.add_child(mi)
	if collide:
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = sz
		cs.shape = sh
		body.add_child(cs)
	add_child(body)
	return body

func _house(c: Vector3, w: float, d: float, h: float, col: Color) -> void:
	var t := 0.3
	var door := 2.2
	_box(c + Vector3(0, h / 2.0, -d / 2.0), Vector3(w, h, t), col)
	_box(c + Vector3(-w / 2.0, h / 2.0, 0), Vector3(t, h, d), col)
	_box(c + Vector3(w / 2.0, h / 2.0, 0), Vector3(t, h, d), col)
	var half := (w - door) / 2.0
	_box(c + Vector3(-(door / 2.0 + half / 2.0), h / 2.0, d / 2.0), Vector3(half, h, t), col)
	_box(c + Vector3(door / 2.0 + half / 2.0, h / 2.0, d / 2.0), Vector3(half, h, t), col)
	_box(c + Vector3(0, 2.4 + (h - 2.4) / 2.0, d / 2.0), Vector3(door, h - 2.4, t), col)
	_box(c + Vector3(0, h + 0.15, 0), Vector3(w + 0.6, 0.3, d + 0.6), col.darkened(0.45))

func _tree(p: Vector3) -> void:
	var body := StaticBody3D.new()
	body.position = p
	var trunk := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.22
	cm.bottom_radius = 0.28
	cm.height = 3.0
	trunk.mesh = cm
	trunk.position = Vector3(0, 1.5, 0)
	var tm := StandardMaterial3D.new()
	tm.albedo_color = Color(0.35, 0.22, 0.12)
	trunk.material_override = tm
	body.add_child(trunk)
	var canopy := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 1.7
	sm.height = 3.4
	canopy.mesh = sm
	canopy.position = Vector3(0, 4.0, 0)
	var gm := StandardMaterial3D.new()
	gm.albedo_color = Color(0.12, 0.45, 0.15)
	canopy.material_override = gm
	body.add_child(canopy)
	var cs := CollisionShape3D.new()
	var sh := CylinderShape3D.new()
	sh.radius = 0.35
	sh.height = 3.0
	cs.shape = sh
	cs.position = Vector3(0, 1.5, 0)
	body.add_child(cs)
	add_child(body)

func _build_world() -> void:
	# sky, light, ambient
	var we := WorldEnvironment.new()
	var env := Environment.new()
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sky.sky_material = sm
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, -30, 0)
	sun.shadow_enabled = not Settings.low_end
	add_child(sun)

	# ground + farmland
	_box(Vector3(0, -0.5, 0), Vector3(400, 1, 400), Color(0.33, 0.55, 0.24))
	for i in 10:
		var fp := Vector3(rng.randf_range(-170, 170), 0.02, rng.randf_range(-170, 170))
		if absf(fp.x + 40.0) < 14.0:
			continue
		_box(fp, Vector3(rng.randf_range(18, 34), 0.04, rng.randf_range(14, 24)), Color(0.55, 0.45, 0.2).lerp(Color(0.4, 0.6, 0.2), rng.randf()), false)
	# roads
	_box(Vector3(0, 0.03, 0), Vector3(400, 0.05, 6), Color(0.18, 0.18, 0.2), false)
	_box(Vector3(60, 0.03, 0), Vector3(6, 0.05, 400), Color(0.18, 0.18, 0.2), false)
	# river + bridge (river slows movement except on the bridge band)
	_box(Vector3(-40, 0.04, 0), Vector3(14, 0.06, 400), Color(0.15, 0.4, 0.75), false)
	_box(Vector3(-40, 0.09, 0), Vector3(16, 0.08, 8), Color(0.4, 0.28, 0.15), false)
	# distant hills (decoration beyond the playable edge)
	for i in 12:
		var a := TAU * float(i) / 12.0
		var hill := MeshInstance3D.new()
		var hs := SphereMesh.new()
		hill.mesh = hs
		var hm := StandardMaterial3D.new()
		hm.albedo_color = Color(0.25, 0.4, 0.25)
		hill.material_override = hm
		hill.scale = Vector3(45, 28, 45)
		hill.position = Vector3(cos(a) * 235.0, -4.0, sin(a) * 235.0)
		add_child(hill)

	# village (houses)
	for ix in 4:
		for iz in 3:
			var hc := Vector3(45.0 + ix * 16.0, 0, 45.0 + iz * 16.0)
			_house(hc, rng.randf_range(7, 10), rng.randf_range(6, 9), 3.2, Color(0.75, 0.55, 0.35))
	# city (tall buildings)
	for ix in 3:
		for iz in 3:
			var cc := Vector3(-135.0 + ix * 26.0, 0, -125.0 + iz * 26.0)
			_house(cc, 14, 14, rng.randf_range(8, 17), Color(0.6, 0.62, 0.66))
	# abandoned buildings
	for i in 5:
		_house(Vector3(85.0 + (i % 3) * 18.0, 0, -125.0 + (i / 3) * 22.0), 9, 8, 3.4, Color(0.3, 0.28, 0.27))
	# trees
	var tree_count := 35 if Settings.low_end else 110
	for i in tree_count:
		var tp := Vector3(rng.randf_range(-MAP_HALF, MAP_HALF), 0, rng.randf_range(-MAP_HALF, MAP_HALF))
		if absf(tp.x + 40.0) < 10.0 or tp.length() < 15.0:
			continue
		var near_hub := false
		for h in HUBS:
			if Vector2(tp.x, tp.z).distance_to(h) < 38.0:
				near_hub = true
		if not near_hub:
			_tree(tp)

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.position = Vector3(0, 0.1, 8)
	player.collision_layer = 4
	player.collision_mask = 1
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.8
	cs.shape = cap
	cs.position = Vector3(0, 0.9, 0)
	player.add_child(cs)
	player_model = Model.build(chardata)
	player.add_child(player_model)
	shield_node = MeshInstance3D.new()
	var sph := SphereMesh.new()
	sph.radius = 1.1
	sph.height = 2.2
	shield_node.mesh = sph
	var shm := StandardMaterial3D.new()
	shm.albedo_color = Color(0.3, 0.8, 1.0, 0.3)
	shm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	shm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	shield_node.material_override = shm
	shield_node.position = Vector3(0, 1.0, 0)
	shield_node.visible = false
	player.add_child(shield_node)
	add_child(player)
	cam_pivot = Node3D.new()
	cam_pivot.position = Vector3(0, 1.5, 0)
	player.add_child(cam_pivot)
	cam = Camera3D.new()
	cam.position = Vector3(0.7, 0.3, 3.4)
	cam.fov = 70.0
	cam_pivot.add_child(cam)
	cam.current = true

func _random_spawn(min_player_dist: float) -> Vector3:
	for i in 20:
		var p := Vector3(rng.randf_range(-MAP_HALF + 10.0, MAP_HALF - 10.0), 0.5, rng.randf_range(-MAP_HALF + 10.0, MAP_HALF - 10.0))
		if absf(p.x + 40.0) < 9.0:
			continue
		if p.distance_to(player.global_position) > min_player_dist:
			return p
	return Vector3(50, 0.5, -50)

func _spawn_bots() -> void:
	var n := 6 if mode == "training" else 29
	for i in n:
		var node := CharacterBody3D.new()
		node.collision_layer = 2
		node.collision_mask = 1
		var cs := CollisionShape3D.new()
		var cap := CapsuleShape3D.new()
		cap.radius = 0.35
		cap.height = 1.8
		cs.shape = cap
		cs.position = Vector3(0, 0.9, 0)
		node.add_child(cs)
		var look := {"gender": "Male" if i % 2 == 0 else "Female", "shirt": Color.from_hsv(rng.randf(), 0.6, 0.7), "pants": Color(0.15, 0.15, 0.18), "skin": Color(0.6, 0.42, 0.3).lerp(Color(0.8, 0.6, 0.45), rng.randf())}
		node.add_child(Model.build(look))
		var p := Vector3.ZERO
		if mode == "training":
			var a := TAU * float(i) / float(n)
			p = player.global_position + Vector3(cos(a) * 18.0, 0.3, sin(a) * 18.0)
		else:
			p = _random_spawn(40.0)
		node.position = p
		add_child(node)
		bots.append({"node": node, "hp": 100.0, "alive": true, "cd": rng.randf_range(0.5, 2.0), "wander": p, "wt": 0.0})

func _spawn_pickups() -> void:
	for i in 45:
		var kind := "med" if i % 3 == 0 else "ammo"
		var p := _random_spawn(10.0)
		_make_pickup(p + Vector3(0, 0.3, 0), kind)

func _make_pickup(p: Vector3, kind: String) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.5, 0.5, 0.5) if kind != "drop" else Vector3(1.2, 1.2, 1.2)
	mi.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = {"med": Color(0.2, 0.9, 0.3), "ammo": Color(0.95, 0.8, 0.2), "drop": Color(1.0, 0.75, 0.1)}[kind]
	m.emission_enabled = true
	m.emission = m.albedo_color
	m.emission_energy_multiplier = 0.6
	mi.material_override = m
	mi.position = p
	add_child(mi)
	if kind == "drop":
		var beam := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 0.2
		cm.bottom_radius = 0.2
		cm.height = 60.0
		beam.mesh = cm
		var bmat := StandardMaterial3D.new()
		bmat.albedo_color = Color(1, 0.8, 0.2, 0.5)
		bmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		bmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		beam.material_override = bmat
		beam.position = Vector3(0, 30, 0)
		mi.add_child(beam)
	pickups.append({"node": mi, "kind": kind})

func _build_zone() -> void:
	zone_node = MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.0
	cm.bottom_radius = 1.0
	cm.height = 80.0
	cm.radial_segments = 48
	cm.rings = 1
	zone_node.mesh = cm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.2, 0.5, 1.0, 0.16)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	zone_node.material_override = m
	zone_node.position = Vector3(0, 30, 0)
	zone_node.scale = Vector3(zone_radius, 1, zone_radius)
	zone_node.visible = mode != "training"
	add_child(zone_node)

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	hud = HudScript.new()
	hud.game = self
	layer.add_child(hud)
	var leave := Button.new()
	leave.text = "LEAVE"
	leave.anchor_left = 1.0
	leave.anchor_right = 1.0
	leave.offset_left = -110.0
	leave.offset_right = -10.0
	leave.offset_top = 8.0
	leave.offset_bottom = 48.0
	leave.pressed.connect(func():
		Settings.save_all()
		exit_to_lobby.emit())
	layer.add_child(leave)
	result_panel = PanelContainer.new()
	result_panel.visible = false
	result_panel.set_anchors_preset(Control.PRESET_CENTER)
	result_panel.custom_minimum_size = Vector2(420, 220)
	result_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	result_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	var box := VBoxContainer.new()
	result_label = Label.new()
	result_label.add_theme_font_size_override("font_size", 26)
	result_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(result_label)
	var back := Button.new()
	back.text = "BACK TO LOBBY"
	back.custom_minimum_size = Vector2(0, 56)
	back.pressed.connect(func(): exit_to_lobby.emit())
	box.add_child(back)
	result_panel.add_child(box)
	layer.add_child(result_panel)

# ------------------------------------------------------------------ audio
func _make_wav(freq: float, dur: float, noise: float) -> AudioStreamWAV:
	var rate := 22050
	var n := int(rate * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		var t := float(i) / rate
		var env := 1.0 - float(i) / n
		var s := (sin(TAU * freq * t) * (1.0 - noise) + (randf() * 2.0 - 1.0) * noise) * env * 0.6
		data.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 32767.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.data = data
	return w

func _make_audio() -> void:
	sfx_shot = _player_for(_make_wav(140.0, 0.12, 0.8))
	sfx_skill = _player_for(_make_wav(520.0, 0.25, 0.0))
	sfx_hit = _player_for(_make_wav(900.0, 0.06, 0.1))

func _player_for(stream: AudioStream) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.stream = stream
	p.volume_db = linear_to_db(maxf(Settings.volume, 0.001))
	add_child(p)
	return p

# ------------------------------------------------------------------ main loop
func _physics_process(delta: float) -> void:
	if finished:
		return
	space = get_world_3d().direct_space_state
	elapsed += delta
	_update_look()
	_update_move(delta)
	_update_combat(delta)
	_update_skills(delta)
	_update_zone(delta)
	_update_bots(delta)
	_update_pickups(delta)
	_sim_attrition(delta)
	_check_end()

func _process(_delta: float) -> void:
	if cam == null or cam_pivot == null:
		return
	# keep the camera from clipping through walls
	var desired := Vector3(0.7, 0.3, 3.4)
	var from := cam_pivot.global_position
	var to := cam_pivot.to_global(desired)
	if space != null:
		var q := PhysicsRayQueryParameters3D.create(from, to)
		q.collision_mask = 1
		var hit := space.intersect_ray(q)
		if hit:
			var dist := maxf(from.distance_to(hit.position) - 0.25, 0.5)
			cam.position = desired.normalized() * minf(dist, desired.length())
			return
	cam.position = desired

func _update_look() -> void:
	var sens: float = 0.004 * (Settings.aim_sens if hud.held.get("fire", false) else Settings.cam_sens)
	yaw -= hud.look_delta.x * sens
	pitch = clampf(pitch - hud.look_delta.y * sens, -1.2, 0.8)
	hud.look_delta = Vector2.ZERO
	player.rotation.y = yaw
	cam_pivot.rotation.x = pitch

func _in_river() -> bool:
	var p := player.global_position
	return absf(p.x + 40.0) < 7.0 and absf(p.z) > 4.0

func _update_move(delta: float) -> void:
	if hud.take("crouch"):
		crouching = not crouching
		player_model.scale.y = 0.72 if crouching else 1.0
		cam_pivot.position.y = 1.1 if crouching else 1.5
	var mv: Vector2 = hud.move_vec
	var dir: Vector3 = player.global_transform.basis * Vector3(mv.x, 0, mv.y)
	dir.y = 0.0
	var spd := 3.0 if crouching else 6.0
	if speed_t > 0.0:
		spd *= 1.6
	if _in_river():
		spd *= 0.55
	var hv := dir * spd
	if dash_t > 0.0:
		hv = dash_dir * 22.0
		dash_t -= delta
	if player.is_on_floor():
		vel_y = 0.0
		if hud.take("jump"):
			vel_y = 5.5
	else:
		vel_y -= 14.0 * delta
		hud.take("jump")
	player.velocity = Vector3(hv.x, vel_y, hv.z)
	player.move_and_slide()
	var p := player.global_position
	player.global_position = Vector3(clampf(p.x, -MAP_HALF, MAP_HALF), p.y, clampf(p.z, -MAP_HALF, MAP_HALF))

func _update_combat(delta: float) -> void:
	fire_cd = maxf(0.0, fire_cd - delta)
	if reloading > 0.0:
		reloading -= delta
		if reloading <= 0.0:
			var take := mini(MAG_SIZE - ammo, reserve)
			ammo += take
			if mode != "training":
				reserve -= take
	if hud.take("reload") and reloading <= 0.0 and ammo < MAG_SIZE and reserve > 0:
		reloading = 1.8
	if hud.held.get("fire", false) and fire_cd <= 0.0 and reloading <= 0.0:
		if ammo > 0:
			_shoot()
		elif reserve > 0:
			reloading = 1.8

func _shoot() -> void:
	fire_cd = FIRE_INTERVAL
	if mode != "training":
		ammo -= 1
	var origin := cam.global_position
	var dir: Vector3 = -cam.global_transform.basis.z
	# aim assist: only pulls toward a target already within ~1.5 m of the crosshair line
	var best = null
	var best_perp := AIM_ASSIST_RANGE
	for b in bots:
		if not b.alive:
			continue
		var tb: Vector3 = b.node.global_position + Vector3(0, 1.1, 0) - origin
		var tt := tb.dot(dir)
		if tt < 2.0 or tt > GUN_RANGE:
			continue
		var perp := (tb - dir * tt).length()
		if perp < best_perp:
			best_perp = perp
			best = b
	if best != null and Settings.aim_assist > 0.0:
		var to_t: Vector3 = best.node.global_position + Vector3(0, 1.1, 0) - origin
		dir = dir.lerp(to_t.normalized(), Settings.aim_assist).normalized()
	# wall check
	var wall_dist := GUN_RANGE
	var q := PhysicsRayQueryParameters3D.create(origin, origin + dir * GUN_RANGE)
	q.collision_mask = 1
	var hit := space.intersect_ray(q)
	if hit:
		wall_dist = origin.distance_to(hit.position)
	var target = null
	var tmin := wall_dist
	for b in bots:
		if not b.alive:
			continue
		var tv: Vector3 = b.node.global_position + Vector3(0, 1.0, 0) - origin
		var t2 := tv.dot(dir)
		if t2 < 0.0 or t2 > tmin:
			continue
		if (tv - dir * t2).length() < 0.7:
			target = b
			tmin = t2
	var muzzle := player.global_position + Vector3(0, 1.3, 0) - player.global_transform.basis.z * 0.6 + player.global_transform.basis.x * 0.3
	_tracer(muzzle, origin + dir * tmin)
	sfx_shot.play()
	pitch = minf(pitch + 0.010, 0.8)
	if target != null:
		hud.hit_flash = 0.15
		sfx_hit.play()
		_damage_bot(target, 18.0, true)

func _tracer(a: Vector3, b: Vector3) -> void:
	var dist := a.distance_to(b)
	if dist < 0.5:
		return
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.03, 0.03, dist)
	mi.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(1, 0.9, 0.4)
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mi.material_override = m
	add_child(mi)
	mi.global_position = (a + b) / 2.0
	mi.look_at(b, Vector3.UP)
	get_tree().create_timer(0.05).timeout.connect(mi.queue_free)

func _damage_bot(b: Dictionary, dmg: float, by_player: bool) -> void:
	if not b.alive:
		return
	b.hp -= dmg
	if b.hp <= 0.0:
		_kill_bot(b, by_player)

func _kill_bot(b: Dictionary, by_player: bool) -> void:
	b.alive = false
	b.node.queue_free()
	if by_player:
		kills += 1
		hud.toast("Eliminated a player!")

func _hurt(dmg: float) -> void:
	if shield_t > 0.0:
		dmg *= 0.3
	hp -= dmg
	hud.dmg_flash = 0.35

# ------------------------------------------------------------------ skills
func _update_skills(delta: float) -> void:
	for i in 3:
		skill_cd[i] = maxf(0.0, skill_cd[i] - delta)
		if hud.take("skill%d" % (i + 1)):
			_use_skill(i)
	shield_t = maxf(0.0, shield_t - delta)
	speed_t = maxf(0.0, speed_t - delta)
	radar_t = maxf(0.0, radar_t - delta)
	shield_node.visible = shield_t > 0.0

func _use_skill(i: int) -> void:
	if skill_cd[i] > 0.0:
		return
	var s: Dictionary = chardata["skills"][i]
	skill_cd[i] = s["cd"]
	Settings.skills_used += 1
	sfx_skill.play()
	var pc := player.global_position + Vector3(0, 1.0, 0)
	match s["kind"]:
		"dash":
			var f: Vector3 = -player.global_transform.basis.z
			f.y = 0.0
			dash_dir = f.normalized()
			dash_t = 0.2
			_fx(pc, Color(1.0, 0.8, 0.2), 1.2, 0.3)
		"shield":
			shield_t = 3.0
			_fx(pc, Color(0.3, 0.8, 1.0), 1.6, 0.4)
		"heal":
			hp = minf(100.0, hp + 30.0)
			_fx(pc, Color(0.3, 1.0, 0.4), 1.6, 0.5)
		"speed":
			speed_t = 4.0
			_fx(pc, Color(1.0, 0.6, 0.2), 1.3, 0.4)
		"radar":
			radar_t = 5.0
			_fx(pc, Color(0.4, 0.6, 1.0), 6.0, 0.8)
		"blast":
			_fx(pc, Color(1.0, 0.3, 0.3), 8.0, 0.5)
			for b in bots:
				if b.alive and b.node.global_position.distance_to(player.global_position) <= 8.0:
					_damage_bot(b, 40.0, true)

func _fx(pos: Vector3, color: Color, radius: float, dur: float) -> void:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 1.0
	sm.height = 2.0
	mi.mesh = sm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(color, 0.45)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mi.material_override = m
	mi.scale = Vector3.ONE * 0.2
	add_child(mi)
	mi.global_position = pos
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(mi, "scale", Vector3.ONE * radius, dur)
	tw.tween_property(m, "albedo_color:a", 0.0, dur)
	tw.chain().tween_callback(mi.queue_free)

# ------------------------------------------------------------------ zone / bots / loot
func _update_zone(delta: float) -> void:
	if mode == "training":
		return
	zone_timer -= delta
	if not zone_shrinking:
		if zone_timer <= 0.0 and zone_stage < ZONE_RADII.size():
			zone_shrinking = true
			zone_timer = 20.0
			zone_from = zone_radius
			zone_to = ZONE_RADII[zone_stage]
			zone_c_from = zone_center
			var ang := rng.randf() * TAU
			zone_c_to = zone_center + Vector2(cos(ang), sin(ang)) * rng.randf() * maxf(zone_from - zone_to, 0.0) * 0.8
			hud.toast("Safe zone is shrinking!")
	else:
		var k := 1.0 - clampf(zone_timer / 20.0, 0.0, 1.0)
		zone_radius = lerpf(zone_from, zone_to, k)
		zone_center = zone_c_from.lerp(zone_c_to, k)
		if zone_timer <= 0.0:
			zone_shrinking = false
			zone_timer = 25.0
			zone_stage += 1
	zone_node.scale = Vector3(zone_radius, 1, zone_radius)
	zone_node.position = Vector3(zone_center.x, 30, zone_center.y)
	var dps := 1.5 + zone_stage * 1.5
	var p2 := Vector2(player.global_position.x, player.global_position.z)
	if p2.distance_to(zone_center) > zone_radius:
		hp -= dps * delta
		hud.dmg_flash = maxf(hud.dmg_flash, 0.15)
	if not drop_spawned and elapsed >= 45.0:
		drop_spawned = true
		var ang2 := rng.randf() * TAU
		var dp := zone_center + Vector2(cos(ang2), sin(ang2)) * zone_radius * 0.5
		_make_pickup(Vector3(clampf(dp.x, -MAP_HALF, MAP_HALF), 0.6, clampf(dp.y, -MAP_HALF, MAP_HALF)), "drop")
		hud.toast("Supply drop landed! Look for the golden beam")
	for b in bots:
		if b.alive:
			var bp := Vector2(b.node.global_position.x, b.node.global_position.z)
			if bp.distance_to(zone_center) > zone_radius:
				_damage_bot(b, dps * delta, false)

func _los_clear(a: Vector3, b: Vector3) -> bool:
	var q := PhysicsRayQueryParameters3D.create(a, b)
	q.collision_mask = 1
	return space.intersect_ray(q).is_empty()

func _update_bots(delta: float) -> void:
	var ppos := player.global_position
	for b in bots:
		if not b.alive:
			continue
		var n: CharacterBody3D = b.node
		var bpos := n.global_position
		var to_p := ppos - bpos
		var d := to_p.length()
		var move_dir := Vector3.ZERO
		var outside := mode != "training" and Vector2(bpos.x, bpos.z).distance_to(zone_center) > zone_radius - 3.0
		if mode == "training":
			pass
		elif outside:
			var c3 := Vector3(zone_center.x, bpos.y, zone_center.y)
			move_dir = (c3 - bpos).normalized()
		elif d < 45.0:
			if d > 14.0:
				move_dir = Vector3(to_p.x, 0, to_p.z).normalized()
			elif d < 8.0:
				move_dir = -Vector3(to_p.x, 0, to_p.z).normalized()
			b.cd -= delta
			if b.cd <= 0.0:
				b.cd = rng.randf_range(0.8, 1.3)
				var eye := bpos + Vector3(0, 1.4, 0)
				var chest := ppos + Vector3(0, 1.1, 0)
				if _los_clear(eye, chest):
					var hit_it := rng.randf() < 0.35
					var miss := Vector3.ZERO if hit_it else Vector3(rng.randf_range(-1.5, 1.5), 0, rng.randf_range(-1.5, 1.5))
					_tracer(eye, chest + miss)
					if hit_it:
						_hurt(7.0)
		else:
			b.wt -= delta
			if b.wt <= 0.0 or bpos.distance_to(b.wander) < 2.0:
				b.wander = bpos + Vector3(rng.randf_range(-40, 40), 0, rng.randf_range(-40, 40))
				b.wt = rng.randf_range(4.0, 8.0)
			move_dir = Vector3(b.wander.x - bpos.x, 0, b.wander.z - bpos.z).normalized()
		if d > 0.5 and (d < 60.0 or mode == "training"):
			n.look_at(Vector3(ppos.x, bpos.y, ppos.z), Vector3.UP)
		elif move_dir.length() > 0.1:
			n.look_at(bpos + move_dir, Vector3.UP)
		n.velocity = Vector3(move_dir.x * 4.0, -6.0, move_dir.z * 4.0)
		n.move_and_slide()

func _update_pickups(delta: float) -> void:
	var pp := player.global_position
	for i in range(pickups.size() - 1, -1, -1):
		var pk: Dictionary = pickups[i]
		var node: MeshInstance3D = pk["node"]
		node.rotate_y(delta * 2.0)
		if node.global_position.distance_to(pp) < 1.8:
			match pk["kind"]:
				"med":
					hp = minf(100.0, hp + 25.0)
					hud.toast("Medkit +25 HP")
				"ammo":
					reserve += 30
					hud.toast("Ammo +30")
				"drop":
					hp = minf(100.0, hp + 50.0)
					reserve += 60
					hud.toast("Supply drop: +50 HP, +60 ammo")
			node.queue_free()
			pickups.remove_at(i)

func _sim_attrition(delta: float) -> void:
	# Simulates fights between bots far from the player so a match ends in a few minutes.
	if mode == "training":
		return
	attr_t -= delta
	if attr_t > 0.0:
		return
	attr_t = rng.randf_range(4.0, 7.0)
	if elapsed < 20.0:
		return
	var far: Array = []
	for b in bots:
		if b.alive and b.node.global_position.distance_to(player.global_position) > 70.0:
			far.append(b)
	if far.size() >= 2:
		_kill_bot(far[rng.randi() % far.size()], false)

# ------------------------------------------------------------------ match end
func _alive_count() -> int:
	var n := 1
	for b in bots:
		if b.alive:
			n += 1
	return n

func _check_end() -> void:
	if mode == "training":
		hp = 100.0
		return
	if hp <= 0.0:
		_finish(false)
	elif _alive_count() <= 1:
		_finish(true)

func _finish(win: bool) -> void:
	if finished:
		return
	finished = true
	var place := 1 if win else _alive_count()
	var gained := kills * 3
	if win:
		gained += 40
	elif place <= 5:
		gained += 20
	elif place <= 15:
		gained += 5
	else:
		gained -= 5
	var old_rp := Settings.rp
	Settings.rp = maxi(0, Settings.rp + gained)
	Settings.matches += 1
	Settings.kills += kills
	if win:
		Settings.wins += 1
	Settings.save_all()
	var tier: String = Settings.TIERS[Settings.tier_index()]
	result_label.text = "%s\nPlacement #%d of 30\nEliminations: %d\nRank points: %+d  (%s, %d RP)" % ["VICTORY!" if win else "ELIMINATED", place, kills, Settings.rp - old_rp, tier, Settings.rp]
	result_panel.visible = true
