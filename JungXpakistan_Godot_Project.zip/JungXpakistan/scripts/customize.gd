extends Control
## Control layout editor: drag buttons, resize, opacity, sensitivity, save / reset.

signal closed

const Settings = preload("res://scripts/settings.gd")
const LABELS := {"stick": "MOVE", "fire": "FIRE", "jump": "JUMP", "crouch": "CROUCH", "reload": "RELOAD", "skill1": "SKILL 1", "skill2": "SKILL 2", "skill3": "SKILL 3"}

var drag_name := ""
var sel := "fire"
var size_slider: HSlider

func _ready() -> void:
	Settings.load_all()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	var panel := PanelContainer.new()
	panel.position = Vector2(150, 8)
	add_child(panel)
	var row := HBoxContainer.new()
	panel.add_child(row)
	size_slider = _col(row, "Selected button size", 0.5, 1.8, Settings.layout[sel][2], _on_size)
	_col(row, "Button opacity", 0.2, 1.0, Settings.opacity, _on_opacity)
	_col(row, "Camera sensitivity", 0.3, 2.5, Settings.cam_sens, func(v): Settings.cam_sens = v)
	_col(row, "Aim sensitivity", 0.3, 2.5, Settings.aim_sens, func(v): Settings.aim_sens = v)
	var save := Button.new()
	save.text = "SAVE"
	save.pressed.connect(func(): Settings.save_all())
	row.add_child(save)
	var reset := Button.new()
	reset.text = "RESET"
	reset.pressed.connect(func():
		Settings.reset_layout()
		size_slider.set_value_no_signal(Settings.layout[sel][2])
		queue_redraw())
	row.add_child(reset)
	var close := Button.new()
	close.text = "CLOSE"
	close.pressed.connect(func():
		Settings.save_all()
		closed.emit())
	row.add_child(close)

func _on_size(v: float) -> void:
	Settings.layout[sel][2] = v
	queue_redraw()

func _on_opacity(v: float) -> void:
	Settings.opacity = v
	queue_redraw()

func _col(row: Control, text: String, lo: float, hi: float, val: float, cb: Callable) -> HSlider:
	var v := VBoxContainer.new()
	var l := Label.new()
	l.text = text
	v.add_child(l)
	var s := HSlider.new()
	s.min_value = lo
	s.max_value = hi
	s.step = 0.01
	s.value = val
	s.custom_minimum_size = Vector2(150, 28)
	s.value_changed.connect(cb)
	v.add_child(s)
	row.add_child(v)
	return s

func _center(bn: String) -> Vector2:
	var l: Array = Settings.layout[bn]
	return Vector2(l[0] * size.x, l[1] * size.y)

func _radius(bn: String) -> float:
	var l: Array = Settings.layout[bn]
	return (70.0 if bn == "stick" else 44.0) * l[2]

func _pick(p: Vector2) -> String:
	for bn in Settings.BUTTONS:
		if p.distance_to(_center(bn)) <= _radius(bn):
			return bn
	return ""

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			drag_name = _pick(event.position)
			if drag_name != "":
				sel = drag_name
				size_slider.set_value_no_signal(Settings.layout[sel][2])
				queue_redraw()
		else:
			drag_name = ""
	elif event is InputEventMouseMotion and drag_name != "":
		Settings.layout[drag_name][0] = clampf(event.position.x / size.x, 0.05, 0.95)
		Settings.layout[drag_name][1] = clampf(event.position.y / size.y, 0.18, 0.95)
		queue_redraw()

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.03, 0.03, 0.08, 0.92))
	var font := ThemeDB.fallback_font
	for bn in Settings.BUTTONS:
		var c := _center(bn)
		var r := _radius(bn)
		var col := Color(1, 0.8, 0.2) if bn == sel else Color(0.5, 0.7, 1.0)
		draw_circle(c, r, Color(col, Settings.opacity * 0.6))
		draw_arc(c, r, 0, TAU, 32, Color(1, 1, 1, Settings.opacity), 2.0)
		draw_string(font, c + Vector2(-r, 6), LABELS[bn], HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 15)
	draw_string(font, Vector2(20, size.y - 14), "Drag a button to move it. Tap to select, then use the size slider.", HORIZONTAL_ALIGNMENT_LEFT, -1, 16)
