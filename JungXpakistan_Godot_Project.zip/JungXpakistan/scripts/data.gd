extends RefCounted
## Original characters and their 3-slot Skill Hub.
## kinds: dash, shield, heal, speed, radar, blast (implemented in game.gd)

const CHARS := [
	{
		"name": "Rafi", "gender": "Male",
		"shirt": Color(0.15, 0.50, 0.32), "pants": Color(0.12, 0.12, 0.17), "skin": Color(0.66, 0.47, 0.34),
		"skills": [
			{"name": "Dash", "kind": "dash", "cd": 6.0, "desc": "Burst forward quickly to dodge fire or close distance."},
			{"name": "Shield Pulse", "kind": "shield", "cd": 14.0, "desc": "Take 70% less damage for 3 seconds."},
			{"name": "Heal Wave", "kind": "heal", "cd": 18.0, "desc": "Instantly restore 30 HP."},
		],
	},
	{
		"name": "Nila", "gender": "Female",
		"shirt": Color(0.55, 0.20, 0.55), "pants": Color(0.10, 0.14, 0.22), "skin": Color(0.72, 0.52, 0.38),
		"skills": [
			{"name": "Sprint", "kind": "speed", "cd": 10.0, "desc": "Move 60% faster for 4 seconds."},
			{"name": "Radar", "kind": "radar", "cd": 20.0, "desc": "Reveal all enemy directions on the minimap for 5 seconds."},
			{"name": "Shock Blast", "kind": "blast", "cd": 16.0, "desc": "Damage every enemy within 8 metres (40 damage)."},
		],
	},
]
