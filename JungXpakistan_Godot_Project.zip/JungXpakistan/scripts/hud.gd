extends Control
## On-screen touch controls + HUD. Handles raw multi-touch itself.

const Settings = preload("res://scripts/settings.gd")

var game
var move_vec := Vector2.ZERO
var look_delta := Vector2.ZERO
var held := {}
var taps := {}
var touches := {}   # touch index -> role ("stick", "look" or button name)
var toast_text := ""
var toast_t := 0.0
var hit_flash := 0.0
var dmg_flash := 0.0

const LABELS := {"fire": "FIRE", "jump": "JUMP", "crouch": "CROUCH", "reload": "RELOAD"}
const COLORS := {"fire": Color(1.0, 0.35, 0.2), "jump": Color(0.3, 0.7, 1.0), "crouch": Color(0.3, 0.7, 1.0), "reload": Color(0.9, 0.9, 0.3), "skill1": Color(0.7, 0.4, 1.0), "skill2": Color(0.7, 0.4, 1.0), "skill3": Color(0.7, 0.4, 1.0)}

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	for b in Settings.BUTTONS:
		held[b] = false

func take(bn: String) -> bool:
	if taps.get(bn, false):
		taps[bn] = false
		return true
	return false

func toast(t: String) -> void:
	toast_text = t
	toast_t = 3.0

func btn_center(bn: String) -> Vector2:
	var l: Array = Settings.layout[bn]
	return Vector2(l[0] * size.x, l[1] * size.y)

func btn_radius(bn: String) -> float:
	var l: Array = Settings.layout[bn]
	return (70.0 if bn == "stick" else 44.0) * l[2]

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			_press(event.index, event.position)
		else:
			_release(event.index)
	elif event is InputEventScreenDrag:
		_drag(event.index, event.position, event.relative)

func _press(idx: int, p: Vector2) -> void:
	for bn in Settings.BUTTONS:
		if bn == "stick":
			continue
		if p.distance_to(btn_center(bn)) <= btn_radius(bn) * 1.15:
			touches[idx] = bn
			held[bn] = true
			taps[bn] = true
			return
	if p.x < size.x * 0.45 and not touches.values().has("stick"):
		touches[idx] = "stick"
		_drag(idx, p, Vector2.ZERO)
	else:
		touches[idx] = "look"

func _drag(idx: int, p: Vector2, rel: Vector2) -> void:
	var role: String = touches.get(idx, "")
	if role == "stick":
		var v := (p - btn_center("stick")) / btn_radius("stick")
		move_vec = v.limit_length(1.0)
	elif role == "look":
		look_delta += rel

func _release(idx: int) -> void:
	var role: String = touches.get(idx, "")
	if role == "stick":
		move_vec = Vector2.ZERO
	elif role != "" and role != "look":
		held[role] = false
	touches.erase(idx)

func _process(delta: float) -> void:
	toast_t = maxf(0.0, toast_t - delta)
	hit_flash = maxf(0.0, hit_flash - delta)
	dmg_flash = maxf(0.0, dmg_flash - delta)
	queue_redraw()

func _draw() -> void:
	if game == null or game.chardata.is_empty():
		return
	var font := ThemeDB.fallback_font
	var op: float = Settings.opacity
	var white := Color(1, 1, 1, minf(1.0, op + 0.2))

	if dmg_flash > 0.0:
		draw_rect(Rect2(Vector2.ZERO, size), Color(1, 0, 0, dmg_flash * 0.8))

	# stick
	var sc := btn_center("stick")
	var sr := btn_radius("stick")
	draw_circle(sc, sr, Color(1, 1, 1, op * 0.25))
	draw_arc(sc, sr, 0, TAU, 40, Color(1, 1, 1, op), 2.0)
	draw_circle(sc + move_vec * sr * 0.6, sr * 0.35, Color(1, 1, 1, op * 0.7))

	# buttons
	for bn in Settings.BUTTONS:
		if bn == "stick":
			continue
		var c := btn_center(bn)
		var r := btn_radius(bn)
		var text: String = ""
		var cd := 0.0
		if bn.begins_with("skill"):
			var i: int = bn.substr(5).to_int() - 1
			text = game.chardata["skills"][i]["name"]
			cd = game.skill_cd[i]
		else:
			text = LABELS[bn]
		var col: Color = COLORS[bn]
		if held[bn]:
			col = col.lightened(0.4)
		draw_circle(c, r, Color(col, op * 0.6))
		draw_arc(c, r, 0, TAU, 32, Color(1, 1, 1, op), 2.0)
		draw_string(font, c + Vector2(-r, 5), text, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 14, white)
		if cd > 0.0:
			draw_circle(c, r, Color(0, 0, 0, 0.6))
			draw_string(font, c + Vector2(-r, 10), "%d" % ceili(cd), HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 26, Color(1, 1, 1))

	# ammo
	var ammo_text: String = "RELOADING..." if game.reloading > 0.0 else "%d / %s" % [game.ammo, "INF" if game.mode == "training" else str(game.reserve)]
	draw_string(font, btn_center("fire") + Vector2(-70, -btn_radius("fire") - 12), ammo_text, HORIZONTAL_ALIGNMENT_CENTER, 140, 22, Color(1, 1, 1))

	# crosshair
	var m := size / 2.0
	var cc := Color(1, 1, 1, 0.85)
	draw_line(m + Vector2(-14, 0), m + Vector2(-5, 0), cc, 2.0)
	draw_line(m + Vector2(14, 0), m + Vector2(5, 0), cc, 2.0)
	draw_line(m + Vector2(0, -14), m + Vector2(0, -5), cc, 2.0)
	draw_line(m + Vector2(0, 14), m + Vector2(0, 5), cc, 2.0)
	if hit_flash > 0.0:
		var hc := Color(1, 0.2, 0.2)
		draw_line(m + Vector2(-9, -9), m + Vector2(9, 9), hc, 3.0)
		draw_line(m + Vector2(9, -9), m + Vector2(-9, 9), hc, 3.0)

	# top info
	var info: String = "TRAINING GROUND" if game.mode == "training" else "ALIVE %d   |   ELIMINATIONS %d" % [game._alive_count(), game.kills]
	draw_string(font, Vector2(0, 30), info, HORIZONTAL_ALIGNMENT_CENTER, size.x, 24, Color(1, 1, 1))
	if game.mode != "training":
		var zt: String = ("ZONE SHRINKING!" if game.zone_shrinking else "Zone shrinks in %ds" % ceili(game.zone_timer)) if game.zone_stage < game.ZONE_RADII.size() else "FINAL ZONE"
		draw_string(font, Vector2(0, 54), zt, HORIZONTAL_ALIGNMENT_CENTER, size.x, 18, Color(0.5, 0.8, 1.0))
	if toast_t > 0.0:
		draw_string(font, Vector2(0, 90), toast_text, HORIZONTAL_ALIGNMENT_CENTER, size.x, 22, Color(1, 0.9, 0.4))

	# HP bar
	var bw := 300.0
	var bx := size.x / 2.0 - bw / 2.0
	var by := size.y - 30.0
	draw_rect(Rect2(bx, by, bw, 16), Color(0, 0, 0, 0.5))
	draw_rect(Rect2(bx, by, bw * clampf(game.hp / 100.0, 0.0, 1.0), 16), Color(0.3, 0.9, 0.4))
	draw_string(font, Vector2(bx, by - 4), "HP %d" % ceili(maxf(game.hp, 0.0)), HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(1, 1, 1))

	# minimap (north-up): enemies within ~70 m, or all directions while Radar is on
	var mc := Vector2(95, 110)
	draw_circle(mc, 70, Color(0, 0, 0, 0.45))
	draw_arc(mc, 70, 0, TAU, 40, Color(1, 1, 1, 0.6), 2.0)
	var pp := Vector2(game.player.global_position.x, game.player.global_position.z)
	for b in game.bots:
		if not b.alive:
			continue
		var bp := Vector2(b.node.global_position.x, b.node.global_position.z)
		var rel := (bp - pp) * 0.9
		if rel.length() < 66.0:
			draw_circle(mc + rel, 3, Color(1, 0.3, 0.3))
		elif game.radar_t > 0.0:
			draw_circle(mc + rel.limit_length(66.0), 3, Color(1, 0.6, 0.2))
	var fwd := Vector2(-sin(game.yaw), -cos(game.yaw))
	draw_circle(mc, 4, Color(0.3, 1, 0.4))
	draw_line(mc, mc + fwd * 15.0, Color(0.3, 1, 0.4), 2.0)
	if game.mode != "training":
		var zc: Vector2 = game.zone_center
		var to_z := zc - pp
		var inside: bool = to_z.length() <= game.zone_radius
		draw_line(mc, mc + to_z.normalized() * 55.0, Color(0.4, 0.7, 1.0), 2.0)
		draw_string(font, mc + Vector2(-70, 92), ("IN ZONE" if inside else "OUTSIDE ZONE!") + "  %dm" % int(to_z.length()), HORIZONTAL_ALIGNMENT_CENTER, 140, 14, Color(0.4, 1, 0.5) if inside else Color(1, 0.4, 0.4))
