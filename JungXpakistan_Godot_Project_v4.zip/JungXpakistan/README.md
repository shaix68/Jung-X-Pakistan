# JungXpakistan (Godot 4.3 prototype)

Original 3D battle-royale prototype. Single-player vs 29 AI bots (30 players per match).
Art is placeholder primitives (no imported assets). Layout is inspired by the genre, not copied from any game.

## STATUS (honest)
| Feature | State |
|---|---|
| Lobby: 16 characters (grid picker), Skill Hub (passive + active), free-skill equip for Primis/Nulla, rank, missions | Runs (headless-tested + screenshot) |
| Bangalia map section (village, city, abandoned buildings, river, bridge, farmland, hills, trees) | Written, NOT yet run |
| Touch controls + default HUD matching the reference "HUD 2" layout: move, look, fire, scope, jump, crouch, prone, reload, swap weapon, grenade, medkit, skills | Runs (headless-tested + screenshot) |
| Control editor: move/resize buttons, opacity, sensitivity, save/load/reset | Written, NOT yet run |
| Weapon: ammo, reload, recoil, hitscan, 40% aim assist (~1.5 m) | Written, NOT yet run |
| Safe zone, loot (medkits, ammo), supply drop, 29 AI bots, results, RP + ranks | Written, NOT yet run |
| Training ground | Written, NOT yet run |
| Online multiplayer, custom rooms, matchmaking, Duo/Squad, AI assistant, anti-cheat | NOT implemented (see docs/ARCHITECTURE.md) |
| APK | Not built here (no Android SDK in my environment). `.github/workflows/build-apk.yml` builds it on GitHub Actions |

Update (v2): this version was loaded in Godot 4.3 headless and in a software-rendered window, all 16 characters
were started in a match and each ability was exercised by a test script. It has NOT been tested by touch on a phone
and no APK was built here.

## Run on PC first (fastest way to test)
1. Download Godot 4.3 (standard, not .NET) from godotengine.org.
2. Open Godot > Import > select `project.godot` > Open.
3. Press F5. Mouse clicks act as touch (drag the left side = move, right side = look, click buttons).

## Build the APK
1. Install JDK 17 and the Android SDK (easiest: install Android Studio once, then SDK Manager: Platform 34,
   Build-Tools 34.0.0, Platform-Tools, Command-line Tools, CMake, NDK).
2. Godot: Editor > Editor Settings > Export > Android: set Android SDK Path and Java SDK Path
   (and create a debug keystore: `keytool -keyalg RSA -genkeypair -alias androiddebugkey -keypass android -keystore debug.keystore -storepass android -dname "CN=Android Debug,O=Android,C=US" -validity 9999`
   then set it in the same settings page, user `androiddebugkey`, password `android`).
3. Editor > Manage Export Templates > Download and Install.
4. Project > Export > Add... > Android. Set Package > Unique Name to `com.jungxpakistan.game`.
5. Click "Export Project", untick "Export With Debug" only for release builds, save as `JungXpakistan.apk`.
6. Copy the APK to your phone and install (allow "install unknown apps").
Exact SDK/NDK versions change per Godot release: follow docs.godotengine.org > "Exporting for Android" for 4.3.

## Files
- scripts/main.gd: lobby <-> match switch
- scripts/lobby.gd, customize.gd: menus
- scripts/game.gd: world, player, bots, zone, skills, loot
- scripts/hud.gd: touch controls + HUD
- scripts/settings.gd: saved settings, layout, rank (user://save.cfg)
- scripts/data.gd: characters + skills


## v2: characters, abilities, HUD
Characters (from the reference screenshots/video): Hayato, Primis, Kla, Andrew, Moco, Caroline, Maxim, Tatsuya, Alok,
Wolfrahh, Skyler, Nulla, Chrono, Kelly (+ original Rafi, Nila). Models are still placeholder primitives (no game art).

| Character | Ability | How it works here |
|---|---|---|
| Hayato | Art of Blades (passive) | Lower HP: up to +50% damage dealt, up to -30% damage taken from the front |
| Primis, Nulla | No skill | Equip any other character's ability in the lobby (CHANGE EQUIPPED SKILL) |
| Kla | Muay Thai (passive) | Fist damage x5 (SWAP button cycles Rifle / Shotgun / Fist) |
| Andrew | Wolf Pack (passive) | Solo has no teammates: fixed 15% damage reduction |
| Moco | Enigma's Eye (passive) | Enemies you hit are marked 6 s (above head + minimap) |
| Caroline | Agility (passive) | +16% move speed while holding the shotgun |
| Maxim | Gluttony (passive) | Medkit use 25% faster (mushrooms not in prototype) |
| Wolfrahh | Limelight (passive) | Headshots x2.4 instead of x1.8; no extra headshot damage taken |
| Kelly | Ultra Velocity (passive) | Sprint (hold stick fully 0.6 s) is faster; first shot after sprinting +60% |
| Tatsuya | Rebel Rush (active) | Rush forward (40 dmg to enemies hit); a kill within 3 s resets the cooldown |
| Alok | Party Remix (active) | +30 HP over 5 s and +15% speed (music notes for teammates need squads) |
| Skyler | Riptide Rhythm (active) | Sonic wave, 45 dmg to enemies in an 18 m cone (no Gloo Walls in prototype) |
| Chrono | Time Turner (active) | 5 s force field, 90% less damage while standing inside |

New systems added for those abilities: shotgun + fist, headshots, scope, prone, sprint, medkit inventory (channeled heal),
grenades, EP (extra shield, +25 per kill), kill feed. Default control layout is now the "HUD 2" layout; the old saved
layout is ignored once (layout version 2), and RESET in Customize Controls restores the default.
Bug fixed: the HUD control had size 0 under the CanvasLayer in v1, so it is now sized to the screen every frame.

## v3: Armory (WEAPON) and Vault
Lobby now has WEAPON and VAULT buttons (top of the lobby).

**Armory** - categories like the reference: Rifle, Marksman Rifle, Machine Gun, SMG, Shotgun, Sniper, Pistol, Melee, Fist,
Grenade (Grenade, Smoke Grenade, Gloo Wall), Others (Crossbow). 55 weapons, 8 stat bars each, skin strip, GALLERY grid with
rarity filter (Artifact / Mythic / Epic / Rare / Uncommon), EQUIP buttons.
- Loadout: Primary 1, Primary 2, Pistol, Melee, Throwable. The in-match SWAP button cycles P1 > P2 > Pistol > Melee.
- The stat bars drive real gameplay (damage, fire rate, range, spread, magazine, reload, move speed). Bar values and skin
  rarities are my approximations from the screenshots, not official numbers. Armor Penetration only affects Gloo Walls.
- Gloo Wall: placed in front of you, 300 HP, 30 s, blocks bullets for you and enemies; Skyler's wave and grenades break it.
- Smoke Grenade: enemies lose sight of you while you stand in the smoke (8 s).
- Gun models are placeholder blocks; skins are colour variants only (no real weapon art).

**Vault** - Fashion (top, bottom, shoes, hair, face/head) changes the selected character's look in lobby and match.
Profile and Collection show real stats. Emote, Posture, Skill Skin, Vehicle, Others are listed but empty (not implemented).

## v4: build the APK with GitHub Actions
1. Create a GitHub repo and upload this whole project (the `.github/workflows/build-apk.yml` file must stay in place).
2. Repo > Actions > "Build Android APK" > Run workflow (it also runs on every push to main/master).
3. When it is green, open the run and download the artifact `JungXpakistan-apk` (zip with `JungXpakistan.apk`).
4. Copy the APK to the phone, allow "install unknown apps", install.
The APK is a debug build signed with an auto-generated debug key (arm64 + armv7). The workflow has not been run by me, so
if a step fails, send the red log lines. Play Store release signing is not set up.
