extends Node3D
## Match scene: Bangalia map section, player, 29 AI bots (30 total), safe zone, loot, skills.
## NOTE: single-player prototype. Multiplayer needs a dedicated server (see docs/ARCHITECTURE.md).

signal exit_to_lobby

const Settings = preload("res://scripts/settings.gd")
const Data = preload("res://scripts/data.gd")
const Model = preload("res://scripts/character_model.gd")
const HudScript = preload("res://scripts/hud.gd")

const MAP_HALF := 190.0
const GUN_RANGE := 120.0
const Weapons = preload("res://scripts/weapons.gd")
const Outfit = preload("res://scripts/outfit.gd")
const SLOTS := ["p1", "p2", "pistol", "melee"]   # swap order
const EP_MAX := 250.0
const MEDKIT_TIME := 3.0
const AIM_ASSIST_RANGE := 1.5
const ZONE_RADII := [180.0, 115.0, 65.0, 30.0, 10.0]
const HUBS := [Vector2(70, 70), Vector2(-110, -100), Vector2(105, -110)]

var mode := "solo"
var chardata: Dictionary = {}
var rng := RandomNumberGenerator.new()
var space: PhysicsDirectSpaceState3D

var player: CharacterBody3D
var cam_pivot: Node3D
var cam: Camera3D
var player_model: Node3D
var shield_node: MeshInstance3D
var hud

var hp := 100.0
var weapon := "p1"           # current slot: p1, p2, pistol, melee
var loadout := {}            # slot -> weapon stats (see weapons.gd)
var wstate := {}             # slot -> {ammo, reserve}
var ammo: int:
	get: return wstate[weapon]["ammo"]
	set(v): wstate[weapon]["ammo"] = v
var reserve: int:
	get: return wstate[weapon]["reserve"]
	set(v): wstate[weapon]["reserve"] = v
var held_model: Node3D
var gloo_walls: Array = []
var smokes: Array = []
var reloading := 0.0
var fire_cd := 0.0
var yaw := 0.0
var pitch := -0.1
var vel_y := 0.0
var crouching := false
var dash_t := 0.0
var dash_dir := Vector3.ZERO
var shield_t := 0.0
var speed_t := 0.0
var radar_t := 0.0
var skill_cd := [0.0, 0.0, 0.0]
var pk := ""                 # passive kind of the current character
var ep := 0.0                # energy points: extra shield that absorbs damage before HP
var medkits := 1
var grenades := 3
var use_t := 0.0             # medkit channel time left
var use_total := MEDKIT_TIME
var scoped := false
var prone := false
var sprint_hold := 0.0
var sprint_len := 0.0
var sprinting := false
var bonus_t := 0.0           # Kelly: first-shot bonus window after sprinting
var remix_t := 0.0           # Alok: heal over time
var field_t := 0.0           # Chrono: force field
var field_pos := Vector3.ZERO
var field_node: MeshInstance3D
var rush_dash := false       # Tatsuya: rush in progress
var rush_idx := -1
var rush_window := 0.0
var rush_hit: Array = []
var feed: Array = []         # kill feed entries {t, text}
var kills := 0
var elapsed := 0.0
var finished := false
var attr_t := 6.0
var drop_spawned := false

var bots: Array = []
var pickups: Array = []

var zone_center := Vector2.ZERO
var zone_radius := 280.0
var zone_stage := 0
var zone_timer := 25.0
var zone_shrinking := false
var zone_from := 280.0
var zone_to := 180.0
var zone_c_from := Vector2.ZERO
var zone_c_to := Vector2.ZERO
var zone_node: MeshInstance3D

var sfx_shot: AudioStreamPlayer
var sfx_skill: AudioStreamPlayer
var sfx_hit: AudioStreamPlayer
var result_panel: PanelContainer
var result_label: Label

func _ready() -> void:
	Settings.load_all()
	rng.randomize()
	var base_name: String = Data.CHARS[clampi(Settings.char_idx, 0, Data.CHARS.size() - 1)]["name"]
	chardata = Outfit.apply(Data.effective(Settings.char_idx, Settings.free_idx), Outfit.get_sel(Settings.outfits, base_name))
	pk = chardata["passive"].get("kind", "")
	_build_world()
	_build_player()
	_init_loadout()
	_spawn_bots()
	_spawn_pickups()
	_build_zone()
	_build_ui()
	_make_audio()
	if mode == "training":
		hud.toast("Training ground: infinite ammo, dummy bots, no zone")
	else:
		hud.toast("Match started: be the last one alive!")

# ------------------------------------------------------------------ world
func _box(pos: Vector3, sz: Vector3, color: Color, collide := true) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = sz
	mi.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	mi.material_override = m
	body.add_child(mi)
	if collide:
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = sz
		cs.shape = sh
		body.add_child(cs)
	add_child(body)
	return body

func _house(c: Vector3, w: float, d: float, h: float, col: Color) -> void:
	var t := 0.3
	var door := 2.2
	_box(c + Vector3(0, h / 2.0, -d / 2.0), Vector3(w, h, t), col)
	_box(c + Vector3(-w / 2.0, h / 2.0, 0), Vector3(t, h, d), col)
	_box(c + Vector3(w / 2.0, h / 2.0, 0), Vector3(t, h, d), col)
	var half := (w - door) / 2.0
	_box(c + Vector3(-(door / 2.0 + half / 2.0), h / 2.0, d / 2.0), Vector3(half, h, t), col)
	_box(c + Vector3(door / 2.0 + half / 2.0, h / 2.0, d / 2.0), Vector3(half, h, t), col)
	_box(c + Vector3(0, 2.4 + (h - 2.4) / 2.0, d / 2.0), Vector3(door, h - 2.4, t), col)
	_box(c + Vector3(0, h + 0.15, 0), Vector3(w + 0.6, 0.3, d + 0.6), col.darkened(0.45))

func _tree(p: Vector3) -> void:
	var body := StaticBody3D.new()
	body.position = p
	var trunk := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.22
	cm.bottom_radius = 0.28
	cm.height = 3.0
	trunk.mesh = cm
	trunk.position = Vector3(0, 1.5, 0)
	var tm := StandardMaterial3D.new()
	tm.albedo_color = Color(0.35, 0.22, 0.12)
	trunk.material_override = tm
	body.add_child(trunk)
	var canopy := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 1.7
	sm.height = 3.4
	canopy.mesh = sm
	canopy.position = Vector3(0, 4.0, 0)
	var gm := StandardMaterial3D.new()
	gm.albedo_color = Color(0.12, 0.45, 0.15)
	canopy.material_override = gm
	body.add_child(canopy)
	var cs := CollisionShape3D.new()
	var sh := CylinderShape3D.new()
	sh.radius = 0.35
	sh.height = 3.0
	cs.shape = sh
	cs.position = Vector3(0, 1.5, 0)
	body.add_child(cs)
	add_child(body)

func _build_world() -> void:
	# sky, light, ambient
	var we := WorldEnvironment.new()
	var env := Environment.new()
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sky.sky_material = sm
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, -30, 0)
	sun.shadow_enabled = not Settings.low_end
	add_child(sun)

	# ground + farmland
	_box(Vector3(0, -0.5, 0), Vector3(400, 1, 400), Color(0.33, 0.55, 0.24))
	for i in 10:
		var fp := Vector3(rng.randf_range(-170, 170), 0.02, rng.randf_range(-170, 170))
		if absf(fp.x + 40.0) < 14.0:
			continue
		_box(fp, Vector3(rng.randf_range(18, 34), 0.04, rng.randf_range(14, 24)), Color(0.55, 0.45, 0.2).lerp(Color(0.4, 0.6, 0.2), rng.randf()), false)
	# roads
	_box(Vector3(0, 0.03, 0), Vector3(400, 0.05, 6), Color(0.18, 0.18, 0.2), false)
	_box(Vector3(60, 0.03, 0), Vector3(6, 0.05, 400), Color(0.18, 0.18, 0.2), false)
	# river + bridge (river slows movement except on the bridge band)
	_box(Vector3(-40, 0.04, 0), Vector3(14, 0.06, 400), Color(0.15, 0.4, 0.75), false)
	_box(Vector3(-40, 0.09, 0), Vector3(16, 0.08, 8), Color(0.4, 0.28, 0.15), false)
	# distant hills (decoration beyond the playable edge)
	for i in 12:
		var a := TAU * float(i) / 12.0
		var hill := MeshInstance3D.new()
		var hs := SphereMesh.new()
		hill.mesh = hs
		var hm := StandardMaterial3D.new()
		hm.albedo_color = Color(0.25, 0.4, 0.25)
		hill.material_override = hm
		hill.scale = Vector3(45, 28, 45)
		hill.position = Vector3(cos(a) * 235.0, -4.0, sin(a) * 235.0)
		add_child(hill)

	# village (houses)
	for ix in 4:
		for iz in 3:
			var hc := Vector3(45.0 + ix * 16.0, 0, 45.0 + iz * 16.0)
			_house(hc, rng.randf_range(7, 10), rng.randf_range(6, 9), 3.2, Color(0.75, 0.55, 0.35))
	# city (tall buildings)
	for ix in 3:
		for iz in 3:
			var cc := Vector3(-135.0 + ix * 26.0, 0, -125.0 + iz * 26.0)
			_house(cc, 14, 14, rng.randf_range(8, 17), Color(0.6, 0.62, 0.66))
	# abandoned buildings
	for i in 5:
		_house(Vector3(85.0 + (i % 3) * 18.0, 0, -125.0 + (i / 3) * 22.0), 9, 8, 3.4, Color(0.3, 0.28, 0.27))
	# trees
	var tree_count := 35 if Settings.low_end else 110
	for i in tree_count:
		var tp := Vector3(rng.randf_range(-MAP_HALF, MAP_HALF), 0, rng.randf_range(-MAP_HALF, MAP_HALF))
		if absf(tp.x + 40.0) < 10.0 or tp.length() < 15.0:
			continue
		var near_hub := false
		for h in HUBS:
			if Vector2(tp.x, tp.z).distance_to(h) < 38.0:
				near_hub = true
		if not near_hub:
			_tree(tp)

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.position = Vector3(0, 0.1, 8)
	player.collision_layer = 4
	player.collision_mask = 1
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.8
	cs.shape = cap
	cs.position = Vector3(0, 0.9, 0)
	player.add_child(cs)
	player_model = Model.build(chardata)
	player.add_child(player_model)
	shield_node = MeshInstance3D.new()
	var sph := SphereMesh.new()
	sph.radius = 1.1
	sph.height = 2.2
	shield_node.mesh = sph
	var shm := StandardMaterial3D.new()
	shm.albedo_color = Color(0.3, 0.8, 1.0, 0.3)
	shm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	shm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	shield_node.material_override = shm
	shield_node.position = Vector3(0, 1.0, 0)
	shield_node.visible = false
	player.add_child(shield_node)
	add_child(player)
	cam_pivot = Node3D.new()
	cam_pivot.position = Vector3(0, 1.5, 0)
	player.add_child(cam_pivot)
	cam = Camera3D.new()
	cam.position = Vector3(0.7, 0.3, 3.4)
	cam.fov = 70.0
	cam_pivot.add_child(cam)
	cam.current = true

func _random_spawn(min_player_dist: float) -> Vector3:
	for i in 20:
		var p := Vector3(rng.randf_range(-MAP_HALF + 10.0, MAP_HALF - 10.0), 0.5, rng.randf_range(-MAP_HALF + 10.0, MAP_HALF - 10.0))
		if absf(p.x + 40.0) < 9.0:
			continue
		if p.distance_to(player.global_position) > min_player_dist:
			return p
	return Vector3(50, 0.5, -50)

func _spawn_bots() -> void:
	var n := 6 if mode == "training" else 29
	for i in n:
		var node := CharacterBody3D.new()
		node.collision_layer = 2
		node.collision_mask = 1
		var cs := CollisionShape3D.new()
		var cap := CapsuleShape3D.new()
		cap.radius = 0.35
		cap.height = 1.8
		cs.shape = cap
		cs.position = Vector3(0, 0.9, 0)
		node.add_child(cs)
		var look := {"gender": "Male" if i % 2 == 0 else "Female", "shirt": Color.from_hsv(rng.randf(), 0.6, 0.7), "pants": Color(0.15, 0.15, 0.18), "skin": Color(0.6, 0.42, 0.3).lerp(Color(0.8, 0.6, 0.45), rng.randf())}
		node.add_child(Model.build(look))
		var p := Vector3.ZERO
		if mode == "training":
			var a := TAU * float(i) / float(n)
			p = player.global_position + Vector3(cos(a) * 18.0, 0.3, sin(a) * 18.0)
		else:
			p = _random_spawn(40.0)
		node.position = p
		add_child(node)
		bots.append({"name": "Player %d" % (i + 2), "mark_t": 0.0, "node": node, "hp": 100.0, "alive": true, "cd": rng.randf_range(0.5, 2.0), "wander": p, "wt": 0.0})

func _spawn_pickups() -> void:
	for i in 45:
		var kind := "med" if i % 3 == 0 else ("gren" if i % 7 == 0 else "ammo")
		var p := _random_spawn(10.0)
		_make_pickup(p + Vector3(0, 0.3, 0), kind)

func _make_pickup(p: Vector3, kind: String) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.5, 0.5, 0.5) if kind != "drop" else Vector3(1.2, 1.2, 1.2)
	mi.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = {"med": Color(0.2, 0.9, 0.3), "ammo": Color(0.95, 0.8, 0.2), "gren": Color(0.45, 0.6, 0.3), "drop": Color(1.0, 0.75, 0.1)}[kind]
	m.emission_enabled = true
	m.emission = m.albedo_color
	m.emission_energy_multiplier = 0.6
	mi.material_override = m
	mi.position = p
	add_child(mi)
	if kind == "drop":
		var beam := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 0.2
		cm.bottom_radius = 0.2
		cm.height = 60.0
		beam.mesh = cm
		var bmat := StandardMaterial3D.new()
		bmat.albedo_color = Color(1, 0.8, 0.2, 0.5)
		bmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		bmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		beam.material_override = bmat
		beam.position = Vector3(0, 30, 0)
		mi.add_child(beam)
	pickups.append({"node": mi, "kind": kind})

func _build_zone() -> void:
	zone_node = MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.0
	cm.bottom_radius = 1.0
	cm.height = 80.0
	cm.radial_segments = 48
	cm.rings = 1
	zone_node.mesh = cm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.2, 0.5, 1.0, 0.16)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	zone_node.material_override = m
	zone_node.position = Vector3(0, 30, 0)
	zone_node.scale = Vector3(zone_radius, 1, zone_radius)
	zone_node.visible = mode != "training"
	add_child(zone_node)

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	hud = HudScript.new()
	hud.game = self
	layer.add_child(hud)
	var leave := Button.new()
	leave.text = "LEAVE"
	leave.anchor_left = 1.0
	leave.anchor_right = 1.0
	leave.offset_left = -110.0
	leave.offset_right = -10.0
	leave.offset_top = 8.0
	leave.offset_bottom = 48.0
	leave.pressed.connect(func():
		Settings.save_all()
		exit_to_lobby.emit())
	layer.add_child(leave)
	result_panel = PanelContainer.new()
	result_panel.visible = false
	result_panel.set_anchors_preset(Control.PRESET_CENTER)
	result_panel.custom_minimum_size = Vector2(420, 220)
	result_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	result_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	var box := VBoxContainer.new()
	result_label = Label.new()
	result_label.add_theme_font_size_override("font_size", 26)
	result_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(result_label)
	var back := Button.new()
	back.text = "BACK TO LOBBY"
	back.custom_minimum_size = Vector2(0, 56)
	back.pressed.connect(func(): exit_to_lobby.emit())
	box.add_child(back)
	result_panel.add_child(box)
	layer.add_child(result_panel)

# ------------------------------------------------------------------ audio
func _make_wav(freq: float, dur: float, noise: float) -> AudioStreamWAV:
	var rate := 22050
	var n := int(rate * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		var t := float(i) / rate
		var env := 1.0 - float(i) / n
		var s := (sin(TAU * freq * t) * (1.0 - noise) + (randf() * 2.0 - 1.0) * noise) * env * 0.6
		data.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 32767.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.data = data
	return w

func _make_audio() -> void:
	sfx_shot = _player_for(_make_wav(140.0, 0.12, 0.8))
	sfx_skill = _player_for(_make_wav(520.0, 0.25, 0.0))
	sfx_hit = _player_for(_make_wav(900.0, 0.06, 0.1))

func _player_for(stream: AudioStream) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.stream = stream
	p.volume_db = linear_to_db(maxf(Settings.volume, 0.001))
	add_child(p)
	return p

# ------------------------------------------------------------------ main loop
func _physics_process(delta: float) -> void:
	if finished:
		return
	space = get_world_3d().direct_space_state
	elapsed += delta
	_update_look()
	_update_move(delta)
	_update_combat(delta)
	_update_skills(delta)
	_update_items(delta)
	_update_marks(delta)
	_update_zone(delta)
	_update_bots(delta)
	_update_pickups(delta)
	_sim_attrition(delta)
	_check_end()
	for i in range(feed.size() - 1, -1, -1):
		feed[i]["t"] -= delta
		if feed[i]["t"] <= 0.0:
			feed.remove_at(i)

func _process(_delta: float) -> void:
	if cam == null or cam_pivot == null:
		return
	cam.fov = lerpf(cam.fov, float(_w()["fov"]) if scoped else 70.0, 0.25)
	# keep the camera from clipping through walls
	var desired := Vector3(0.7, 0.3, 3.4)
	var from := cam_pivot.global_position
	var to := cam_pivot.to_global(desired)
	if space != null:
		var q := PhysicsRayQueryParameters3D.create(from, to)
		q.collision_mask = 1
		var hit := space.intersect_ray(q)
		if hit:
			var dist := maxf(from.distance_to(hit.position) - 0.25, 0.5)
			cam.position = desired.normalized() * minf(dist, desired.length())
			return
	cam.position = desired

func _update_look() -> void:
	var sens: float = 0.004 * (Settings.aim_sens if hud.held.get("fire", false) else Settings.cam_sens)
	if scoped:
		sens *= 0.55
	yaw -= hud.look_delta.x * sens
	pitch = clampf(pitch - hud.look_delta.y * sens, -1.2, 0.8)
	hud.look_delta = Vector2.ZERO
	player.rotation.y = yaw
	cam_pivot.rotation.x = pitch

func _in_river() -> bool:
	var p := player.global_position
	return absf(p.x + 40.0) < 7.0 and absf(p.z) > 4.0

func _apply_stance() -> void:
	player_model.scale.y = 0.35 if prone else (0.72 if crouching else 1.0)
	cam_pivot.position.y = 0.6 if prone else (1.1 if crouching else 1.5)

func _update_move(delta: float) -> void:
	if hud.take("crouch"):
		crouching = not crouching
		prone = false
		_apply_stance()
	if hud.take("prone"):
		prone = not prone
		crouching = false
		_apply_stance()
	var mv: Vector2 = hud.move_vec
	var dir: Vector3 = player.global_transform.basis * Vector3(mv.x, 0, mv.y)
	dir.y = 0.0
	# sprint: hold the stick fully for 0.6 s
	var was_sprinting := sprinting
	if mv.length() > 0.85 and not crouching and not prone and use_t <= 0.0:
		sprint_hold += delta
	else:
		sprint_hold = 0.0
	sprinting = sprint_hold >= 0.6
	if sprinting:
		sprint_len += delta
	elif was_sprinting:
		if pk == "velocity" and sprint_len >= 1.0:
			bonus_t = 3.0
			hud.toast("Ultra Velocity: next shot deals bonus damage")
		sprint_len = 0.0
	var spd := 6.0
	if prone:
		spd = 1.8
	elif crouching:
		spd = 3.0
	if sprinting:
		spd *= 1.5 if pk == "velocity" else 1.25
	spd *= float(_w().get("move", 1.0))
	if pk == "agility" and _w()["cat"] == "shotgun":
		spd *= 1.16
	if speed_t > 0.0:
		spd *= 1.6
	if remix_t > 0.0:
		spd *= 1.15
	if use_t > 0.0:
		spd *= 0.6
	if _in_river():
		spd *= 0.55
	var hv := dir * spd
	if dash_t > 0.0:
		hv = dash_dir * (26.0 if rush_dash else 22.0)
		dash_t -= delta
		if rush_dash:
			_rush_hits()
			if dash_t <= 0.0:
				rush_dash = false
	if player.is_on_floor():
		vel_y = 0.0
		if hud.take("jump"):
			vel_y = 5.5
			if crouching or prone:
				crouching = false
				prone = false
				_apply_stance()
	else:
		vel_y -= 14.0 * delta
		hud.take("jump")
	player.velocity = Vector3(hv.x, vel_y, hv.z)
	player.move_and_slide()
	var p := player.global_position
	player.global_position = Vector3(clampf(p.x, -MAP_HALF, MAP_HALF), p.y, clampf(p.z, -MAP_HALF, MAP_HALF))

func _rush_hits() -> void:
	for b in bots:
		if b.alive and not rush_hit.has(b.name) and b.node.global_position.distance_to(player.global_position) < 2.0:
			rush_hit.append(b.name)
			_damage_bot(b, 40.0 * _out_mult(), true)

func _w() -> Dictionary:
	return loadout[weapon]

func _mag() -> int:
	return int(_w()["mag"])

func _init_loadout() -> void:
	for sl in SLOTS:
		var id: String = Settings.loadout.get(sl, "m4a1")
		loadout[sl] = Weapons.stats(id, int(Settings.skins.get(id, 0)))
		var mag: int = loadout[sl]["mag"]
		wstate[sl] = {"ammo": mag, "reserve": 999 if mode == "training" else mag * 3}
	weapon = "p1"
	if mode == "training":
		medkits = 9
		grenades = 9
	_update_held()

func _update_held() -> void:
	if held_model != null and is_instance_valid(held_model):
		held_model.queue_free()
	held_model = null
	var w := _w()
	if w["cat"] == "fist":
		return
	held_model = Weapons.build_model(w)
	held_model.position = Vector3(0.34, 1.1, -0.2)
	held_model.scale = Vector3.ONE * 0.85
	player_model.add_child(held_model)

func _swap_weapon() -> void:
	reloading = 0.0
	weapon = SLOTS[(SLOTS.find(weapon) + 1) % SLOTS.size()]
	fire_cd = 0.25
	if _w()["melee"]:
		scoped = false
	_update_held()
	hud.toast("Weapon: %s" % _w()["name"])

func _update_combat(delta: float) -> void:
	fire_cd = maxf(0.0, fire_cd - delta)
	var tapped: bool = hud.take("fire")
	var holding: bool = hud.held.get("fire", false)
	if hud.take("swap"):
		_swap_weapon()
	var w := _w()
	if hud.take("scope") and not w["melee"]:
		scoped = not scoped
	if w["melee"]:
		scoped = false
		hud.take("reload")
		if holding and fire_cd <= 0.0:
			_melee()
		return
	if reloading > 0.0:
		reloading -= delta
		if reloading <= 0.0:
			var take := mini(_mag() - ammo, reserve)
			ammo += take
			if mode != "training":
				reserve -= take
	if hud.take("reload") and reloading <= 0.0 and ammo < _mag() and reserve > 0:
		reloading = w["reload"]
	if (holding or tapped) and fire_cd <= 0.0 and reloading <= 0.0:
		if ammo > 0:
			_shoot()
		elif reserve > 0:
			reloading = w["reload"]

func _out_mult() -> float:
	# Hayato "Art of Blades": lower HP = more armor penetration (damage dealt)
	if pk == "blades":
		return 1.0 + 0.5 * (1.0 - clampf(hp / 100.0, 0.0, 1.0))
	return 1.0

func _melee() -> void:
	var w := _w()
	fire_cd = w["interval"]
	var fwd: Vector3 = -player.global_transform.basis.z
	fwd.y = 0.0
	fwd = fwd.normalized()
	var best = null
	var best_d: float = w["range"]
	for b in bots:
		if not b.alive:
			continue
		var to: Vector3 = b.node.global_position - player.global_position
		to.y = 0.0
		var d := to.length()
		if d < best_d and (d < 0.3 or fwd.dot(to / d) > 0.3):
			best_d = d
			best = b
	if best != null:
		var dmg: float = w["dmg"] * _out_mult()
		if pk == "fist" and w["cat"] == "fist":
			dmg *= 5.0   # Muay Thai: fist damage +400%
		hud.hit_flash = 0.15
		sfx_hit.play()
		_damage_bot(best, dmg, true)

func _shoot() -> void:
	var w := _w()
	fire_cd = w["interval"]
	if mode != "training":
		ammo -= 1
	var origin := cam.global_position
	var base_dir: Vector3 = -cam.global_transform.basis.z
	var gun_range: float = w["range"]
	# aim assist: only pulls toward a target already within ~1.5 m of the crosshair line
	var best = null
	var best_perp := AIM_ASSIST_RANGE
	for b in bots:
		if not b.alive:
			continue
		var tb: Vector3 = b.node.global_position + Vector3(0, 1.1, 0) - origin
		var tt := tb.dot(base_dir)
		if tt < 2.0 or tt > gun_range:
			continue
		var perp := (tb - base_dir * tt).length()
		if perp < best_perp:
			best_perp = perp
			best = b
	if best != null and Settings.aim_assist > 0.0:
		var to_t: Vector3 = best.node.global_position + Vector3(0, 1.1, 0) - origin
		base_dir = base_dir.lerp(to_t.normalized(), Settings.aim_assist).normalized()
	# Kelly "Ultra Velocity": first shot after sprinting hits harder
	var shot_mult := 1.0
	if pk == "velocity" and bonus_t > 0.0:
		shot_mult = 1.6
		bonus_t = 0.0
	var muzzle := player.global_position + Vector3(0, 1.3, 0) - player.global_transform.basis.z * 0.6 + player.global_transform.basis.x * 0.3
	var pellets: int = w["pellets"]
	var spread: float = w["spread"]
	var any_hit := false
	for k in pellets:
		var dir := base_dir
		if spread > 0.0:
			dir = (dir + cam.global_transform.basis.x * rng.randf_range(-spread, spread) + cam.global_transform.basis.y * rng.randf_range(-spread, spread)).normalized()
		# wall check (a Gloo Wall absorbs the shot and takes damage)
		var wall_dist := gun_range
		var q := PhysicsRayQueryParameters3D.create(origin, origin + dir * gun_range)
		q.collision_mask = 1
		var hit := space.intersect_ray(q)
		if hit:
			wall_dist = origin.distance_to(hit.position)
			var col = hit.get("collider")
			if col != null and col.has_meta("gloo"):
				_damage_wall(col, float(w["dmg"]) * (1.0 + float(w["pen"])))
		var target = null
		var tmin := wall_dist
		var head := false
		for b in bots:
			if not b.alive:
				continue
			var tv: Vector3 = b.node.global_position + Vector3(0, 1.0, 0) - origin
			var t2 := tv.dot(dir)
			if t2 < 0.0 or t2 > tmin:
				continue
			if (tv - dir * t2).length() < 0.7:
				target = b
				tmin = t2
				head = (origin + dir * t2).y - b.node.global_position.y >= 1.4
		if k < 3:
			_tracer(muzzle, origin + dir * tmin)
		if target != null:
			any_hit = true
			var dmg: float = w["dmg"] * shot_mult * _out_mult()
			if w["cat"] == "shotgun" and tmin > 8.0:
				dmg *= clampf(1.0 - (tmin - 8.0) / 22.0, 0.25, 1.0)
			if head:
				dmg *= 2.4 if pk == "limelight" else 1.8
			_damage_bot(target, dmg, true)
	sfx_shot.play()
	var heavy: bool = w["cat"] in ["shotgun", "sniper", "others", "marksman"]
	pitch = minf(pitch + (0.05 if heavy else 0.010), 0.8)
	if any_hit:
		hud.hit_flash = 0.15
		sfx_hit.play()

func _tracer(a: Vector3, b: Vector3) -> void:
	var dist := a.distance_to(b)
	if dist < 0.5:
		return
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.03, 0.03, dist)
	mi.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(1, 0.9, 0.4)
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mi.material_override = m
	add_child(mi)
	mi.global_position = (a + b) / 2.0
	mi.look_at(b, Vector3.UP)
	get_tree().create_timer(0.05).timeout.connect(mi.queue_free)

func _damage_bot(b: Dictionary, dmg: float, by_player: bool, killer := "") -> void:
	if not b.alive:
		return
	b.hp -= dmg
	if by_player and pk == "mark":
		_mark_bot(b)
	if b.hp <= 0.0:
		_kill_bot(b, by_player, killer)

func _mark_bot(b: Dictionary) -> void:
	b["mark_t"] = 6.0
	var node: Node3D = b.node
	if node.get_node_or_null("MarkLabel") == null:
		var l := Label3D.new()
		l.name = "MarkLabel"
		l.text = "v"
		l.font_size = 120
		l.pixel_size = 0.01
		l.modulate = Color(1.0, 0.2, 0.2)
		l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		l.no_depth_test = true
		l.position = Vector3(0, 2.4, 0)
		node.add_child(l)

func _update_marks(delta: float) -> void:
	for b in bots:
		if not b.alive or b.get("mark_t", 0.0) <= 0.0:
			continue
		b["mark_t"] -= delta
		if b["mark_t"] <= 0.0:
			var l: Node = b.node.get_node_or_null("MarkLabel")
			if l:
				l.queue_free()

func _kill_bot(b: Dictionary, by_player: bool, killer := "") -> void:
	b.alive = false
	b.node.queue_free()
	var who := "YOU" if by_player else (killer if killer != "" else "Zone")
	feed.append({"t": 6.0, "text": "%s  eliminated  %s" % [who, b.name], "you": by_player})
	if feed.size() > 4:
		feed.remove_at(0)
	if by_player:
		kills += 1
		ep = minf(EP_MAX, ep + 25.0)
		hud.toast("Eliminated %s!" % b.name)
		# Tatsuya "Rebel Rush": knocking down enemies soon after rushing resets the cooldown
		if rush_window > 0.0 and rush_idx >= 0:
			skill_cd[rush_idx] = 0.0
			rush_window = 0.0
			hud.toast("Rebel Rush cooldown reset!")

func _hurt(dmg: float, src := Vector3.INF, head := false) -> void:
	if head:
		dmg *= 1.0 if pk == "limelight" else 1.6   # Limelight: no extra headshot damage taken
	if shield_t > 0.0:
		dmg *= 0.3
	if field_t > 0.0:
		var pp := player.global_position
		if Vector2(pp.x - field_pos.x, pp.z - field_pos.z).length() < 3.2:
			dmg *= 0.1
	if pk == "wolfpack":
		dmg *= 0.85
	if pk == "blades" and src != Vector3.INF:
		var fwd: Vector3 = -player.global_transform.basis.z
		var to_src: Vector3 = src - player.global_position
		to_src.y = 0.0
		if to_src.length() > 0.1 and fwd.dot(to_src.normalized()) > 0.3:
			dmg *= 1.0 - 0.3 * (1.0 - clampf(hp / 100.0, 0.0, 1.0))
	if ep > 0.0:
		var absorbed := minf(ep, dmg)
		ep -= absorbed
		dmg -= absorbed
	hp -= dmg
	use_t = 0.0   # taking damage interrupts a medkit
	hud.dmg_flash = 0.35

# ------------------------------------------------------------------ skills
func _update_skills(delta: float) -> void:
	for i in 3:
		skill_cd[i] = maxf(0.0, skill_cd[i] - delta)
		if hud.take("skill%d" % (i + 1)) and i < chardata["skills"].size():
			_use_skill(i)
	shield_t = maxf(0.0, shield_t - delta)
	speed_t = maxf(0.0, speed_t - delta)
	radar_t = maxf(0.0, radar_t - delta)
	field_t = maxf(0.0, field_t - delta)
	rush_window = maxf(0.0, rush_window - delta)
	shield_node.visible = shield_t > 0.0
	if field_node != null:
		field_node.visible = field_t > 0.0

func _use_skill(i: int) -> void:
	if skill_cd[i] > 0.0:
		return
	var s: Dictionary = chardata["skills"][i]
	skill_cd[i] = s["cd"]
	Settings.skills_used += 1
	sfx_skill.play()
	var pc := player.global_position + Vector3(0, 1.0, 0)
	var fwd: Vector3 = -player.global_transform.basis.z
	fwd.y = 0.0
	fwd = fwd.normalized()
	match s["kind"]:
		"dash":
			dash_dir = fwd
			dash_t = 0.2
			_fx(pc, Color(1.0, 0.8, 0.2), 1.2, 0.3)
		"shield":
			shield_t = 3.0
			_fx(pc, Color(0.3, 0.8, 1.0), 1.6, 0.4)
		"heal":
			hp = minf(100.0, hp + 30.0)
			_fx(pc, Color(0.3, 1.0, 0.4), 1.6, 0.5)
		"speed":
			speed_t = 4.0
			_fx(pc, Color(1.0, 0.6, 0.2), 1.3, 0.4)
		"radar":
			radar_t = 5.0
			_fx(pc, Color(0.4, 0.6, 1.0), 6.0, 0.8)
		"blast":
			_fx(pc, Color(1.0, 0.3, 0.3), 8.0, 0.5)
			for b in bots:
				if b.alive and b.node.global_position.distance_to(player.global_position) <= 8.0:
					_damage_bot(b, 40.0, true)
		"rush":   # Tatsuya: Rebel Rush
			dash_dir = fwd
			dash_t = 0.3
			rush_dash = true
			rush_idx = i
			rush_window = 3.0
			rush_hit.clear()
			_fx(pc, Color(0.4, 0.7, 1.0), 1.4, 0.4)
		"remix":  # Alok: Party Remix
			remix_t = 5.0
			_fx(pc, Color(1.0, 0.5, 0.9), 3.0, 0.6)
		"wave":   # Skyler: Riptide Rhythm
			_fx(player.global_position + fwd * 6.0 + Vector3(0, 1.0, 0), Color(0.3, 0.8, 1.0), 5.0, 0.5)
			for b in bots:
				if not b.alive:
					continue
				var to: Vector3 = b.node.global_position - player.global_position
				to.y = 0.0
				var d := to.length()
				if d <= 18.0 and d > 0.1 and fwd.dot(to / d) > 0.8:
					_damage_bot(b, 45.0 * _out_mult(), true)
			for g in gloo_walls.duplicate():
				if is_instance_valid(g["node"]):
					var gw: Vector3 = g["node"].global_position - player.global_position
					gw.y = 0.0
					if gw.length() <= 18.0 and gw.length() > 0.1 and fwd.dot(gw.normalized()) > 0.7:
						_remove_wall(g)
		"field":  # Chrono: Time Turner
			field_t = 5.0
			field_pos = player.global_position
			if field_node == null:
				field_node = MeshInstance3D.new()
				var sph := SphereMesh.new()
				sph.radius = 3.2
				sph.height = 6.4
				field_node.mesh = sph
				var fm := StandardMaterial3D.new()
				fm.albedo_color = Color(0.3, 0.6, 1.0, 0.25)
				fm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
				fm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
				fm.cull_mode = BaseMaterial3D.CULL_DISABLED
				field_node.material_override = fm
				add_child(field_node)
			field_node.global_position = field_pos + Vector3(0, 0.5, 0)
			field_node.visible = true
			_fx(pc, Color(0.3, 0.6, 1.0), 3.2, 0.5)

# ------------------------------------------------------------------ items (medkit, grenade)
func _update_items(delta: float) -> void:
	_update_deployables(delta)
	bonus_t = maxf(0.0, bonus_t - delta)
	if hud.take("medkit"):
		if use_t > 0.0:
			pass
		elif medkits <= 0:
			hud.toast("No medkits left")
		elif hp >= 100.0:
			hud.toast("HP is already full")
		else:
			use_total = MEDKIT_TIME / (1.25 if pk == "gluttony" else 1.0)   # Maxim: 25% faster
			use_t = use_total
	if use_t > 0.0:
		use_t -= delta
		if use_t <= 0.0:
			use_t = 0.0
			hp = minf(100.0, hp + 50.0)
			if mode != "training":
				medkits -= 1
			hud.toast("Medkit used: +50 HP")
	if remix_t > 0.0:
		remix_t -= delta
		hp = minf(100.0, hp + 6.0 * delta)   # Party Remix: +30 HP over 5 s
	if hud.take("grenade"):
		_throw_grenade()

func _throw_grenade() -> void:
	if grenades <= 0:
		hud.toast("No grenades left")
		return
	if mode != "training":
		grenades -= 1
	var gid: String = Settings.loadout.get("grenade", "grenade")
	if gid == "gloo":
		_place_gloo()
		return
	var fwd: Vector3 = -cam.global_transform.basis.z
	var from := player.global_position + Vector3(0, 1.5, 0)
	var to := from + fwd * 16.0
	to.y = maxf(player.global_position.y + 0.2, 0.2)
	var q := PhysicsRayQueryParameters3D.create(from, to)
	q.collision_mask = 1
	var hit := space.intersect_ray(q)
	if hit:
		to = hit.position - fwd * 0.4
		to.y = maxf(to.y, 0.2)
	var mi := Weapons.build_model(Weapons.stats(gid, 0))
	add_child(mi)
	mi.global_position = from
	var tw := create_tween()
	tw.tween_property(mi, "global_position", to, 0.7)
	sfx_skill.play()
	get_tree().create_timer(1.6 if gid == "grenade" else 1.0).timeout.connect(func():
		if not is_instance_valid(mi) or finished:
			return
		mi.queue_free()
		if gid == "smoke":
			_make_smoke(to)
			return
		_fx(to, Color(1.0, 0.55, 0.1), 5.0, 0.4)
		for b in bots:
			if b.alive:
				var d: float = b.node.global_position.distance_to(to)
				if d <= 5.0:
					_damage_bot(b, 70.0 * (1.0 - 0.6 * d / 5.0), true)
		for g in gloo_walls.duplicate():
			if is_instance_valid(g["node"]) and g["node"].global_position.distance_to(to) <= 5.0:
				_damage_wall(g["node"], 150.0)
		var pd := player.global_position.distance_to(to)
		if pd <= 4.0:
			_hurt(35.0 * (1.0 - pd / 4.0)))

func _place_gloo() -> void:
	var fwd: Vector3 = -player.global_transform.basis.z
	fwd.y = 0.0
	fwd = fwd.normalized()
	var sk := Weapons.stats("gloo", int(Settings.skins.get("gloo", 0)))
	var sb := StaticBody3D.new()
	sb.collision_layer = 1
	sb.collision_mask = 0
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(3.0, 2.0, 0.4)
	cs.shape = bs
	cs.position.y = 1.0
	sb.add_child(cs)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(3.0, 2.0, 0.4)
	mi.mesh = bm
	mi.position.y = 1.0
	var mat := StandardMaterial3D.new()
	var bc: Color = sk["body"]
	mat.albedo_color = Color(bc, 0.85)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mi.material_override = mat
	sb.add_child(mi)
	add_child(sb)
	sb.global_position = Vector3(player.global_position.x + fwd.x * 2.6, player.global_position.y, player.global_position.z + fwd.z * 2.6)
	sb.rotation.y = player.rotation.y
	sb.set_meta("gloo", true)
	gloo_walls.append({"node": sb, "hp": 300.0, "t": 30.0})
	sfx_skill.play()
	hud.toast("Gloo Wall placed")

func _damage_wall(col: Object, dmg: float) -> void:
	for g in gloo_walls:
		if g["node"] == col:
			g["hp"] -= dmg
			if g["hp"] <= 0.0:
				_remove_wall(g)
			return

func _remove_wall(g: Dictionary) -> void:
	if is_instance_valid(g["node"]):
		_fx(g["node"].global_position + Vector3(0, 1, 0), Color(0.8, 0.9, 1.0), 2.0, 0.3)
		g["node"].queue_free()
	gloo_walls.erase(g)

func _make_smoke(pos: Vector3) -> void:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 5.0
	sm.height = 10.0
	mi.mesh = sm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.75, 0.75, 0.78, 0.6)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	mi.material_override = mat
	add_child(mi)
	mi.global_position = pos + Vector3(0, 2.0, 0)
	smokes.append({"pos": pos, "t": 8.0, "node": mi})
	hud.toast("Smoke deployed: enemies lose sight of you inside it")

func _in_smoke(p: Vector3) -> bool:
	for sm in smokes:
		if p.distance_to(sm["pos"]) < 5.0:
			return true
	return false

func _update_deployables(delta: float) -> void:
	for g in gloo_walls.duplicate():
		g["t"] -= delta
		if g["t"] <= 0.0:
			_remove_wall(g)
	for i in range(smokes.size() - 1, -1, -1):
		smokes[i]["t"] -= delta
		if smokes[i]["t"] <= 0.0:
			if is_instance_valid(smokes[i]["node"]):
				smokes[i]["node"].queue_free()
			smokes.remove_at(i)

func _fx(pos: Vector3, color: Color, radius: float, dur: float) -> void:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 1.0
	sm.height = 2.0
	mi.mesh = sm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(color, 0.45)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mi.material_override = m
	mi.scale = Vector3.ONE * 0.2
	add_child(mi)
	mi.global_position = pos
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(mi, "scale", Vector3.ONE * radius, dur)
	tw.tween_property(m, "albedo_color:a", 0.0, dur)
	tw.chain().tween_callback(mi.queue_free)

# ------------------------------------------------------------------ zone / bots / loot
func _update_zone(delta: float) -> void:
	if mode == "training":
		return
	zone_timer -= delta
	if not zone_shrinking:
		if zone_timer <= 0.0 and zone_stage < ZONE_RADII.size():
			zone_shrinking = true
			zone_timer = 20.0
			zone_from = zone_radius
			zone_to = ZONE_RADII[zone_stage]
			zone_c_from = zone_center
			var ang := rng.randf() * TAU
			zone_c_to = zone_center + Vector2(cos(ang), sin(ang)) * rng.randf() * maxf(zone_from - zone_to, 0.0) * 0.8
			hud.toast("Safe zone is shrinking!")
	else:
		var k := 1.0 - clampf(zone_timer / 20.0, 0.0, 1.0)
		zone_radius = lerpf(zone_from, zone_to, k)
		zone_center = zone_c_from.lerp(zone_c_to, k)
		if zone_timer <= 0.0:
			zone_shrinking = false
			zone_timer = 25.0
			zone_stage += 1
	zone_node.scale = Vector3(zone_radius, 1, zone_radius)
	zone_node.position = Vector3(zone_center.x, 30, zone_center.y)
	var dps := 1.5 + zone_stage * 1.5
	var p2 := Vector2(player.global_position.x, player.global_position.z)
	if p2.distance_to(zone_center) > zone_radius:
		hp -= dps * delta
		hud.dmg_flash = maxf(hud.dmg_flash, 0.15)
	if not drop_spawned and elapsed >= 45.0:
		drop_spawned = true
		var ang2 := rng.randf() * TAU
		var dp := zone_center + Vector2(cos(ang2), sin(ang2)) * zone_radius * 0.5
		_make_pickup(Vector3(clampf(dp.x, -MAP_HALF, MAP_HALF), 0.6, clampf(dp.y, -MAP_HALF, MAP_HALF)), "drop")
		hud.toast("Supply drop landed! Look for the golden beam")
	for b in bots:
		if b.alive:
			var bp := Vector2(b.node.global_position.x, b.node.global_position.z)
			if bp.distance_to(zone_center) > zone_radius:
				_damage_bot(b, dps * delta, false)

func _los_clear(a: Vector3, b: Vector3) -> bool:
	var q := PhysicsRayQueryParameters3D.create(a, b)
	q.collision_mask = 1
	return space.intersect_ray(q).is_empty()

func _update_bots(delta: float) -> void:
	var ppos := player.global_position
	for b in bots:
		if not b.alive:
			continue
		var n: CharacterBody3D = b.node
		var bpos := n.global_position
		var to_p := ppos - bpos
		var d := to_p.length()
		var move_dir := Vector3.ZERO
		var outside := mode != "training" and Vector2(bpos.x, bpos.z).distance_to(zone_center) > zone_radius - 3.0
		if mode == "training":
			pass
		elif outside:
			var c3 := Vector3(zone_center.x, bpos.y, zone_center.y)
			move_dir = (c3 - bpos).normalized()
		elif d < 45.0:
			if d > 14.0:
				move_dir = Vector3(to_p.x, 0, to_p.z).normalized()
			elif d < 8.0:
				move_dir = -Vector3(to_p.x, 0, to_p.z).normalized()
			b.cd -= delta
			if b.cd <= 0.0:
				b.cd = rng.randf_range(0.8, 1.3)
				var eye := bpos + Vector3(0, 1.4, 0)
				var chest := ppos + Vector3(0, 1.1, 0)
				if _los_clear(eye, chest) and not (_in_smoke(ppos) and d > 6.0):
					var hit_it := rng.randf() < 0.35
					var miss := Vector3.ZERO if hit_it else Vector3(rng.randf_range(-1.5, 1.5), 0, rng.randf_range(-1.5, 1.5))
					_tracer(eye, chest + miss)
					if hit_it:
						_hurt(7.0, bpos, rng.randf() < 0.15)
		else:
			b.wt -= delta
			if b.wt <= 0.0 or bpos.distance_to(b.wander) < 2.0:
				b.wander = bpos + Vector3(rng.randf_range(-40, 40), 0, rng.randf_range(-40, 40))
				b.wt = rng.randf_range(4.0, 8.0)
			move_dir = Vector3(b.wander.x - bpos.x, 0, b.wander.z - bpos.z).normalized()
		if d > 0.5 and (d < 60.0 or mode == "training"):
			n.look_at(Vector3(ppos.x, bpos.y, ppos.z), Vector3.UP)
		elif move_dir.length() > 0.1:
			n.look_at(bpos + move_dir, Vector3.UP)
		n.velocity = Vector3(move_dir.x * 4.0, -6.0, move_dir.z * 4.0)
		n.move_and_slide()

func _update_pickups(delta: float) -> void:
	var pp := player.global_position
	for i in range(pickups.size() - 1, -1, -1):
		var pk: Dictionary = pickups[i]
		var node: MeshInstance3D = pk["node"]
		node.rotate_y(delta * 2.0)
		if node.global_position.distance_to(pp) < 1.8:
			match pk["kind"]:
				"med":
					medkits = mini(medkits + 1, 4)
					hud.toast("Medkit +1  (tap MEDKIT to heal)")
				"ammo":
					for sl in ["p1", "p2", "pistol"]:
						wstate[sl]["reserve"] += maxi(1, int(loadout[sl]["mag"]))
					hud.toast("Ammo +1 magazine for every gun")
				"gren":
					grenades = mini(grenades + 2, 9)
					hud.toast("Grenades +2")
				"drop":
					hp = minf(100.0, hp + 50.0)
					medkits = mini(medkits + 1, 4)
					ep = minf(EP_MAX, ep + 100.0)
					for sl in ["p1", "p2", "pistol"]:
						wstate[sl]["reserve"] += maxi(2, int(loadout[sl]["mag"]) * 2)
					hud.toast("Supply drop: +50 HP, +100 EP, medkit, ammo")
			node.queue_free()
			pickups.remove_at(i)

func _sim_attrition(delta: float) -> void:
	# Simulates fights between bots far from the player so a match ends in a few minutes.
	if mode == "training":
		return
	attr_t -= delta
	if attr_t > 0.0:
		return
	attr_t = rng.randf_range(4.0, 7.0)
	if elapsed < 20.0:
		return
	var far: Array = []
	for b in bots:
		if b.alive and b.node.global_position.distance_to(player.global_position) > 70.0:
			far.append(b)
	if far.size() >= 2:
		var victim: Dictionary = far[rng.randi() % far.size()]
		var killer: Dictionary = far[rng.randi() % far.size()]
		_kill_bot(victim, false, killer.name if killer != victim else "Player ?")

# ------------------------------------------------------------------ match end
func _alive_count() -> int:
	var n := 1
	for b in bots:
		if b.alive:
			n += 1
	return n

func _check_end() -> void:
	if mode == "training":
		hp = 100.0
		return
	if hp <= 0.0:
		_finish(false)
	elif _alive_count() <= 1:
		_finish(true)

func _finish(win: bool) -> void:
	if finished:
		return
	finished = true
	var place := 1 if win else _alive_count()
	var gained := kills * 3
	if win:
		gained += 40
	elif place <= 5:
		gained += 20
	elif place <= 15:
		gained += 5
	else:
		gained -= 5
	var old_rp := Settings.rp
	Settings.rp = maxi(0, Settings.rp + gained)
	Settings.matches += 1
	Settings.kills += kills
	if win:
		Settings.wins += 1
	Settings.save_all()
	var tier: String = Settings.TIERS[Settings.tier_index()]
	result_label.text = "%s\nPlacement #%d of 30\nEliminations: %d\nRank points: %+d  (%s, %d RP)" % ["VICTORY!" if win else "ELIMINATED", place, kills, Settings.rp - old_rp, tier, Settings.rp]
	result_panel.visible = true
