extends RefCounted
## Builds a simple low-poly human from primitives (placeholder art, no imported assets).

static func _part(parent: Node3D, mesh: Mesh, pos: Vector3, c: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.position = pos
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	mi.material_override = m
	parent.add_child(mi)
	return mi

static func _box(s: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = s
	return b

static func build(c: Dictionary) -> Node3D:
	var root := Node3D.new()
	var female: bool = c["gender"] == "Female"
	var hair: Color = c.get("hair", Color(0.08, 0.06, 0.05))
	_part(root, _box(Vector3(0.42, 0.85, 0.26)), Vector3(0, 0.43, 0), c["pants"])
	var tw := 0.48 if female else 0.56
	_part(root, _box(Vector3(tw, 0.62, 0.30)), Vector3(0, 1.16, 0), c["shirt"])
	_part(root, _box(Vector3(0.12, 0.60, 0.14)), Vector3(-(tw / 2.0 + 0.07), 1.14, 0), c["shirt"])
	_part(root, _box(Vector3(0.12, 0.60, 0.14)), Vector3(tw / 2.0 + 0.07, 1.14, 0), c["shirt"])
	var head := SphereMesh.new()
	head.radius = 0.15
	head.height = 0.30
	_part(root, head, Vector3(0, 1.62, 0), c["skin"])
	if female:
		_part(root, _box(Vector3(0.34, 0.50, 0.12)), Vector3(0, 1.50, 0.14), hair)
		_part(root, _box(Vector3(0.32, 0.08, 0.32)), Vector3(0, 1.74, 0), hair)
	else:
		_part(root, _box(Vector3(0.32, 0.08, 0.32)), Vector3(0, 1.74, 0), hair)
	if c.has("shoes"):
		_part(root, _box(Vector3(0.16, 0.1, 0.28)), Vector3(-0.11, 0.05, -0.04), c["shoes"])
		_part(root, _box(Vector3(0.16, 0.1, 0.28)), Vector3(0.11, 0.05, -0.04), c["shoes"])
	var acc: String = c.get("acc", "")
	var ac: Color = c.get("acc_color", Color(0.1, 0.1, 0.1))
	match acc:
		"glasses":
			_part(root, _box(Vector3(0.30, 0.06, 0.04)), Vector3(0, 1.64, -0.14), ac)
		"mask":
			_part(root, _box(Vector3(0.28, 0.12, 0.05)), Vector3(0, 1.57, -0.14), ac)
		"cap":
			_part(root, _box(Vector3(0.36, 0.08, 0.36)), Vector3(0, 1.78, 0), ac)
			_part(root, _box(Vector3(0.30, 0.03, 0.18)), Vector3(0, 1.74, -0.22), ac)
	return root
