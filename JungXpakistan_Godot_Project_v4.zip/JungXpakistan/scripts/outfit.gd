extends RefCounted
## Vault > Fashion: outfit pieces (colour variants for the placeholder character model).
## Index 0 of every list is "Default" (keeps the character's own look).

const SLOTS := ["top", "bottom", "shoes", "hair", "accessory"]
const SLOT_LABELS := {"top": "TOP", "bottom": "BOTTOM", "shoes": "SHOES", "hair": "HAIR", "accessory": "FACE / HEAD"}

const ITEMS := {
	"top": [
		["Default", null], ["White Shirt & Tie", Color(0.95, 0.95, 0.97)], ["Black Hoodie", Color(0.08, 0.08, 0.09)],
		["Sky Tank Top", Color(0.4, 0.75, 0.95)], ["Red Stripe Tee", Color(0.85, 0.2, 0.22)], ["Yellow Tracksuit", Color(0.96, 0.8, 0.1)],
		["Purple Shade Jacket", Color(0.35, 0.2, 0.7)], ["Camo Green", Color(0.3, 0.45, 0.25)], ["Golden Jacket", Color(0.85, 0.7, 0.25)],
	],
	"bottom": [
		["Default", null], ["Black Wing Pants", Color(0.07, 0.07, 0.09)], ["Plaid Pants", Color(0.28, 0.28, 0.3)],
		["White Pants", Color(0.93, 0.93, 0.95)], ["Blue Jeans", Color(0.16, 0.24, 0.4)], ["Khaki Cargo", Color(0.5, 0.45, 0.3)],
		["Yellow Track Pants", Color(0.96, 0.8, 0.1)], ["Crimson Pants", Color(0.6, 0.12, 0.15)],
	],
	"shoes": [
		["Default", null], ["White Sneakers", Color(0.95, 0.95, 0.95)], ["Black Boots", Color(0.06, 0.06, 0.07)],
		["Yellow Sneakers", Color(0.95, 0.85, 0.15)], ["Blue Runners", Color(0.2, 0.45, 0.9)], ["Red Kicks", Color(0.85, 0.15, 0.15)],
	],
	"hair": [
		["Default", null], ["Silver Hair", Color(0.8, 0.8, 0.83)], ["Black Hair", Color(0.05, 0.05, 0.07)], ["Brown Hair", Color(0.35, 0.22, 0.12)],
		["Blonde Hair", Color(0.9, 0.78, 0.4)], ["Blue Hair", Color(0.2, 0.4, 0.95)], ["Pink Hair", Color(0.95, 0.45, 0.7)],
	],
	"accessory": [
		["Default", null], ["None", {"acc": ""}], ["Black Shades", {"acc": "glasses", "color": Color(0.05, 0.05, 0.08)}],
		["Gold Shades", {"acc": "glasses", "color": Color(1.0, 0.75, 0.1)}], ["Black Mask", {"acc": "mask", "color": Color(0.08, 0.08, 0.1)}],
		["Pink Mask", {"acc": "mask", "color": Color(0.95, 0.4, 0.6)}], ["Blue Cap", {"acc": "cap", "color": Color(0.5, 0.8, 1.0)}],
		["Red Cap", {"acc": "cap", "color": Color(0.85, 0.15, 0.15)}],
	],
}

static func get_sel(all: Dictionary, char_name: String) -> Dictionary:
	var d: Dictionary = all.get(char_name, {})
	var out := {}
	for s in SLOTS:
		out[s] = int(d.get(s, 0))
	return out

## Returns a copy of the character dictionary with the outfit pieces applied.
static func apply(c: Dictionary, sel: Dictionary) -> Dictionary:
	var o: Dictionary = c.duplicate(true)
	var ti: int = sel.get("top", 0)
	if ti > 0:
		o["shirt"] = ITEMS["top"][ti][1]
	var bi: int = sel.get("bottom", 0)
	if bi > 0:
		o["pants"] = ITEMS["bottom"][bi][1]
	var si: int = sel.get("shoes", 0)
	if si > 0:
		o["shoes"] = ITEMS["shoes"][si][1]
	var hi: int = sel.get("hair", 0)
	if hi > 0:
		o["hair"] = ITEMS["hair"][hi][1]
	var ai: int = sel.get("accessory", 0)
	if ai > 0:
		var a: Dictionary = ITEMS["accessory"][ai][1]
		o["acc"] = a["acc"]
		if a.has("color"):
			o["acc_color"] = a["color"]
	return o
