extends Control
## Vault: Fashion (outfit pieces applied to the selected character), Profile and Collection summaries.
## Emote / Posture / Skill Skin / Vehicle / Others are listed like the reference but are not implemented yet.

signal closed

const Settings = preload("res://scripts/settings.gd")
const Data = preload("res://scripts/data.gd")
const Model = preload("res://scripts/character_model.gd")
const Outfit = preload("res://scripts/outfit.gd")
const Weapons = preload("res://scripts/weapons.gd")

const CATS := ["FASHION", "EMOTE", "POSTURE", "SKILL SKIN", "COLLECTION", "VEHICLE", "PROFILE", "OTHERS"]

var cat := "FASHION"
var slot := "top"
var cat_buttons: Dictionary = {}
var content: Control
var model_root: Node3D
var char_name := ""
var spin := 0.0

func _ready() -> void:
	size = get_viewport_rect().size
	mouse_filter = Control.MOUSE_FILTER_STOP
	var bg := ColorRect.new()
	bg.color = Color(0.1, 0.07, 0.16)
	bg.size = size
	add_child(bg)
	var top := Label.new()
	top.text = "VAULT"
	top.position = Vector2(size.x - 260, 14)
	top.add_theme_font_size_override("font_size", 26)
	add_child(top)
	var close := Button.new()
	close.text = "X"
	close.position = Vector2(size.x - 70, 10)
	close.custom_minimum_size = Vector2(50, 44)
	close.pressed.connect(func(): closed.emit())
	add_child(close)
	var y := 14.0
	for c in CATS:
		var b := Button.new()
		b.text = c
		b.position = Vector2(20, y)
		b.size = Vector2(170, 46)
		b.add_theme_font_size_override("font_size", 17)
		var cc: String = c
		b.pressed.connect(func(): _select(cc))
		add_child(b)
		cat_buttons[c] = b
		y += 52.0
	content = Control.new()
	content.size = size
	add_child(content)
	_build_preview()
	_select("FASHION")

func _process(delta: float) -> void:
	if model_root != null and cat == "FASHION":
		spin += delta * 0.6
		model_root.rotation.y = spin

func _build_preview() -> void:
	var svc := SubViewportContainer.new()
	svc.position = Vector2(size.x - 470, 60)
	svc.size = Vector2(380, 520)
	svc.stretch = true
	add_child(svc)
	var sv := SubViewport.new()
	sv.size = Vector2i(380, 520)
	sv.own_world_3d = true
	svc.add_child(sv)
	var cam := Camera3D.new()
	sv.add_child(cam)
	cam.look_at_from_position(Vector3(0, 1.0, 2.6), Vector3(0, 0.95, 0))
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-35, 30, 0)
	sv.add_child(light)
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.16, 0.1, 0.24)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.7, 0.7, 0.8)
	env.environment = e
	sv.add_child(env)
	model_root = Node3D.new()
	sv.add_child(model_root)
	svc.name = "PreviewBox"

func _select(c: String) -> void:
	cat = c
	for k in cat_buttons.keys():
		cat_buttons[k].modulate = Color(1, 0.85, 0.2) if k == c else Color(1, 1, 1)
	get_node("PreviewBox").visible = c == "FASHION"
	_refresh()

func _character() -> Dictionary:
	var base: Dictionary = Data.CHARS[clampi(Settings.char_idx, 0, Data.CHARS.size() - 1)]
	char_name = base["name"]
	return Data.effective(Settings.char_idx, Settings.free_idx)

func _refresh() -> void:
	for ch in content.get_children():
		ch.queue_free()
	if cat == "FASHION":
		_build_fashion()
	elif cat == "PROFILE":
		_build_info("PROFILE", "Character: %s\nRank: %s  (%d RP)\nMatches played: %d\nWins: %d\nEliminations: %d\nSkills used: %d" % [
			_character()["name"], Settings.TIERS[Settings.tier_index()], Settings.rp, Settings.matches, Settings.wins, Settings.kills, Settings.skills_used])
	elif cat == "COLLECTION":
		var skins := 0
		for w in Weapons.LIST:
			skins += Weapons.skins_for(w[0]).size()
		var outfit_items := 0
		for s in Outfit.SLOTS:
			outfit_items += Outfit.ITEMS[s].size() - 1
		_build_info("COLLECTION", "Characters: %d\nWeapons: %d\nWeapon skins: %d\nFashion pieces: %d\n\nEverything is unlocked in this prototype." % [Data.CHARS.size(), Weapons.LIST.size(), skins, outfit_items])
	else:
		_build_info(cat, "Not in this prototype yet.\n\nThe %s tab is listed like the reference Vault so the menu matches, but it has no content or gameplay effect." % cat.to_lower())

func _build_info(title: String, text: String) -> void:
	var t := Label.new()
	t.text = title
	t.position = Vector2(220, 20)
	t.add_theme_font_size_override("font_size", 28)
	content.add_child(t)
	var l := Label.new()
	l.text = text
	l.position = Vector2(220, 80)
	l.add_theme_font_size_override("font_size", 20)
	content.add_child(l)

func _build_fashion() -> void:
	var c := _character()
	var sel := Outfit.get_sel(Settings.outfits, char_name)
	# slot tabs
	var x := 210.0
	for s in Outfit.SLOTS:
		var b := Button.new()
		b.text = Outfit.SLOT_LABELS[s]
		b.position = Vector2(x, 14)
		b.size = Vector2(130, 42)
		b.modulate = Color(1, 0.85, 0.2) if s == slot else Color(1, 1, 1)
		var ss: String = s
		b.pressed.connect(func():
			slot = ss
			_refresh())
		content.add_child(b)
		x += 136.0
	var who := Label.new()
	who.text = "Outfit for: " + char_name
	who.position = Vector2(210, 66)
	content.add_child(who)
	# item grid
	var scroll := ScrollContainer.new()
	scroll.position = Vector2(210, 100)
	scroll.size = Vector2(size.x - 710, size.y - 130)
	content.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	scroll.add_child(grid)
	var items: Array = Outfit.ITEMS[slot]
	for i in items.size():
		var b := Button.new()
		b.text = String(items[i][0]) + ("\n[EQUIPPED]" if sel[slot] == i else "")
		b.custom_minimum_size = Vector2(170, 64)
		var col = items[i][1]
		if col is Color:
			b.add_theme_color_override("font_color", col.lerp(Color.WHITE, 0.55))
		elif col is Dictionary and col.has("color"):
			b.add_theme_color_override("font_color", col["color"].lerp(Color.WHITE, 0.55))
		var idx := i
		b.pressed.connect(func(): _equip(idx))
		grid.add_child(b)
	var reset := Button.new()
	reset.text = "RESET OUTFIT"
	reset.position = Vector2(size.x - 470, size.y - 120)
	reset.size = Vector2(380, 44)
	reset.pressed.connect(func():
		Settings.outfits.erase(char_name)
		Settings.save_all()
		_refresh())
	content.add_child(reset)
	_update_model(Outfit.apply(c, sel))

func _equip(i: int) -> void:
	var d: Dictionary = Settings.outfits.get(char_name, {})
	d[slot] = i
	Settings.outfits[char_name] = d
	Settings.save_all()
	_refresh()

func _update_model(c: Dictionary) -> void:
	for ch in model_root.get_children():
		ch.queue_free()
	model_root.add_child(Model.build(c))
