extends RefCounted
## Armory data: weapon categories, weapons with stat bars, skins, gameplay stats derived from the bars,
## and simple placeholder 3D gun models (primitives, no imported art).
## Stat bar values are approximations typed in from the reference screenshots (not exact game values).

const CATS := [
	{"id": "rifle", "label": "RIFLE"},
	{"id": "marksman", "label": "MARKSMAN RIFLE"},
	{"id": "mg", "label": "MACHINE GUN"},
	{"id": "smg", "label": "SUB-MACHINE GUN"},
	{"id": "shotgun", "label": "SHOTGUN"},
	{"id": "sniper", "label": "SNIPER"},
	{"id": "pistol", "label": "PISTOL"},
	{"id": "melee", "label": "MELEE"},
	{"id": "fist", "label": "FIST"},
	{"id": "grenade", "label": "GRENADE"},
	{"id": "others", "label": "OTHERS"},
]
const GUN_LABELS := ["Damage", "Rate of Fire", "Range", "Accuracy", "Movement Speed", "Magazine", "Reload Speed", "Armor Penetration"]
const MELEE_LABELS := ["Damage", "Attack Speed", "Range", "Movement Speed"]
const PRIMARY_CATS := ["rifle", "marksman", "mg", "smg", "shotgun", "sniper", "others"]
const RARITIES := ["artifact", "mythic", "epic", "rare", "uncommon"]
const RARITY_COLORS := {
	"artifact": Color(1.0, 0.55, 0.15), "mythic": Color(0.9, 0.25, 0.3), "epic": Color(0.7, 0.35, 0.95),
	"rare": Color(0.3, 0.6, 1.0), "uncommon": Color(0.35, 0.85, 0.5),
}

# [id, name, category, bars]
const LIST := [
	["m4a1", "M4A1", "rifle", [50, 60, 55, 60, 60, 50, 55, 35]],
	["ak47", "AK47", "rifle", [65, 50, 50, 50, 55, 45, 50, 45]],
	["scar", "SCAR", "rifle", [55, 55, 55, 60, 55, 50, 55, 40]],
	["groza", "Groza", "rifle", [60, 60, 45, 50, 55, 50, 50, 40]],
	["famas", "FAMAS", "rifle", [45, 75, 45, 45, 60, 50, 65, 30]],
	["xm8", "XM8", "rifle", [55, 70, 55, 70, 60, 55, 35, 40]],
	["an94", "AN94", "rifle", [60, 50, 60, 65, 55, 45, 50, 45]],
	["plasma", "Plasma", "rifle", [55, 60, 40, 45, 55, 40, 45, 35]],
	["aug", "AUG", "rifle", [50, 55, 70, 60, 40, 50, 65, 30]],
	["parafal", "Parafal", "rifle", [65, 50, 55, 55, 50, 45, 45, 50]],
	["kingfisher", "Kingfisher", "rifle", [70, 35, 70, 70, 50, 30, 45, 50]],
	["g36", "G36", "rifle", [55, 55, 55, 60, 55, 50, 55, 40]],
	["m14", "M14", "marksman", [70, 30, 75, 70, 50, 30, 45, 50]],
	["sks", "SKS", "marksman", [65, 35, 70, 70, 55, 35, 50, 45]],
	["svd", "SVD", "marksman", [75, 30, 80, 75, 45, 25, 45, 55]],
	["woodpecker", "Woodpecker", "marksman", [70, 40, 70, 70, 50, 35, 45, 50]],
	["ac80", "AC80", "marksman", [72, 30, 78, 75, 50, 30, 45, 50]],
	["winchester", "Winchester", "marksman", [60, 25, 65, 65, 55, 25, 55, 40]],
	["m249", "M249", "mg", [50, 70, 55, 40, 35, 90, 25, 35]],
	["ump", "UMP", "smg", [50, 65, 35, 55, 70, 45, 60, 25]],
	["mp5", "MP5", "smg", [40, 75, 35, 60, 75, 45, 65, 20]],
	["vss", "VSS", "smg", [55, 50, 60, 70, 65, 35, 55, 30]],
	["mp40", "MP40", "smg", [45, 70, 35, 50, 70, 50, 40, 20]],
	["p90", "P90", "smg", [35, 85, 30, 45, 70, 70, 45, 15]],
	["cg15", "CG15", "smg", [50, 60, 45, 60, 65, 45, 55, 30]],
	["thompson", "Thompson", "smg", [55, 65, 35, 45, 65, 50, 35, 25]],
	["vector", "Vector", "smg", [35, 90, 25, 40, 70, 45, 60, 15]],
	["mac10", "MAC10", "smg", [30, 90, 20, 35, 75, 45, 65, 10]],
	["bizon", "Bizon", "smg", [30, 80, 25, 40, 70, 75, 50, 15]],
	["m1014", "M1014", "shotgun", [75, 55, 25, 50, 60, 35, 45, 15]],
	["spas12", "SPAS12", "shotgun", [70, 55, 40, 45, 55, 25, 50, 15]],
	["m1887", "M1887", "shotgun", [85, 20, 30, 50, 55, 20, 50, 15]],
	["mag7", "MAG-7", "shotgun", [70, 40, 25, 50, 55, 30, 40, 15]],
	["chargebuster", "Charge Buster", "shotgun", [80, 30, 30, 55, 55, 25, 40, 20]],
	["trogon", "Trogon", "shotgun", [75, 40, 35, 55, 55, 30, 45, 15]],
	["awm", "AWM", "sniper", [100, 25, 95, 85, 25, 20, 30, 95]],
	["kar98k", "Kar98k", "sniper", [95, 20, 90, 85, 30, 20, 35, 85]],
	["m82b", "M82B", "sniper", [100, 30, 95, 80, 20, 30, 35, 95]],
	["m24", "M24", "sniper", [95, 20, 90, 85, 30, 20, 40, 85]],
	["healsniper", "Heal Sniper", "sniper", [60, 25, 80, 80, 35, 25, 50, 40]],
	["vsk94", "VSK94", "sniper", [75, 40, 80, 80, 40, 30, 45, 60]],
	["usp", "USP", "pistol", [30, 50, 30, 60, 80, 35, 70, 10]],
	["deserteagle", "Desert Eagle", "pistol", [60, 30, 35, 60, 75, 25, 60, 30]],
	["g18", "G18", "pistol", [25, 80, 25, 50, 80, 50, 70, 5]],
	["m1873", "M1873", "pistol", [50, 20, 30, 50, 80, 20, 55, 15]],
	["m500", "M500", "pistol", [70, 15, 35, 55, 80, 15, 40, 25]],
	["pan", "Pan", "melee", [55, 40, 30, 70]],
	["parang", "Parang", "melee", [60, 55, 35, 75]],
	["katana", "Katana", "melee", [65, 60, 40, 75]],
	["scythe", "Scythe", "melee", [75, 35, 55, 60]],
	["fist", "Fist", "fist", [30, 70, 20, 90]],
	["grenade", "Grenade", "grenade", [70, 50, 50]],
	["smoke", "Smoke Grenade", "grenade", [50, 50, 50]],
	["gloo", "Gloo Wall", "grenade", [50, 40, 30]],
	["crossbow", "Crossbow", "others", [80, 15, 60, 75, 55, 15, 35, 60]],
]

# skins: weapon id -> [[name, rarity, body colour, accent colour], ...]  (index 0 is always the default skin)
const SKINS := {
	"m4a1": [["Default", "uncommon", Color(0.12, 0.12, 0.13), Color(0.3, 0.3, 0.3)], ["Scorching Sands", "epic", Color(0.85, 0.7, 0.2), Color(0.9, 0.3, 0.2)]],
	"xm8": [["Default", "uncommon", Color(0.2, 0.2, 0.22), Color(0.4, 0.4, 0.45)], ["Destiny Guardian", "artifact", Color(0.9, 0.9, 0.95), Color(0.9, 0.75, 0.3)]],
	"famas": [["Default", "uncommon", Color(0.2, 0.2, 0.22), Color(0.4, 0.4, 0.45)], ["Custom", "mythic", Color(0.8, 0.12, 0.15), Color(0.2, 0.9, 0.8)]],
	"aug": [["Default", "uncommon", Color(0.2, 0.2, 0.22), Color(0.4, 0.4, 0.45)], ["Beast of Legend", "epic", Color(0.8, 0.2, 0.25), Color(0.95, 0.8, 0.4)]],
	"m249": [["Default", "uncommon", Color(0.15, 0.15, 0.17), Color(0.35, 0.35, 0.4)], ["Baa Baa Wolf", "rare", Color(0.95, 0.95, 0.95), Color(0.9, 0.15, 0.2)]],
	"mp40": [["Default", "uncommon", Color(0.15, 0.15, 0.17), Color(0.35, 0.35, 0.4)], ["Predatory Cobra", "artifact", Color(0.1, 0.1, 0.12), Color(0.95, 0.25, 0.15)]],
	"p90": [["Default", "uncommon", Color(0.15, 0.15, 0.17), Color(0.35, 0.35, 0.4)], ["Tune Blaster Orange", "mythic", Color(0.7, 0.12, 0.1), Color(1.0, 0.7, 0.15)]],
	"thompson": [["Default", "uncommon", Color(0.2, 0.15, 0.1), Color(0.4, 0.4, 0.4)], ["Cindered Colossus", "artifact", Color(0.1, 0.08, 0.1), Color(1.0, 0.4, 0.1)]],
	"spas12": [["Default", "uncommon", Color(0.12, 0.12, 0.13), Color(0.3, 0.3, 0.3)], ["Santa's Choice", "rare", Color(0.8, 0.1, 0.12), Color(0.95, 0.8, 0.2)]],
	"awm": [["Default", "uncommon", Color(0.1, 0.25, 0.15), Color(0.3, 0.3, 0.3)], ["Crimson Firehorn", "mythic", Color(0.85, 0.25, 0.1), Color(1.0, 0.75, 0.2)]],
	"kar98k": [["Default", "uncommon", Color(0.4, 0.25, 0.12), Color(0.3, 0.3, 0.3)], ["The Executioner", "epic", Color(0.8, 0.15, 0.1), Color(1.0, 0.85, 0.2)]],
	"m82b": [["Default", "uncommon", Color(0.15, 0.15, 0.17), Color(0.35, 0.35, 0.4)], ["Vampire Malevolence", "epic", Color(0.75, 0.1, 0.15), Color(0.95, 0.9, 0.85)]],
	"deserteagle": [["Default", "uncommon", Color(0.75, 0.75, 0.78), Color(0.15, 0.15, 0.15)], ["Glacier", "rare", Color(0.5, 0.8, 0.95), Color(0.9, 0.95, 1.0)]],
	"pan": [["Default", "uncommon", Color(0.25, 0.25, 0.28), Color(0.4, 0.25, 0.1)], ["Watermelon", "rare", Color(0.2, 0.75, 0.3), Color(0.9, 0.2, 0.3)]],
	"gloo": [["Default", "uncommon", Color(0.7, 0.85, 0.95), Color(0.9, 0.95, 1.0)], ["Aurous Dragon", "epic", Color(0.8, 0.2, 0.12), Color(0.95, 0.75, 0.25)]],
}

static func _by_id() -> Dictionary:
	var d := {}
	for w in LIST:
		d[w[0]] = w
	return d

static func get_entry(id: String) -> Array:
	for w in LIST:
		if w[0] == id:
			return w
	return LIST[0]

static func in_category(cat: String) -> Array:
	var out: Array = []
	for w in LIST:
		if w[2] == cat:
			out.append(w)
	return out

static func skins_for(id: String) -> Array:
	if SKINS.has(id):
		return SKINS[id]
	return [["Default", "uncommon", Color(0.17, 0.17, 0.19), Color(0.4, 0.4, 0.45)]]

static func labels_for(id: String) -> Array:
	var e := get_entry(id)
	match e[2]:
		"melee", "fist":
			return MELEE_LABELS
		"grenade":
			if id == "gloo":
				return ["Cover range", "Cover height", "Climbability"]
			if id == "smoke":
				return ["Duration", "Radius", "Fuse Time"]
			return ["Damage", "Radius", "Fuse Time"]
	return GUN_LABELS

static func is_primary(cat: String) -> bool:
	return PRIMARY_CATS.has(cat)

# ------------------------------------------------------------------ gameplay stats derived from the bars
const CAT_RULES := {
	"rifle": {"dmul": 1.0, "auto": true, "min_int": 0.06, "pellets": 1},
	"marksman": {"dmul": 1.7, "auto": false, "min_int": 0.30, "pellets": 1},
	"mg": {"dmul": 1.0, "auto": true, "min_int": 0.06, "pellets": 1},
	"smg": {"dmul": 0.8, "auto": true, "min_int": 0.05, "pellets": 1},
	"shotgun": {"dmul": 1.0, "auto": false, "min_int": 0.55, "pellets": 8},
	"sniper": {"dmul": 2.6, "auto": false, "min_int": 1.0, "pellets": 1},
	"pistol": {"dmul": 1.1, "auto": false, "min_int": 0.18, "pellets": 1},
	"others": {"dmul": 2.2, "auto": false, "min_int": 1.1, "pellets": 1},
}

static func stats(id: String, skin_idx := 0) -> Dictionary:
	var e := get_entry(id)
	var cat: String = e[2]
	var bars: Array = e[3]
	var sk: Array = skins_for(id)
	var skin: Array = sk[clampi(skin_idx, 0, sk.size() - 1)]
	var s := {"id": id, "name": e[1], "cat": cat, "skin": skin[0], "body": skin[2], "accent": skin[3], "melee": false, "grenade": false}
	if cat == "melee" or cat == "fist":
		s["melee"] = true
		s["auto"] = true
		s["dmg"] = 8.0 if cat == "fist" else lerpf(10.0, 40.0, bars[0] / 100.0)
		s["interval"] = lerpf(0.8, 0.3, bars[1] / 100.0)
		s["range"] = lerpf(1.8, 2.8, bars[2] / 100.0)
		s["move"] = lerpf(0.95, 1.1, bars[3] / 100.0)
		s["mag"] = 0
		s["reload"] = 0.0
		s["pellets"] = 1
		s["spread"] = 0.0
		s["pen"] = 0.0
		s["fov"] = 70.0
		return s
	if cat == "grenade":
		s["grenade"] = true
		s["bars"] = bars
		return s
	var r: Dictionary = CAT_RULES[cat]
	var shotgun := cat == "shotgun"
	var d: float = bars[0] / 100.0
	if shotgun:
		s["dmg"] = lerpf(4.0, 9.0, d)
	else:
		s["dmg"] = lerpf(6.0, 40.0, d) * float(r["dmul"])
	s["interval"] = maxf(float(r["min_int"]), lerpf(0.5, 0.06, bars[1] / 100.0))
	s["auto"] = r["auto"]
	s["pellets"] = r["pellets"]
	s["range"] = lerpf(15.0, 45.0, bars[2] / 100.0) if shotgun else lerpf(40.0, 200.0, bars[2] / 100.0)
	var acc: float = bars[3] / 100.0
	s["spread"] = lerpf(0.13, 0.05, acc) if shotgun else lerpf(0.03, 0.0, acc) * (0.0 if cat == "sniper" else 1.0)
	s["move"] = lerpf(0.85, 1.06, bars[4] / 100.0)
	s["mag"] = int(round(lerpf(2.0, 10.0, bars[5] / 100.0))) if shotgun else int(round(lerpf(4.0, 60.0, bars[5] / 100.0)))
	s["reload"] = lerpf(3.2, 1.0, bars[6] / 100.0)
	s["pen"] = bars[7] / 100.0
	s["fov"] = 22.0 if cat == "sniper" else (30.0 if cat == "marksman" or cat == "others" else 40.0)
	return s

# ------------------------------------------------------------------ placeholder 3D models (point along -Z)
static func _mi(parent: Node3D, mesh: Mesh, pos: Vector3, col: Color, rot := Vector3.ZERO) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	m.mesh = mesh
	m.position = pos
	m.rotation_degrees = rot
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.metallic = 0.3
	mat.roughness = 0.6
	m.material_override = mat
	parent.add_child(m)
	return m

static func _bx(x: float, y: float, z: float) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = Vector3(x, y, z)
	return b

static func _cyl(r: float, h: float) -> CylinderMesh:
	var c := CylinderMesh.new()
	c.top_radius = r
	c.bottom_radius = r
	c.height = h
	return c

static func build_model(s: Dictionary) -> Node3D:
	var root := Node3D.new()
	var body: Color = s["body"]
	var acc: Color = s["accent"]
	var dark := Color(0.08, 0.08, 0.09)
	var id: String = s["id"]
	match String(s["cat"]):
		"rifle", "mg":
			_mi(root, _bx(0.09, 0.11, 0.55), Vector3(0, 0, 0), body)
			_mi(root, _bx(0.04, 0.04, 0.45), Vector3(0, 0.02, -0.5), dark)
			_mi(root, _bx(0.07, 0.14, 0.22), Vector3(0, -0.03, 0.38), body)
			_mi(root, _bx(0.06, 0.2, 0.08), Vector3(0, -0.15, -0.05), acc)
			_mi(root, _bx(0.05, 0.1, 0.06), Vector3(0, -0.1, 0.15), dark)
			if s["cat"] == "mg":
				_mi(root, _cyl(0.11, 0.1), Vector3(0, -0.14, -0.05), acc, Vector3(0, 0, 90))
		"marksman", "sniper":
			var long: float = 1.0 if s["cat"] == "sniper" else 0.8
			_mi(root, _bx(0.08, 0.1, 0.6), Vector3(0, 0, 0.05), body)
			_mi(root, _bx(0.035, 0.035, long), Vector3(0, 0.02, -0.3 - long / 2.0), dark)
			_mi(root, _bx(0.07, 0.15, 0.25), Vector3(0, -0.03, 0.42), body)
			_mi(root, _cyl(0.04, 0.32), Vector3(0, 0.1, -0.05), acc, Vector3(90, 0, 0))
			_mi(root, _bx(0.05, 0.14, 0.06), Vector3(0, -0.12, 0.0), dark)
		"smg":
			_mi(root, _bx(0.09, 0.12, 0.36), Vector3(0, 0, 0), body)
			_mi(root, _bx(0.035, 0.035, 0.2), Vector3(0, 0.02, -0.28), dark)
			_mi(root, _bx(0.06, 0.2, 0.07), Vector3(0, -0.15, 0.0), acc)
			_mi(root, _bx(0.05, 0.12, 0.06), Vector3(0, -0.1, 0.14), dark)
		"shotgun":
			_mi(root, _bx(0.09, 0.1, 0.45), Vector3(0, 0, 0.05), body)
			_mi(root, _bx(0.05, 0.05, 0.7), Vector3(0, 0.02, -0.5), dark)
			_mi(root, _bx(0.08, 0.07, 0.2), Vector3(0, -0.06, -0.3), acc)
			_mi(root, _bx(0.07, 0.14, 0.22), Vector3(0, -0.03, 0.36), body)
		"pistol":
			_mi(root, _bx(0.05, 0.07, 0.24), Vector3(0, 0.02, 0), body)
			_mi(root, _bx(0.045, 0.14, 0.06), Vector3(0, -0.08, 0.08), dark, Vector3(-12, 0, 0))
			_mi(root, _bx(0.03, 0.03, 0.08), Vector3(0, 0.02, -0.16), acc)
		"melee":
			if id == "pan":
				_mi(root, _cyl(0.17, 0.03), Vector3(0, 0, -0.35), body, Vector3(90, 0, 0))
				_mi(root, _bx(0.04, 0.04, 0.35), Vector3(0, 0, -0.05), acc)
			else:
				_mi(root, _bx(0.03, 0.06, 0.2), Vector3(0, 0, 0.05), acc)
				_mi(root, _bx(0.02, 0.07, 0.75 if id != "parang" else 0.5), Vector3(0, 0, -0.45), body)
				if id == "scythe":
					_mi(root, _bx(0.02, 0.07, 0.35), Vector3(0, 0, -0.9), body, Vector3(0, 40, 0))
		"fist":
			_mi(root, _bx(0.12, 0.12, 0.14), Vector3(0, 0, 0), body)
		"grenade":
			if id == "grenade":
				var sm := SphereMesh.new()
				sm.radius = 0.1
				sm.height = 0.2
				_mi(root, sm, Vector3.ZERO, Color(0.2, 0.4, 0.2))
				_mi(root, _bx(0.02, 0.06, 0.02), Vector3(0, 0.11, 0), acc)
			elif id == "smoke":
				_mi(root, _cyl(0.07, 0.25), Vector3.ZERO, Color(0.5, 0.52, 0.55))
				_mi(root, _cyl(0.075, 0.05), Vector3(0, 0.1, 0), dark)
			else:
				_mi(root, _bx(0.7, 0.45, 0.2), Vector3.ZERO, body)
				_mi(root, _bx(0.35, 0.25, 0.22), Vector3.ZERO, acc)
		"others":
			_mi(root, _bx(0.07, 0.09, 0.6), Vector3(0, 0, 0), body)
			_mi(root, _bx(0.6, 0.04, 0.05), Vector3(0, 0, -0.3), acc)
			_mi(root, _bx(0.3, 0.04, 0.04), Vector3(-0.28, 0, -0.45), acc, Vector3(0, -35, 0))
			_mi(root, _bx(0.3, 0.04, 0.04), Vector3(0.28, 0, -0.45), acc, Vector3(0, 35, 0))
	return root
