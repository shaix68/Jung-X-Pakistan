extends Control
## On-screen touch controls + HUD (layout modelled on the reference "HUD 2" screenshot).
## Handles raw multi-touch itself.

const Settings = preload("res://scripts/settings.gd")

var game
var move_vec := Vector2.ZERO
var look_delta := Vector2.ZERO
var held := {}
var taps := {}
var touches := {}   # touch index -> role ("stick", "look" or button name)
var toast_text := ""
var toast_t := 0.0
var hit_flash := 0.0
var dmg_flash := 0.0
var sb_panel: StyleBoxFlat

const LABELS := {"fire": "FIRE", "scope": "SCOPE", "jump": "JUMP", "crouch": "CROUCH", "prone": "PRONE", "reload": "RELOAD", "swap": "SWAP", "grenade": "GRENADE", "medkit": "MEDKIT"}
const COLORS := {
	"fire": Color(1.0, 0.35, 0.2), "scope": Color(0.9, 0.9, 0.9), "jump": Color(0.3, 0.7, 1.0), "crouch": Color(0.3, 0.7, 1.0),
	"prone": Color(0.3, 0.7, 1.0), "reload": Color(0.9, 0.9, 0.3), "swap": Color(0.9, 0.9, 0.3), "grenade": Color(0.5, 0.75, 0.35),
	"medkit": Color(0.3, 0.9, 0.5), "skill1": Color(0.7, 0.4, 1.0), "skill2": Color(0.7, 0.4, 1.0), "skill3": Color(0.7, 0.4, 1.0),
}
const MAP_SCALE := 0.9   # minimap pixels per metre

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	for b in Settings.BUTTONS:
		held[b] = false
	sb_panel = StyleBoxFlat.new()
	sb_panel.bg_color = Color(0, 0, 0, 0.5)
	sb_panel.set_corner_radius_all(6)

func take(bn: String) -> bool:
	if taps.get(bn, false):
		taps[bn] = false
		return true
	return false

func toast(t: String) -> void:
	toast_text = t
	toast_t = 3.0

func btn_center(bn: String) -> Vector2:
	var l: Array = Settings.layout[bn]
	return Vector2(l[0] * size.x, l[1] * size.y)

func btn_radius(bn: String) -> float:
	var l: Array = Settings.layout[bn]
	return (70.0 if bn == "stick" else 44.0) * l[2]

func btn_visible(bn: String) -> bool:
	if bn.begins_with("skill"):
		var i: int = bn.substr(5).to_int() - 1
		var sk: Array = game.chardata["skills"]
		return i < sk.size()
	return true

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			_press(event.index, event.position)
		else:
			_release(event.index)
	elif event is InputEventScreenDrag:
		_drag(event.index, event.position, event.relative)

func _press(idx: int, p: Vector2) -> void:
	for bn in Settings.BUTTONS:
		if bn == "stick" or not btn_visible(bn):
			continue
		if p.distance_to(btn_center(bn)) <= btn_radius(bn) * 1.15:
			touches[idx] = bn
			held[bn] = true
			taps[bn] = true
			return
	if p.x < size.x * 0.45 and not touches.values().has("stick"):
		touches[idx] = "stick"
		_drag(idx, p, Vector2.ZERO)
	else:
		touches[idx] = "look"

func _drag(idx: int, p: Vector2, rel: Vector2) -> void:
	var role: String = touches.get(idx, "")
	if role == "stick":
		var v := (p - btn_center("stick")) / btn_radius("stick")
		move_vec = v.limit_length(1.0)
	elif role == "look":
		look_delta += rel

func _release(idx: int) -> void:
	var role: String = touches.get(idx, "")
	if role == "stick":
		move_vec = Vector2.ZERO
	elif role != "" and role != "look":
		held[role] = false
	touches.erase(idx)

func _process(delta: float) -> void:
	# the HUD sits under a CanvasLayer, so keep it exactly as big as the screen
	var vs := get_viewport_rect().size
	if size != vs:
		position = Vector2.ZERO
		size = vs
	toast_t = maxf(0.0, toast_t - delta)
	hit_flash = maxf(0.0, hit_flash - delta)
	dmg_flash = maxf(0.0, dmg_flash - delta)
	queue_redraw()

# ------------------------------------------------------------------ drawing helpers
func _txt(font: Font, pos: Vector2, text: String, fsize: int, col: Color, align := HORIZONTAL_ALIGNMENT_LEFT, width := -1.0) -> void:
	draw_string(font, pos, text, align, width, fsize, col)

func _bar(r: Rect2, frac: float, col: Color, back := Color(0, 0, 0, 0.55)) -> void:
	draw_rect(r, back)
	draw_rect(Rect2(r.position, Vector2(r.size.x * clampf(frac, 0.0, 1.0), r.size.y)), col)

func _lines_label(font: Font, c: Vector2, r: float, lines: Array, fsize: int, col: Color) -> void:
	var total := float(lines.size()) * (fsize + 2.0)
	var y := c.y - total / 2.0 + fsize
	for l in lines:
		_txt(font, Vector2(c.x - r, y), str(l), fsize, col, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0)
		y += fsize + 2.0

func _draw() -> void:
	if game == null or game.chardata.is_empty():
		return
	var font := ThemeDB.fallback_font
	var op: float = Settings.opacity
	var white := Color(1, 1, 1, minf(1.0, op + 0.2))
	var R := size.x
	var H := size.y
	var training: bool = game.mode == "training"

	if dmg_flash > 0.0:
		draw_rect(Rect2(Vector2.ZERO, size), Color(1, 0, 0, dmg_flash * 0.8))

	_draw_minimap(font)
	_draw_top_left(font)
	_draw_top_right(font, R, training)
	_draw_bottom_center(font, R, H)
	_draw_feed(font, R, H)
	_draw_controls(font, op, white)
	_draw_crosshair(font, R, H, training)

# ------------------------------------------------------------------ minimap + squad
func _draw_minimap(font: Font) -> void:
	var m := Rect2(44, 6, 170, 136)
	var mc := m.position + m.size / 2.0
	var pp := Vector2(game.player.global_position.x, game.player.global_position.z)
	draw_rect(m, Color(0.28, 0.46, 0.34, 0.9))
	# river (world x -47..-33, bridge at |z| < 4)
	var rx0 := clampf(mc.x + (-47.0 - pp.x) * MAP_SCALE, m.position.x, m.end.x)
	var rx1 := clampf(mc.x + (-33.0 - pp.x) * MAP_SCALE, m.position.x, m.end.x)
	if rx1 > rx0:
		draw_rect(Rect2(rx0, m.position.y, rx1 - rx0, m.size.y), Color(0.25, 0.5, 0.8, 0.9))
		var by0 := clampf(mc.y + (-4.0 - pp.y) * MAP_SCALE, m.position.y, m.end.y)
		var by1 := clampf(mc.y + (4.0 - pp.y) * MAP_SCALE, m.position.y, m.end.y)
		if by1 > by0:
			draw_rect(Rect2(rx0, by0, rx1 - rx0, by1 - by0), Color(0.55, 0.42, 0.28, 0.95))
	# safe zone ring (only segments inside the map box)
	if game.mode != "training":
		var zc: Vector2 = game.zone_center
		var zr: float = game.zone_radius
		var prev := Vector2.INF
		for k in 49:
			var a := TAU * float(k) / 48.0
			var wp := zc + Vector2(cos(a), sin(a)) * zr
			var sp := mc + (wp - pp) * MAP_SCALE
			if m.has_point(sp) and prev != Vector2.INF:
				draw_line(prev, sp, Color(0.4, 0.75, 1.0, 0.95), 2.0)
			prev = sp if m.has_point(sp) else Vector2.INF
	# enemies
	for b in game.bots:
		if not b.alive:
			continue
		var bp := Vector2(b.node.global_position.x, b.node.global_position.z)
		var sp := mc + (bp - pp) * MAP_SCALE
		var marked: bool = b.get("mark_t", 0.0) > 0.0
		if m.has_point(sp) and (marked or (bp - pp).length() < 66.0):
			draw_circle(sp, 4.0 if marked else 3.0, Color(1, 0.9, 0.2) if marked else Color(1, 0.3, 0.3))
		elif marked or game.radar_t > 0.0:
			var e := Vector2(clampf(sp.x, m.position.x + 3.0, m.end.x - 3.0), clampf(sp.y, m.position.y + 3.0, m.end.y - 3.0))
			draw_circle(e, 3.0, Color(1, 0.9, 0.2) if marked else Color(1, 0.6, 0.2))
	# player arrow
	var fwd := Vector2(-sin(game.yaw), -cos(game.yaw))
	var side := Vector2(-fwd.y, fwd.x)
	draw_colored_polygon(PackedVector2Array([mc + fwd * 9.0, mc - fwd * 5.0 + side * 5.0, mc - fwd * 5.0 - side * 5.0]), Color(0.3, 1, 0.4))
	draw_rect(m, Color(1, 1, 1, 0.7), false, 2.0)
	if game.mode != "training":
		var to_z: Vector2 = game.zone_center - pp
		var inside: bool = to_z.length() <= game.zone_radius
		_txt(font, Vector2(m.position.x, m.end.y + 14.0), ("IN ZONE" if inside else "OUTSIDE ZONE!") + "  %dm" % int(to_z.length()), 13, Color(0.4, 1, 0.5) if inside else Color(1, 0.4, 0.4), HORIZONTAL_ALIGNMENT_CENTER, m.size.x)
	# squad row (solo: just you)
	var row := Rect2(44, 160, 170, 24)
	draw_style_box(sb_panel, row)
	draw_rect(Rect2(row.position, Vector2(22, 24)), Color(0.2, 0.7, 0.9, 0.9))
	_txt(font, row.position + Vector2(0, 17), "1", 15, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 22.0)
	_txt(font, row.position + Vector2(28, 12), "YOU - " + String(game.chardata["name"]), 12, Color.WHITE)
	_bar(Rect2(row.position + Vector2(28, 16), Vector2(136, 5)), game.hp / 100.0, Color(0.3, 0.9, 0.4))
	var pas: Dictionary = game.chardata["passive"]
	if not pas.is_empty():
		_txt(font, Vector2(44, 200), "Passive: " + String(pas["name"]), 13, Color(0.7, 1.0, 0.8, 0.95))

func _draw_top_left(font: Font) -> void:
	# decorative icon cluster (sound, emote, mic, pet, chat) + live sprint indicator
	var icons := [["SND", Vector2(250, 26)], ["EMO", Vector2(290, 26)], ["MIC", Vector2(330, 26)], ["PET", Vector2(250, 66)], ["MSG", Vector2(290, 66)], ["RUN", Vector2(330, 66)]]
	for ic in icons:
		var p: Vector2 = ic[1]
		var on: bool = ic[0] == "RUN" and game.sprinting
		draw_circle(p, 17.0, Color(0.1, 0.4, 0.8, 0.75) if on else Color(0, 0, 0, 0.45))
		draw_arc(p, 17.0, 0, TAU, 24, Color(1, 1, 1, 0.5), 1.5)
		_txt(font, p + Vector2(-17, 4), String(ic[0]), 10, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 34.0)

# ------------------------------------------------------------------ top right: weapon, alive/kills, items
func _draw_top_right(font: Font, R: float, training: bool) -> void:
	var x0 := R - 300.0
	# weapon card
	var card := Rect2(x0, 56, 290, 62)
	draw_style_box(sb_panel, card)
	var cw: Dictionary = game._w()
	var wname: String = String(cw["name"]).to_upper()
	if cw["melee"]:
		_txt(font, card.position + Vector2(14, 42), "MELEE", 30, Color.WHITE)
	else:
		var res: String = "INF" if training else str(game.reserve)
		_txt(font, card.position + Vector2(14, 42), "%d" % game.ammo, 38, Color(1, 1, 1))
		_txt(font, card.position + Vector2(80, 42), "/" + res, 22, Color(0.8, 0.8, 0.8))
	_txt(font, card.position + Vector2(130, 24), wname, 16, Color(1, 0.85, 0.3), HORIZONTAL_ALIGNMENT_RIGHT, 150.0)
	var st: String = "RELOADING..." if game.reloading > 0.0 else ("SCOPED" if game.scoped else String(cw["skin"]).to_upper())
	_txt(font, card.position + Vector2(130, 46), st, 13, Color(0.7, 0.9, 1.0), HORIZONTAL_ALIGNMENT_RIGHT, 150.0)
	if not cw["melee"]:
		var frac: float = 1.0 - game.reloading / maxf(0.1, float(cw["reload"])) if game.reloading > 0.0 else float(game.ammo) / float(maxi(1, int(cw["mag"])))
		_bar(Rect2(card.position + Vector2(8, 54), Vector2(274, 4)), frac, Color(1, 0.85, 0.3), Color(0.3, 0.3, 0.3, 0.6))
	# weapon slots (p1, p2, pistol, melee)
	var wx := x0
	for sl in game.SLOTS:
		var slot := Rect2(wx, 124, 70, 40)
		draw_style_box(sb_panel, slot)
		if sl == game.weapon:
			draw_rect(slot, Color(1, 0.85, 0.3, 0.9), false, 2.0)
		var lw: Dictionary = game.loadout[sl]
		_txt(font, slot.position + Vector2(0, 16), String(lw["name"]), 11, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, slot.size.x)
		var ammo_s := "-"
		if not lw["melee"]:
			ammo_s = "%d/%s" % [game.wstate[sl]["ammo"], "INF" if training else str(game.wstate[sl]["reserve"])]
		_txt(font, slot.position + Vector2(0, 33), ammo_s, 11, Color(0.8, 0.8, 0.8), HORIZONTAL_ALIGNMENT_CENTER, slot.size.x)
		wx += 73.0
	# alive / eliminations bar
	var bar := Rect2(x0, 172, 290, 24)
	draw_rect(Rect2(bar.position, Vector2(145, 24)), Color(0.1, 0.6, 0.75, 0.9))
	draw_rect(Rect2(bar.position + Vector2(145, 0), Vector2(145, 24)), Color(0.75, 0.15, 0.15, 0.9))
	_txt(font, bar.position + Vector2(0, 17), "ALIVE  %d" % game._alive_count(), 15, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 145.0)
	_txt(font, bar.position + Vector2(145, 17), "KILLS  %d" % game.kills, 15, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 145.0)
	draw_rect(bar, Color(1, 0.85, 0.3, 0.9), false, 2.0)
	# item slots (2 x 2)
	var items := [
		["MEDKIT", "x%d" % game.medkits, Color(0.3, 0.9, 0.5)],
		[String(Settings.loadout.get("grenade", "grenade")).to_upper().replace("GLOO", "GLOO WALL"), "x%d" % game.grenades, Color(0.55, 0.8, 0.35)],
		[String(game.loadout["p1"]["name"]).to_upper() + " AMMO", "INF" if training else str(game.wstate["p1"]["reserve"]), Color(1, 0.85, 0.3)],
		[String(game.loadout["p2"]["name"]).to_upper() + " AMMO", "INF" if training else str(game.wstate["p2"]["reserve"]), Color(1, 0.6, 0.3)],
	]
	for k in 4:
		var slot := Rect2(x0 + float(k % 2) * 148.0, 204 + float(k / 2) * 52.0, 142, 46)
		draw_style_box(sb_panel, slot)
		draw_rect(Rect2(slot.position, Vector2(4, 46)), items[k][2])
		_txt(font, slot.position + Vector2(12, 19), String(items[k][0]), 12, Color(0.85, 0.85, 0.85))
		_txt(font, slot.position + Vector2(12, 40), String(items[k][1]), 18, Color.WHITE)
	# match info (top centre)
	var info: String = "TRAINING GROUND" if training else ""
	if not training:
		info = ("ZONE SHRINKING!" if game.zone_shrinking else "Zone shrinks in %ds" % ceili(game.zone_timer)) if game.zone_stage < game.ZONE_RADII.size() else "FINAL ZONE"
	_txt(font, Vector2(0, 26), info, 20, Color(0.5, 0.85, 1.0), HORIZONTAL_ALIGNMENT_CENTER, R)
	if toast_t > 0.0:
		_txt(font, Vector2(0, 62), toast_text, 22, Color(1, 0.9, 0.4), HORIZONTAL_ALIGNMENT_CENTER, R)

# ------------------------------------------------------------------ bottom centre: EP / HP / status
func _draw_bottom_center(font: Font, R: float, H: float) -> void:
	var bw := 280.0
	var bx := R / 2.0 - bw / 2.0
	# status chips
	var chips: Array = []
	if game.shield_t > 0.0:
		chips.append("SHIELD %ds" % ceili(game.shield_t))
	if game.field_t > 0.0:
		chips.append("FIELD %ds" % ceili(game.field_t))
	if game.speed_t > 0.0:
		chips.append("SPEED %ds" % ceili(game.speed_t))
	if game.remix_t > 0.0:
		chips.append("REMIX %ds" % ceili(game.remix_t))
	if game.radar_t > 0.0:
		chips.append("RADAR %ds" % ceili(game.radar_t))
	if game.bonus_t > 0.0:
		chips.append("FIRST-SHOT BONUS")
	if game.rush_window > 0.0:
		chips.append("RUSH RESET WINDOW")
	if game.sprinting:
		chips.append("SPRINT")
	if chips.size() > 0:
		_txt(font, Vector2(0, H - 70.0), "   |   ".join(chips), 14, Color(1, 0.9, 0.5), HORIZONTAL_ALIGNMENT_CENTER, R)
	if game.use_t > 0.0:
		_txt(font, Vector2(bx, H - 86.0), "USING MEDKIT...", 13, Color(0.5, 1, 0.6))
		_bar(Rect2(bx, H - 82.0, bw, 6), 1.0 - game.use_t / game.use_total, Color(0.3, 0.9, 0.5))
	_txt(font, Vector2(bx, H - 46.0), "EP %d/%d" % [int(game.ep), int(game.EP_MAX)], 13, Color(1, 0.85, 0.3))
	_bar(Rect2(bx, H - 42.0, bw, 7), game.ep / game.EP_MAX, Color(1, 0.7, 0.15))
	_txt(font, Vector2(bx, H - 24.0), "HP %d/100" % ceili(maxf(game.hp, 0.0)), 13, Color(1, 1, 1))
	_bar(Rect2(bx, H - 20.0, bw, 9), game.hp / 100.0, Color(0.95, 0.95, 0.95) if game.hp > 35.0 else Color(1, 0.3, 0.3))

# ------------------------------------------------------------------ kill feed
func _draw_feed(font: Font, R: float, H: float) -> void:
	var y := H - 165.0
	for e in game.feed:
		var col := Color(1, 0.9, 0.4) if e["you"] else Color(1, 1, 1, 0.9)
		var tw := 270.0
		draw_rect(Rect2(R / 2.0 - tw / 2.0, y - 15.0, tw, 20.0), Color(0, 0, 0, 0.4))
		_txt(font, Vector2(R / 2.0 - tw / 2.0, y), String(e["text"]), 14, col, HORIZONTAL_ALIGNMENT_CENTER, tw)
		y += 22.0

# ------------------------------------------------------------------ touch controls
func _draw_controls(font: Font, op: float, white: Color) -> void:
	# stick
	var sc := btn_center("stick")
	var sr := btn_radius("stick")
	draw_circle(sc, sr, Color(1, 1, 1, op * 0.25))
	draw_arc(sc, sr, 0, TAU, 40, Color(1, 1, 1, op), 2.0)
	draw_circle(sc + move_vec * sr * 0.6, sr * 0.35, Color(1, 1, 1, op * 0.7))
	for bn in Settings.BUTTONS:
		if bn == "stick" or not btn_visible(bn):
			continue
		var c := btn_center(bn)
		var r := btn_radius(bn)
		var col: Color = COLORS[bn]
		var active: bool = held[bn]
		var lines: Array = []
		var cd := 0.0
		if bn.begins_with("skill"):
			var i: int = bn.substr(5).to_int() - 1
			lines = String(game.chardata["skills"][i]["name"]).split(" ")
			cd = game.skill_cd[i]
		elif bn == "medkit":
			lines = ["MEDKIT", "x%d" % game.medkits]
			active = active or game.use_t > 0.0
		elif bn == "grenade":
			lines = [String(Settings.loadout.get("grenade", "grenade")).replace("gloo", "GLOO").replace("smoke", "SMOKE").replace("grenade", "GRENADE"), "x%d" % game.grenades]
		elif bn == "swap":
			lines = ["SWAP", String(game._w()["name"])]
		elif bn == "scope":
			active = active or game.scoped
			lines = [LABELS[bn]]
		elif bn == "crouch":
			active = active or game.crouching
			lines = [LABELS[bn]]
		elif bn == "prone":
			active = active or game.prone
			lines = [LABELS[bn]]
		elif bn == "fire":
			lines = ["FIRE"] if not game._w()["melee"] else ["ATTACK"]
		else:
			lines = [LABELS[bn]]
		if active:
			col = col.lightened(0.4)
		draw_circle(c, r, Color(col, op * 0.6))
		draw_arc(c, r, 0, TAU, 32, Color(1, 1, 1, op), 3.0 if bn == "fire" else 2.0)
		_lines_label(font, c, r, lines, 15 if bn == "fire" else 12, white)
		if bn == "medkit" and game.use_t > 0.0:
			draw_arc(c, r + 4.0, -PI / 2.0, -PI / 2.0 + TAU * (1.0 - game.use_t / game.use_total), 32, Color(0.5, 1, 0.6), 4.0)
		if cd > 0.0:
			draw_circle(c, r, Color(0, 0, 0, 0.6))
			_txt(font, c + Vector2(-r, 10), "%d" % ceili(cd), 26, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER, r * 2.0)

func _draw_crosshair(_font: Font, R: float, H: float, _training: bool) -> void:
	var m := Vector2(R, H) / 2.0
	var cc := Color(1, 1, 1, 0.85)
	if game.scoped:
		draw_arc(m, 26.0, 0, TAU, 40, cc, 2.0)
		draw_circle(m, 2.0, Color(1, 0.2, 0.2))
	else:
		draw_line(m + Vector2(-14, 0), m + Vector2(-5, 0), cc, 2.0)
		draw_line(m + Vector2(14, 0), m + Vector2(5, 0), cc, 2.0)
		draw_line(m + Vector2(0, -14), m + Vector2(0, -5), cc, 2.0)
		draw_line(m + Vector2(0, 14), m + Vector2(0, 5), cc, 2.0)
	if hit_flash > 0.0:
		var hc := Color(1, 0.2, 0.2)
		draw_line(m + Vector2(-9, -9), m + Vector2(9, 9), hc, 3.0)
		draw_line(m + Vector2(9, -9), m + Vector2(-9, 9), hc, 3.0)
