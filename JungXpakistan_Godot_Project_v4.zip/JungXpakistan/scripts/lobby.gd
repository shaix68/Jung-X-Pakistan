extends Control
## Lobby: character select, Skill Hub, rank, missions, settings, control customization.

signal start_pressed(mode)

const Settings = preload("res://scripts/settings.gd")
const Data = preload("res://scripts/data.gd")
const Model = preload("res://scripts/character_model.gd")
const Customize = preload("res://scripts/customize.gd")
const Armory = preload("res://scripts/armory.gd")
const Vault = preload("res://scripts/vault.gd")
const Outfit = preload("res://scripts/outfit.gd")

var name_label: Label
var skill_box: VBoxContainer
var rank_label: Label
var mission_label: Label
var model_root: Node3D
var overlay: Control
var char_list: GridContainer
var free_btn: Button

func _ready() -> void:
	Settings.load_all()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_build()
	_refresh()

func _process(delta: float) -> void:
	if model_root:
		model_root.rotate_y(delta * 0.6)

func _btn(text: String, pos: Vector2, sz: Vector2, col: Color) -> Button:
	var b := Button.new()
	b.text = text
	b.position = pos
	b.size = sz
	var sb := StyleBoxFlat.new()
	sb.bg_color = col
	sb.set_corner_radius_all(8)
	b.add_theme_stylebox_override("normal", sb)
	b.add_theme_stylebox_override("hover", sb)
	b.add_theme_stylebox_override("pressed", sb)
	b.add_theme_font_size_override("font_size", 22)
	return b

func _build() -> void:
	var bg := ColorRect.new()
	bg.color = Color(0.06, 0.04, 0.15)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var tri := Polygon2D.new()
	tri.polygon = PackedVector2Array([Vector2(640, 80), Vector2(960, 600), Vector2(320, 600)])
	tri.color = Color(0.45, 0.25, 0.95, 0.30)
	add_child(tri)

	var title := Label.new()
	title.text = "JUNGXPAKISTAN"
	title.position = Vector2(30, 16)
	title.add_theme_font_size_override("font_size", 40)
	title.add_theme_color_override("font_color", Color(1.0, 0.85, 0.3))
	add_child(title)

	# 3D character preview
	var svc := SubViewportContainer.new()
	svc.stretch = true
	svc.position = Vector2(400, 70)
	svc.size = Vector2(480, 520)
	add_child(svc)
	var vp := SubViewport.new()
	vp.transparent_bg = true
	vp.own_world_3d = true
	svc.add_child(vp)
	var cam := Camera3D.new()
	vp.add_child(cam)
	cam.look_at_from_position(Vector3(0, 1.0, 2.7), Vector3(0, 0.95, 0))
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-35, 30, 0)
	vp.add_child(light)
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.7, 0.7, 0.85)
	env.ambient_light_energy = 0.8
	we.environment = env
	vp.add_child(we)
	model_root = Node3D.new()
	vp.add_child(model_root)

	# character switch
	var prev := _btn("<", Vector2(420, 610), Vector2(60, 50), Color(0.25, 0.2, 0.45))
	prev.pressed.connect(func(): _switch_char(-1))
	add_child(prev)
	var next := _btn(">", Vector2(800, 610), Vector2(60, 50), Color(0.25, 0.2, 0.45))
	next.pressed.connect(func(): _switch_char(1))
	add_child(next)
	name_label = Label.new()
	name_label.position = Vector2(495, 620)
	name_label.size = Vector2(290, 40)
	name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_label.add_theme_font_size_override("font_size", 22)
	add_child(name_label)

	# left menu
	var train := _btn("TRAINING GROUND", Vector2(30, 120), Vector2(300, 56), Color(0.2, 0.35, 0.55))
	train.pressed.connect(func(): start_pressed.emit("training"))
	add_child(train)
	var ctl := _btn("CUSTOMIZE CONTROLS", Vector2(30, 190), Vector2(300, 56), Color(0.2, 0.35, 0.55))
	ctl.pressed.connect(_open_customize)
	var wbtn := _btn("WEAPON", Vector2(470, 16), Vector2(150, 48), Color(0.55, 0.3, 0.15))
	wbtn.pressed.connect(_open_armory)
	var vbtn := _btn("VAULT", Vector2(630, 16), Vector2(150, 48), Color(0.35, 0.2, 0.55))
	vbtn.pressed.connect(_open_vault)
	add_child(ctl)
	var st := _btn("SETTINGS", Vector2(30, 260), Vector2(300, 56), Color(0.2, 0.35, 0.55))
	st.pressed.connect(_open_settings)
	add_child(st)
	mission_label = Label.new()
	mission_label.position = Vector2(920, 440)
	mission_label.add_theme_font_size_override("font_size", 14)
	add_child(mission_label)

	# character picker (grid, scrollable)
	var cl := Label.new()
	cl.text = "CHARACTERS"
	cl.position = Vector2(30, 330)
	cl.add_theme_font_size_override("font_size", 20)
	add_child(cl)
	var scroll := ScrollContainer.new()
	scroll.position = Vector2(30, 360)
	scroll.size = Vector2(320, 340)
	add_child(scroll)
	char_list = GridContainer.new()
	char_list.columns = 2
	scroll.add_child(char_list)
	for i in Data.CHARS.size():
		var cb := Button.new()
		cb.text = Data.CHARS[i]["name"]
		cb.custom_minimum_size = Vector2(150, 44)
		cb.add_theme_font_size_override("font_size", 18)
		var idx := i
		cb.pressed.connect(func(): _pick_char(idx))
		char_list.add_child(cb)

	# right: skill hub + rank
	var panel := PanelContainer.new()
	panel.position = Vector2(920, 70)
	panel.custom_minimum_size = Vector2(330, 0)
	add_child(panel)
	var box := VBoxContainer.new()
	panel.add_child(box)
	var hub := Label.new()
	hub.text = "SKILL HUB"
	hub.add_theme_font_size_override("font_size", 26)
	box.add_child(hub)
	skill_box = VBoxContainer.new()
	box.add_child(skill_box)
	rank_label = Label.new()
	rank_label.position = Vector2(920, 405)
	rank_label.add_theme_font_size_override("font_size", 24)
	rank_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.3))
	add_child(rank_label)

	var start := _btn("START  (SOLO • 30 PLAYERS)", Vector2(920, 570), Vector2(330, 90), Color(0.95, 0.72, 0.1))
	start.add_theme_color_override("font_color", Color(0.1, 0.07, 0.0))
	start.pressed.connect(func(): start_pressed.emit("solo"))
	add_child(start)

func _switch_char(d: int) -> void:
	Settings.char_idx = posmod(Settings.char_idx + d, Data.CHARS.size())
	Settings.save_all()
	_refresh()

func _pick_char(i: int) -> void:
	Settings.char_idx = i
	Settings.save_all()
	_refresh()

func _cycle_free_skill() -> void:
	var src: Array = Data.skill_sources()
	var pos := src.find(Settings.free_idx)
	Settings.free_idx = src[(pos + 1) % src.size()]
	Settings.save_all()
	_refresh()

func _skill_label(text: String, w := 310.0) -> Label:
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(w, 0)
	return l

func _refresh() -> void:
	var base: Dictionary = Data.CHARS[Settings.char_idx]
	var c: Dictionary = Data.effective(Settings.char_idx, Settings.free_idx)
	name_label.text = "%s   %d/%d" % [Data.display_name(base), Settings.char_idx + 1, Data.CHARS.size()]
	for ch in skill_box.get_children():
		ch.queue_free()
	if base.get("free_skill", false):
		var src: Dictionary = Data.CHARS[Settings.free_idx]
		skill_box.add_child(_skill_label("%s has no skill of its own.\nEquipped ability from: %s" % [base["name"], src["name"]]))
		var fb := Button.new()
		fb.text = "CHANGE EQUIPPED SKILL  >"
		fb.custom_minimum_size = Vector2(310, 40)
		fb.pressed.connect(_cycle_free_skill)
		skill_box.add_child(fb)
	var pas: Dictionary = c["passive"]
	if not pas.is_empty():
		skill_box.add_child(_skill_label("[PASSIVE] %s  (%s)\n%s\n" % [pas["name"], pas["tags"], pas["desc"]]))
	var i := 1
	for s in c["skills"]:
		skill_box.add_child(_skill_label("[ACTIVE %d] %s  (%s) - cooldown %ds\n%s\n" % [i, s["name"], s["tags"], int(s["cd"]), s["desc"]]))
		i += 1
	if pas.is_empty() and c["skills"].is_empty():
		skill_box.add_child(_skill_label("No skill."))
	for ch in model_root.get_children():
		ch.queue_free()
	model_root.add_child(Model.build(Outfit.apply(c, Outfit.get_sel(Settings.outfits, String(base["name"])))))
	var t := Settings.tier_index()
	rank_label.text = "RANK: %s  (%d RP)" % [Settings.TIERS[t], Settings.rp]
	mission_label.text = "MISSIONS\n- Play 3 matches: %d/3\n- 10 eliminations: %d/10\n- Use skills 10 times: %d/10\n- Wins: %d" % [mini(Settings.matches, 3), mini(Settings.kills, 10), mini(Settings.skills_used, 10), Settings.wins]

func _open_armory() -> void:
	var a := Armory.new()
	a.closed.connect(func():
		a.queue_free())
	add_child(a)

func _open_vault() -> void:
	var v := Vault.new()
	v.closed.connect(func():
		v.queue_free()
		_refresh())
	add_child(v)

func _open_customize() -> void:
	var c := Customize.new()
	c.closed.connect(func(): c.queue_free())
	add_child(c)

func _add_slider(parent: Control, text: String, lo: float, hi: float, val: float, cb: Callable) -> void:
	var l := Label.new()
	l.text = text
	parent.add_child(l)
	var s := HSlider.new()
	s.min_value = lo
	s.max_value = hi
	s.step = 0.01
	s.value = val
	s.custom_minimum_size = Vector2(520, 32)
	s.value_changed.connect(cb)
	parent.add_child(s)

func _open_settings() -> void:
	if overlay:
		overlay.queue_free()
	var p := PanelContainer.new()
	overlay = p
	p.position = Vector2(340, 90)
	var box := VBoxContainer.new()
	p.add_child(box)
	var t := Label.new()
	t.text = "SETTINGS"
	t.add_theme_font_size_override("font_size", 28)
	box.add_child(t)
	_add_slider(box, "Camera sensitivity", 0.3, 2.5, Settings.cam_sens, func(v): Settings.cam_sens = v)
	_add_slider(box, "Aim sensitivity (while firing)", 0.3, 2.5, Settings.aim_sens, func(v): Settings.aim_sens = v)
	_add_slider(box, "Aim assist strength (0.40 = 40%, range ~1.5 m)", 0.0, 0.6, Settings.aim_assist, func(v): Settings.aim_assist = v)
	_add_slider(box, "Volume", 0.0, 1.0, Settings.volume, func(v): Settings.volume = v)
	var cb := CheckButton.new()
	cb.text = "Low-end device mode (fewer trees, no shadows)"
	cb.button_pressed = Settings.low_end
	cb.toggled.connect(func(on): Settings.low_end = on)
	box.add_child(cb)
	var close := Button.new()
	close.text = "SAVE & CLOSE"
	close.custom_minimum_size = Vector2(0, 50)
	close.pressed.connect(func():
		Settings.save_all()
		p.queue_free())
	box.add_child(close)
	add_child(p)
