extends RefCounted
## Saved settings, control layout and player profile (user://save.cfg).

const PATH := "user://save.cfg"
const LAYOUT_VERSION := 2
const BUTTONS := ["stick", "fire", "scope", "jump", "crouch", "prone", "reload", "swap", "grenade", "medkit", "skill1", "skill2", "skill3"]
# Default HUD (matches the reference "HUD 2" screenshot).
# name: [x fraction, y fraction, size multiplier]
const DEFAULT_LAYOUT := {
	"stick": [0.17, 0.75, 1.1],
	"grenade": [0.06, 0.73, 0.85],
	"fire": [0.84, 0.72, 1.5],
	"scope": [0.93, 0.53, 0.8],
	"jump": [0.93, 0.70, 0.85],
	"crouch": [0.91, 0.88, 0.8],
	"prone": [0.84, 0.93, 0.7],
	"medkit": [0.735, 0.67, 0.75],
	"reload": [0.755, 0.82, 0.75],
	"swap": [0.70, 0.82, 0.75],
	"skill1": [0.64, 0.80, 0.85],
	"skill2": [0.62, 0.62, 0.85],
	"skill3": [0.55, 0.80, 0.85],
}
const TIERS := ["Bronze", "Silver", "Gold", "Platinum", "Diamond", "Heroic"]
const TIER_MIN := [0, 100, 250, 450, 700, 1000]

static var layout: Dictionary = {}
static var opacity := 0.75
static var cam_sens := 1.0
static var aim_sens := 0.8
static var aim_assist := 0.4
static var low_end := false
static var volume := 0.8
static var rp := 0
static var matches := 0
static var kills := 0
static var wins := 0
static var skills_used := 0
static var char_idx := 0
static var loadout := {"p1": "m4a1", "p2": "m1014", "pistol": "usp", "melee": "fist", "grenade": "grenade"}
static var skins := {}     # weapon id -> equipped skin index
static var outfits := {}   # character name -> {slot: item index}
static var free_idx := 8   # ability equipped by Primis / Nulla (default: Alok)
static var loaded := false

static func reset_layout() -> void:
	layout = {}
	for b in BUTTONS:
		layout[b] = DEFAULT_LAYOUT[b].duplicate()

static func load_all() -> void:
	if loaded:
		return
	loaded = true
	reset_layout()
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	if cfg.get_value("layout", "version", 0) == LAYOUT_VERSION:
		for b in BUTTONS:
			var v = cfg.get_value("layout", b, null)
			if v is Array and v.size() == 3:
				layout[b] = v
	opacity = cfg.get_value("ui", "opacity", opacity)
	cam_sens = cfg.get_value("ui", "cam_sens", cam_sens)
	aim_sens = cfg.get_value("ui", "aim_sens", aim_sens)
	aim_assist = cfg.get_value("ui", "aim_assist", aim_assist)
	low_end = cfg.get_value("ui", "low_end", low_end)
	volume = cfg.get_value("ui", "volume", volume)
	rp = cfg.get_value("profile", "rp", rp)
	matches = cfg.get_value("profile", "matches", matches)
	kills = cfg.get_value("profile", "kills", kills)
	wins = cfg.get_value("profile", "wins", wins)
	skills_used = cfg.get_value("profile", "skills_used", skills_used)
	char_idx = cfg.get_value("profile", "char_idx", char_idx)
	free_idx = cfg.get_value("profile", "free_idx", free_idx)
	for k in loadout.keys():
		loadout[k] = cfg.get_value("loadout", k, loadout[k])
	var sk = cfg.get_value("skins", "all", {})
	if sk is Dictionary:
		skins = sk
	var of = cfg.get_value("outfits", "all", {})
	if of is Dictionary:
		outfits = of

static func save_all() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("layout", "version", LAYOUT_VERSION)
	for b in BUTTONS:
		cfg.set_value("layout", b, layout[b])
	cfg.set_value("ui", "opacity", opacity)
	cfg.set_value("ui", "cam_sens", cam_sens)
	cfg.set_value("ui", "aim_sens", aim_sens)
	cfg.set_value("ui", "aim_assist", aim_assist)
	cfg.set_value("ui", "low_end", low_end)
	cfg.set_value("ui", "volume", volume)
	cfg.set_value("profile", "rp", rp)
	cfg.set_value("profile", "matches", matches)
	cfg.set_value("profile", "kills", kills)
	cfg.set_value("profile", "wins", wins)
	cfg.set_value("profile", "skills_used", skills_used)
	cfg.set_value("profile", "char_idx", char_idx)
	cfg.set_value("profile", "free_idx", free_idx)
	for k in loadout.keys():
		cfg.set_value("loadout", k, loadout[k])
	cfg.set_value("skins", "all", skins)
	cfg.set_value("outfits", "all", outfits)
	cfg.save(PATH)

static func tier_index() -> int:
	var idx := 0
	for i in TIER_MIN.size():
		if rp >= TIER_MIN[i]:
			idx = i
	return idx
