extends RefCounted
## Characters and abilities.
## Each character has an optional "passive" and up to 3 "skills" (active, shown as skill buttons).
## Characters with "free_skill": true (Primis, Nulla) have no skill of their own: the player equips
## any other character's ability in the lobby (like the original character screen says).
##
## passive kinds: blades, fist, wolfpack, mark, agility, gluttony, limelight, velocity
## skill kinds:   dash, shield, heal, speed, radar, blast, rush, remix, wave, field  (implemented in game.gd)

const CHARS := [
	{
		"name": "Hayato", "title": "Firebrand", "gender": "Male",
		"shirt": Color(0.12, 0.25, 0.62), "pants": Color(0.07, 0.07, 0.09), "skin": Color(0.80, 0.64, 0.52), "hair": Color(0.05, 0.05, 0.07),
		"passive": {"name": "Art of Blades", "kind": "blades", "tags": "DMG Resist / Armor Pierce",
			"desc": "Lower HP grants more armor penetration (up to +50% damage dealt) and frontal damage reduction (up to 30%)."},
		"skills": [],
	},
	{
		"name": "Primis", "title": "", "gender": "Male", "free_skill": true,
		"shirt": Color(0.07, 0.07, 0.07), "pants": Color(0.30, 0.27, 0.20), "skin": Color(0.78, 0.60, 0.45), "hair": Color(0.62, 0.50, 0.32),
		"passive": {}, "skills": [],
	},
	{
		"name": "Kla", "title": "", "gender": "Male",
		"shirt": Color(0.76, 0.56, 0.42), "pants": Color(0.22, 0.10, 0.10), "skin": Color(0.76, 0.56, 0.42), "hair": Color(0.06, 0.05, 0.05), "acc": "cap", "acc_color": Color(0.5, 0.8, 1.0),
		"passive": {"name": "Muay Thai", "kind": "fist", "tags": "Fist",
			"desc": "Fist damage increases by 400%. Use the SWAP button to switch to fists."},
		"skills": [],
	},
	{
		"name": "Andrew", "title": "", "gender": "Male",
		"shirt": Color(0.06, 0.06, 0.07), "pants": Color(0.08, 0.08, 0.10), "skin": Color(0.78, 0.60, 0.46), "hair": Color(0.30, 0.20, 0.12),
		"passive": {"name": "Wolf Pack", "kind": "wolfpack", "tags": "DMG Resist",
			"desc": "Armor defense increases. The more teammates in range, the better. (Solo mode has no teammates: fixed 15% damage reduction.)"},
		"skills": [],
	},
	{
		"name": "Moco", "title": "", "gender": "Female",
		"shirt": Color(0.95, 0.95, 0.95), "pants": Color(0.13, 0.13, 0.15), "skin": Color(0.80, 0.62, 0.50), "hair": Color(0.45, 0.28, 0.15), "acc": "mask", "acc_color": Color(0.95, 0.40, 0.60),
		"passive": {"name": "Enigma's Eye", "kind": "mark", "tags": "Share / Mark",
			"desc": "Marks enemies you hit for 6 seconds: they show above their head and on the minimap."},
		"skills": [],
	},
	{
		"name": "Caroline", "title": "", "gender": "Female",
		"shirt": Color(0.07, 0.07, 0.08), "pants": Color(0.16, 0.22, 0.32), "skin": Color(0.88, 0.72, 0.62), "hair": Color(0.68, 0.52, 0.32),
		"passive": {"name": "Agility", "kind": "agility", "tags": "Move Speed",
			"desc": "When holding a shotgun, movement speed increases by 16%."},
		"skills": [],
	},
	{
		"name": "Maxim", "title": "", "gender": "Male",
		"shirt": Color(0.95, 0.95, 0.97), "pants": Color(0.07, 0.07, 0.09), "skin": Color(0.85, 0.70, 0.60), "hair": Color(0.80, 0.80, 0.83), "acc": "glasses", "acc_color": Color(0.9, 0.75, 0.2),
		"passive": {"name": "Gluttony", "kind": "gluttony", "tags": "Recover",
			"desc": "Using Med Kits is 25% faster. (Mushrooms are not in this prototype.)"},
		"skills": [],
	},
	{
		"name": "Tatsuya", "title": "", "gender": "Male",
		"shirt": Color(0.95, 0.95, 0.97), "pants": Color(0.07, 0.07, 0.09), "skin": Color(0.82, 0.66, 0.54), "hair": Color(0.80, 0.80, 0.83), "acc": "mask", "acc_color": Color(0.08, 0.08, 0.10),
		"passive": {},
		"skills": [
			{"name": "Rebel Rush", "kind": "rush", "cd": 18.0, "tags": "Mobility / Attack",
				"desc": "Rush forward quickly (hits enemies on the way for 40) and reset the cooldown by knocking down enemies within 3 seconds."},
		],
	},
	{
		"name": "Alok", "title": "", "gender": "Male",
		"shirt": Color(0.95, 0.95, 0.95), "pants": Color(0.16, 0.16, 0.18), "skin": Color(0.80, 0.64, 0.52), "hair": Color(0.78, 0.78, 0.80), "acc": "glasses", "acc_color": Color(1.0, 0.75, 0.1),
		"passive": {},
		"skills": [
			{"name": "Party Remix", "kind": "remix", "cd": 30.0, "tags": "Heal / Move Speed",
				"desc": "Recovers HP over time (+30 HP in 5 s) and increases movement speed by 15%. (Music notes for teammates need squads, not in this prototype.)"},
		],
	},
	{
		"name": "Wolfrahh", "title": "", "gender": "Male",
		"shirt": Color(0.40, 0.75, 0.95), "pants": Color(0.15, 0.15, 0.17), "skin": Color(0.84, 0.68, 0.56), "hair": Color(0.76, 0.76, 0.80),
		"passive": {"name": "Limelight", "kind": "limelight", "tags": "DMG Resist / Headshot",
			"desc": "Headshots deal more damage to enemies (x2.4 instead of x1.8) and you take no extra damage from headshots."},
		"skills": [],
	},
	{
		"name": "Skyler", "title": "", "gender": "Male",
		"shirt": Color(0.82, 0.90, 0.96), "pants": Color(0.93, 0.93, 0.95), "skin": Color(0.86, 0.72, 0.62), "hair": Color(0.25, 0.15, 0.10), "acc": "glasses", "acc_color": Color(0.05, 0.05, 0.08),
		"passive": {},
		"skills": [
			{"name": "Riptide Rhythm", "kind": "wave", "cd": 35.0, "tags": "Wall Break",
				"desc": "Unleashes a sonic wave forward. (No Gloo Walls in this prototype, so it deals 45 damage to enemies in an 18 m cone.)"},
		],
	},
	{
		"name": "Nulla", "title": "", "gender": "Female", "free_skill": true,
		"shirt": Color(0.07, 0.07, 0.08), "pants": Color(0.10, 0.12, 0.18), "skin": Color(0.74, 0.55, 0.42), "hair": Color(0.40, 0.26, 0.16),
		"passive": {}, "skills": [],
	},
	{
		"name": "Chrono", "title": "", "gender": "Male",
		"shirt": Color(0.95, 0.95, 0.97), "pants": Color(0.07, 0.07, 0.09), "skin": Color(0.78, 0.60, 0.46), "hair": Color(0.80, 0.80, 0.83), "acc": "glasses", "acc_color": Color(1.0, 0.75, 0.1),
		"passive": {},
		"skills": [
			{"name": "Time Turner", "kind": "field", "cd": 40.0, "tags": "Shield Barrier",
				"desc": "Creates a damage-blocking force field for 5 s. Standing inside it you take 90% less damage."},
		],
	},
	{
		"name": "Kelly", "title": "the Swift", "gender": "Female",
		"shirt": Color(0.96, 0.80, 0.10), "pants": Color(0.96, 0.80, 0.10), "skin": Color(0.78, 0.60, 0.46), "hair": Color(0.06, 0.05, 0.05),
		"passive": {"name": "Ultra Velocity", "kind": "velocity", "tags": "Move Speed / Attack",
			"desc": "Sprint speed up and higher first-shot damage (+60%) after sprinting. Hold the stick fully for 0.6 s to sprint."},
		"skills": [],
	},
	{
		"name": "Rafi", "title": "original", "gender": "Male",
		"shirt": Color(0.15, 0.50, 0.32), "pants": Color(0.12, 0.12, 0.17), "skin": Color(0.66, 0.47, 0.34), "hair": Color(0.08, 0.06, 0.05),
		"passive": {},
		"skills": [
			{"name": "Dash", "kind": "dash", "cd": 6.0, "tags": "Mobility", "desc": "Burst forward quickly to dodge fire or close distance."},
			{"name": "Shield Pulse", "kind": "shield", "cd": 14.0, "tags": "Shield", "desc": "Take 70% less damage for 3 seconds."},
			{"name": "Heal Wave", "kind": "heal", "cd": 18.0, "tags": "Heal", "desc": "Instantly restore 30 HP."},
		],
	},
	{
		"name": "Nila", "title": "original", "gender": "Female",
		"shirt": Color(0.55, 0.20, 0.55), "pants": Color(0.10, 0.14, 0.22), "skin": Color(0.72, 0.52, 0.38), "hair": Color(0.08, 0.06, 0.05),
		"passive": {},
		"skills": [
			{"name": "Sprint", "kind": "speed", "cd": 10.0, "tags": "Move Speed", "desc": "Move 60% faster for 4 seconds."},
			{"name": "Radar", "kind": "radar", "cd": 20.0, "tags": "Scan", "desc": "Reveal all enemy directions on the minimap for 5 seconds."},
			{"name": "Shock Blast", "kind": "blast", "cd": 16.0, "tags": "Attack", "desc": "Damage every enemy within 8 metres (40 damage)."},
		],
	},
]

static func display_name(c: Dictionary) -> String:
	if c.get("title", "") != "":
		return "%s \"%s\"" % [c["name"], c["title"]]
	return c["name"]

## Indices of characters whose ability can be equipped by a "free skill" character.
static func skill_sources() -> Array:
	var out: Array = []
	for i in CHARS.size():
		var c: Dictionary = CHARS[i]
		if c.get("free_skill", false):
			continue
		if not c["passive"].is_empty() or not c["skills"].is_empty():
			out.append(i)
	return out

## The character as played: free-skill characters borrow the equipped ability.
static func effective(idx: int, free_idx: int) -> Dictionary:
	var c: Dictionary = CHARS[clampi(idx, 0, CHARS.size() - 1)].duplicate(true)
	if c.get("free_skill", false):
		var src: Dictionary = CHARS[clampi(free_idx, 0, CHARS.size() - 1)]
		c["passive"] = src["passive"].duplicate(true)
		c["skills"] = src["skills"].duplicate(true)
		c["equipped_from"] = src["name"]
	return c
