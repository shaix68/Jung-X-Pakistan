extends Control
## Armory: weapon categories, stats, skins, equip + Gallery (all skins by rarity).
## Opened from the lobby WEAPON button.

signal closed

const Settings = preload("res://scripts/settings.gd")
const Weapons = preload("res://scripts/weapons.gd")

var cat_idx := 0
var wid := "m4a1"
var skin_idx := 0
var gallery_filter := "all"

var armory_box: Control
var gallery_box: Control
var cat_buttons: Array = []
var weapon_list: VBoxContainer
var title_label: Label
var stats_box: GridContainer
var skin_row: HBoxContainer
var equip_box: VBoxContainer
var loadout_label: Label
var gallery_grid: GridContainer
var model_root: Node3D
var spin := 0.0

func _ready() -> void:
	size = get_viewport_rect().size
	mouse_filter = Control.MOUSE_FILTER_STOP
	var bg := ColorRect.new()
	bg.color = Color(0.1, 0.07, 0.16)
	bg.size = size
	add_child(bg)
	var top := Label.new()
	top.text = "ARMORY"
	top.position = Vector2(size.x - 260, 14)
	top.add_theme_font_size_override("font_size", 26)
	add_child(top)
	var close := Button.new()
	close.text = "X"
	close.position = Vector2(size.x - 70, 10)
	close.custom_minimum_size = Vector2(50, 44)
	close.pressed.connect(func(): closed.emit())
	add_child(close)
	_build_armory()
	_build_gallery()
	_select_weapon(Settings.loadout.get("p1", "m4a1"))
	gallery_box.visible = false

func _process(delta: float) -> void:
	if model_root != null and armory_box.visible:
		spin += delta * 0.8
		model_root.rotation.y = spin

# ------------------------------------------------------------------ armory view
func _build_armory() -> void:
	armory_box = Control.new()
	armory_box.size = size
	add_child(armory_box)
	# categories
	var y := 14.0
	for i in Weapons.CATS.size():
		var b := Button.new()
		b.text = Weapons.CATS[i]["label"]
		b.position = Vector2(20, y)
		b.custom_minimum_size = Vector2(200, 42)
		b.size = Vector2(200, 42)
		b.add_theme_font_size_override("font_size", 16)
		var idx := i
		b.pressed.connect(func(): _select_cat(idx))
		armory_box.add_child(b)
		cat_buttons.append(b)
		y += 46.0
	var gal := Button.new()
	gal.text = "GALLERY"
	gal.position = Vector2(20, size.y - 60)
	gal.size = Vector2(200, 46)
	gal.add_theme_font_size_override("font_size", 20)
	gal.pressed.connect(_show_gallery)
	armory_box.add_child(gal)
	# weapon list
	var scroll := ScrollContainer.new()
	scroll.position = Vector2(232, 14)
	scroll.size = Vector2(150, size.y - 90)
	armory_box.add_child(scroll)
	weapon_list = VBoxContainer.new()
	scroll.add_child(weapon_list)
	# title
	title_label = Label.new()
	title_label.position = Vector2(400, 14)
	title_label.add_theme_font_size_override("font_size", 28)
	armory_box.add_child(title_label)
	# 3D preview
	var svc := SubViewportContainer.new()
	svc.position = Vector2(400, 60)
	svc.size = Vector2(560, 300)
	svc.stretch = true
	armory_box.add_child(svc)
	var sv := SubViewport.new()
	sv.size = Vector2i(560, 300)
	sv.own_world_3d = true
	sv.transparent_bg = true
	svc.add_child(sv)
	var cam := Camera3D.new()
	sv.add_child(cam)
	cam.look_at_from_position(Vector3(0, 0.25, 1.9), Vector3(0, 0, 0))
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-35, 30, 0)
	sv.add_child(light)
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.16, 0.1, 0.24)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.7, 0.7, 0.8)
	env.environment = e
	sv.add_child(env)
	model_root = Node3D.new()
	sv.add_child(model_root)
	# stats
	stats_box = GridContainer.new()
	stats_box.columns = 2
	stats_box.position = Vector2(400, 372)
	stats_box.add_theme_constant_override("h_separation", 40)
	stats_box.add_theme_constant_override("v_separation", 6)
	armory_box.add_child(stats_box)
	# skins strip
	var sl := Label.new()
	sl.text = "SKINS"
	sl.position = Vector2(400, size.y - 100)
	armory_box.add_child(sl)
	var sscroll := ScrollContainer.new()
	sscroll.position = Vector2(400, size.y - 78)
	sscroll.size = Vector2(size.x - 420, 70)
	armory_box.add_child(sscroll)
	skin_row = HBoxContainer.new()
	sscroll.add_child(skin_row)
	# right: equip + loadout
	equip_box = VBoxContainer.new()
	equip_box.position = Vector2(size.x - 280, 400)
	equip_box.custom_minimum_size = Vector2(250, 0)
	armory_box.add_child(equip_box)
	loadout_label = Label.new()
	loadout_label.position = Vector2(size.x - 280, 80)
	loadout_label.add_theme_font_size_override("font_size", 16)
	armory_box.add_child(loadout_label)

func _select_cat(i: int) -> void:
	cat_idx = i
	var list := Weapons.in_category(Weapons.CATS[i]["id"])
	_select_weapon(list[0][0])

func _select_weapon(id: String) -> void:
	wid = id
	var e := Weapons.get_entry(id)
	for i in Weapons.CATS.size():
		if Weapons.CATS[i]["id"] == e[2]:
			cat_idx = i
	skin_idx = int(Settings.skins.get(id, 0))
	_refresh()

func _refresh() -> void:
	for i in cat_buttons.size():
		cat_buttons[i].modulate = Color(1, 0.85, 0.2) if i == cat_idx else Color(1, 1, 1)
	for ch in weapon_list.get_children():
		ch.queue_free()
	for w in Weapons.in_category(Weapons.CATS[cat_idx]["id"]):
		var b := Button.new()
		b.text = "%s  (%d)" % [w[1], Weapons.skins_for(w[0]).size()]
		b.custom_minimum_size = Vector2(140, 44)
		b.modulate = Color(1, 0.85, 0.2) if w[0] == wid else Color(1, 1, 1)
		var id: String = w[0]
		b.pressed.connect(func(): _select_weapon(id))
		weapon_list.add_child(b)
	var s := Weapons.stats(wid, skin_idx)
	title_label.text = "%s - %s" % [String(s["name"]).to_upper(), String(s["skin"]).to_upper()] if skin_idx > 0 else String(s["name"]).to_upper()
	# model
	for ch in model_root.get_children():
		ch.queue_free()
	var m := Weapons.build_model(s)
	var sc := 2.3
	if s["cat"] == "melee" or s["cat"] == "grenade" or s["cat"] == "fist":
		sc = 2.6
	m.scale = Vector3.ONE * sc
	model_root.add_child(m)
	# stat bars
	for ch in stats_box.get_children():
		ch.queue_free()
	var labels: Array = Weapons.labels_for(wid)
	var bars: Array = Weapons.get_entry(wid)[3]
	for i in labels.size():
		var row := VBoxContainer.new()
		var l := Label.new()
		l.text = labels[i]
		l.add_theme_font_size_override("font_size", 14)
		row.add_child(l)
		var pb := ProgressBar.new()
		pb.min_value = 0
		pb.max_value = 100
		pb.value = bars[i]
		pb.show_percentage = false
		pb.custom_minimum_size = Vector2(220, 10)
		row.add_child(pb)
		stats_box.add_child(row)
	# skins
	for ch in skin_row.get_children():
		ch.queue_free()
	var sk := Weapons.skins_for(wid)
	for i in sk.size():
		var b := Button.new()
		b.text = String(sk[i][0]) + "\n" + String(sk[i][1]).to_upper()
		b.custom_minimum_size = Vector2(150, 58)
		b.add_theme_color_override("font_color", Weapons.RARITY_COLORS[sk[i][1]])
		if i == skin_idx:
			b.add_theme_color_override("font_color", Color(1, 0.9, 0.3))
			b.text = "> " + b.text
		var idx := i
		b.pressed.connect(func(): _pick_skin(idx))
		skin_row.add_child(b)
	_refresh_equip()

func _pick_skin(i: int) -> void:
	skin_idx = i
	Settings.skins[wid] = i
	Settings.save_all()
	_refresh()

func _slot_for(cat: String) -> String:
	match cat:
		"pistol": return "pistol"
		"melee", "fist": return "melee"
		"grenade": return "grenade"
	return "p1"

func _refresh_equip() -> void:
	for ch in equip_box.get_children():
		ch.queue_free()
	var cat: String = Weapons.get_entry(wid)[2]
	if Weapons.is_primary(cat):
		for sl in ["p1", "p2"]:
			var b := Button.new()
			var on: bool = Settings.loadout[sl] == wid
			b.text = ("EQUIPPED AS PRIMARY %s" if on else "EQUIP AS PRIMARY %s") % sl.substr(1)
			b.disabled = on
			b.custom_minimum_size = Vector2(250, 48)
			var slot: String = sl
			b.pressed.connect(func(): _equip(slot))
			equip_box.add_child(b)
	else:
		var slot := _slot_for(cat)
		var b := Button.new()
		var on: bool = Settings.loadout[slot] == wid
		b.text = "EQUIPPED" if on else "EQUIP"
		b.disabled = on
		b.custom_minimum_size = Vector2(250, 48)
		b.pressed.connect(func(): _equip(slot))
		equip_box.add_child(b)
	var note := Label.new()
	note.text = "Equipped weapons are used in matches.\nSwap button cycles: Primary 1 > Primary 2 > Pistol > Melee."
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.custom_minimum_size = Vector2(250, 0)
	note.add_theme_font_size_override("font_size", 13)
	equip_box.add_child(note)
	var L := Settings.loadout
	loadout_label.text = "LOADOUT\nPrimary 1: %s\nPrimary 2: %s\nPistol: %s\nMelee: %s\nThrowable: %s" % [
		Weapons.get_entry(L["p1"])[1], Weapons.get_entry(L["p2"])[1], Weapons.get_entry(L["pistol"])[1],
		Weapons.get_entry(L["melee"])[1], Weapons.get_entry(L["grenade"])[1]]

func _equip(slot: String) -> void:
	if slot == "p1" or slot == "p2":
		var other := "p2" if slot == "p1" else "p1"
		if Settings.loadout[other] == wid:
			Settings.loadout[other] = Settings.loadout[slot]   # swap so both slots stay different
	Settings.loadout[slot] = wid
	Settings.save_all()
	_refresh_equip()

# ------------------------------------------------------------------ gallery view
func _build_gallery() -> void:
	gallery_box = Control.new()
	gallery_box.size = size
	add_child(gallery_box)
	var title := Label.new()
	title.text = "GALLERY"
	title.position = Vector2(size.x - 260, 14)
	title.add_theme_font_size_override("font_size", 26)
	gallery_box.add_child(title)
	var filters := ["all"] + Weapons.RARITIES
	var y := 70.0
	for f in filters:
		var b := Button.new()
		b.text = String(f).to_upper()
		b.position = Vector2(20, y)
		b.size = Vector2(180, 44)
		if f != "all":
			b.add_theme_color_override("font_color", Weapons.RARITY_COLORS[f])
		var ff: String = f
		b.pressed.connect(func(): _set_filter(ff))
		gallery_box.add_child(b)
		y += 50.0
	var back := Button.new()
	back.text = "< ARMORY"
	back.position = Vector2(20, size.y - 60)
	back.size = Vector2(180, 46)
	back.pressed.connect(_show_armory)
	gallery_box.add_child(back)
	var scroll := ScrollContainer.new()
	scroll.position = Vector2(230, 70)
	scroll.size = Vector2(size.x - 260, size.y - 90)
	gallery_box.add_child(scroll)
	gallery_grid = GridContainer.new()
	gallery_grid.columns = 5
	gallery_grid.add_theme_constant_override("h_separation", 8)
	gallery_grid.add_theme_constant_override("v_separation", 8)
	scroll.add_child(gallery_grid)

func _show_gallery() -> void:
	armory_box.visible = false
	gallery_box.visible = true
	_set_filter(gallery_filter)

func _show_armory() -> void:
	gallery_box.visible = false
	armory_box.visible = true
	_refresh()

func _set_filter(f: String) -> void:
	gallery_filter = f
	for ch in gallery_grid.get_children():
		ch.queue_free()
	var count := 0
	for w in Weapons.LIST:
		var sk := Weapons.skins_for(w[0])
		for i in sk.size():
			if f != "all" and sk[i][1] != f:
				continue
			var b := Button.new()
			b.text = "%s\n%s\n%s" % [w[1], sk[i][0], String(sk[i][1]).to_upper()]
			b.custom_minimum_size = Vector2(168, 84)
			b.add_theme_color_override("font_color", Weapons.RARITY_COLORS[sk[i][1]])
			b.add_theme_font_size_override("font_size", 13)
			var id: String = w[0]
			var si := i
			b.pressed.connect(func():
				Settings.skins[id] = si
				_show_armory()
				_select_weapon(id))
			gallery_grid.add_child(b)
			count += 1
	if count == 0:
		var l := Label.new()
		l.text = "No skins in this rarity."
		gallery_grid.add_child(l)
